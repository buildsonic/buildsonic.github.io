import model.Repository
import util.GitUtil
import util.GithubUtil
import util.GradleUtil
import util.HubUtil
import util.MavenUtil
import util.TravisUtil
import util.Util
import java.nio.file.Files
import java.nio.file.Paths

class PullRequestCreator {
    static List<String> initGitAndRepo(Repository repository, String branchSuffix){
        String originRepoName = repository.getRepoName()
        GithubUtil.forkRepo(originRepoName)

        String defaultBranchName = GithubUtil.getDefaultBranchName(originRepoName)

        def (userName, repoName) = Util.splitFullRepoName(originRepoName)
        String forkRepoName = "${GithubUtil.USER_NAME}/${repoName}"

        Util.createDir(Util.forkDirectoryPath.toString())
        String repoPath = Paths.get(Util.forkDirectoryPath, forkRepoName.replace("/", "@")).toString()
        if (!Files.exists(Paths.get(repoPath))) {
            HubUtil.cloneRepo(repoPath, forkRepoName)
        }

        GitUtil.setUpstream(repoPath, originRepoName)
        HubUtil.fetchAndMergeUpStream(repoPath, defaultBranchName)

        String branchName = GitUtil.createAndCheckoutBranch(repoPath, "Modify_${branchSuffix}", defaultBranchName)

        return [repoPath, originRepoName, branchName, defaultBranchName, branchSuffix]
    }

    static Boolean pushAndMakePullRequest(List<String> repoInfos, List<Object> strategies ){
        def (repoPath, originRepoName, branchName, defaultBranchName, branchSuffix) = repoInfos
        String commitMessage = "Improve ${branchSuffix} build Performance"
        GitUtil.addAndCommit(repoPath, commitMessage)

        HubUtil.push(repoPath, branchName)

        String head = "${GithubUtil.USER_NAME}:${branchName}"
        def (title, description, outFilePaths) = null
        if(branchSuffix == "TRAVIS"){
            (title, description, outFilePaths) = PullRequestTravisCreator.getDescription(strategies as List<TravisUtil.TravisStrategy>)
        }else if(branchSuffix == "MAVEN"){
            (title, description, outFilePaths) = PullRequestMavenCreator.getDescription(strategies as List<MavenUtil.MavenStrategy>)
        }else{
            (title, description, outFilePaths) = PullRequestGradleCreator.getDescription(strategies as List<GradleUtil.GradleStrategy>)
        }
        return GithubUtil.pullRequest(originRepoName, head, defaultBranchName, title, description, outFilePaths)
    }

    static pullRequestExist(String originRepoName, List<Object> strategies){
        def onlyStrategies = []

        Closure strategyPullRequestExist = { Object strategy ->
            String contentFilePath = Util.getPullRequestListFilePath(strategy)
            File contentFile = new File(contentFilePath)
            String content = contentFile.exists() ? contentFile.text : ""
            if (content.contains(originRepoName)) {
                return true
            }
            return false
        }

        strategies.each{strategy->
            if(strategyPullRequestExist.call(strategy)){
                return
            }
            onlyStrategies << strategy
        }
        if(onlyStrategies.size()==0){
            return null
        }
        return onlyStrategies
    }

    static void goSleep(){
        Random random = new Random()
        Long sleepTime = 0 + random.nextInt(15)
        long start = System.currentTimeMillis()
        sleep(sleepTime*60000)
        long end = System.currentTimeMillis()
    }
}
