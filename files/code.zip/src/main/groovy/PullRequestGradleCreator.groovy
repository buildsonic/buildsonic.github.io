import smell.fixer.Gradle.GradleFixer
import model.Repository
import smell.checker.gradle.GradleChecker
import util.*
import static util.GradleUtil.*
import static PullRequestCreator.*


class PullRequestGradleCreator {

    static Boolean run(Repository repository, List<GradleStrategy> strategies) {
        def repoInfos = initGitAndRepo(repository,"GRADLE")
        def (repoPath,originRepoName, branchName, defaultBranchName, branchSuffix) = repoInfos

        def onlyStrategies = pullRequestExist(repository.repoName,strategies)
        if(onlyStrategies==null){
            return false
        }
        checkAndFix(repository,repoPath,onlyStrategies)

        return pushAndMakePullRequest(repoInfos,onlyStrategies)
    }

    static void checkAndFix(Repository repository, String repoPath, List<GradleStrategy> onlyStrategies){
        def checkedFileWithStrategy = GradleChecker.check(repository,repoPath)

        if (checkedFileWithStrategy.keySet().size() == 0){
            return
        }

        GradleFixer fixer = new GradleFixer(repoPath,repository.repoName,checkedFileWithStrategy)
        fixer.fix(onlyStrategies)

    }

    static String getPRTitle(GradleStrategy strategy){
        def parallelTest = [
                'Parallel test execution maxParallelForks',
                'Enable parallel test feature',
                'Take full advantage of multi-core cpus while execute test',
        ]
        def parallelBuild = [
                'Parallel builds can improve the build speed',
                'Reduce total build time for a multi-project build',
                'Provide faster feedback for execution by Parallel Build',
        ]
        def gradleDaemon = [
                'Executes the builds much more quickly by Gradle Daemon',
                'Gradle Daemon is important for performance',
                'Improve build speed by reusing computations from previous builds'
        ]
        def configurationOnDemand = [
                'Configure only projects that are relevant for requested tasks',
                'How about enable Gradle Configuration on Demand feature',
                'Improve GRADLE build Performance'
        ]
        int randomNum = new Random().nextInt(3)
        if(strategy== GradleStrategy.GRADLE_PARALLEL_TEST){
            return parallelTest[randomNum]
        }
        if(strategy== GradleStrategy.GRADLE_PARALLEL_BUILDS){
            return parallelBuild[randomNum]
        }
        if(strategy== GradleStrategy.GRADLE_DAEMON){
            return gradleDaemon[randomNum]
        }
        if(strategy== GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND){
            return configurationOnDemand[randomNum]
        }

        return ""
    }

    static List<String> getDescription(List<GradleStrategy> strategies) {
        String title = getPRTitle(strategies[0])
        title = title==""?'Improve GRADLE build Performance':title
        String description = ""
        List<String> outFilePaths = []

        for (GradleStrategy strategy : strategies) {
            outFilePaths << Util.getPullRequestListFilePath(strategy)

            if (strategy == GradleStrategy.GRADLE_PARALLEL_TEST) {
                description += "\n[Parallel test execution maxParallelForks](https://docs.gradle.org/current/userguide/performance.html#parallel_test_execution). Gradle can run multiple test cases in parallel by setting `maxParallelForks`.\n"
            } else if (strategy == GradleStrategy.GRADLE_FORK_TEST) {
                description += "\n[Process forking options](https://docs.gradle.org/current/userguide/performance.html#forking_options). Gradle will run all tests in a single forked VM by default. This can be problematic if there are a lot of tests or some very memory-hungry ones. We can fork a new test VM after a certain number of tests have run by setting `forkEvery`.\n"
            } else if (strategy == GradleStrategy.GRADLE_REPORT_GENERATION) {
                description += "\n[Disable report generation](https://docs.gradle.org/current/userguide/performance.html#report_generation). We can conditionally disable it by setting `reports.html.required = false; reports.junitXml.required = false`. If you need to generate reports, add `-PcreateReports` to the end of Gradle's build command line.\n"
            } else if (strategy == GradleStrategy.GRADLE_COMPILER_DAEMON) {
                description += "\n[Compiler daemon](https://docs.gradle.org/current/userguide/performance.html#compiler_daemon). The Gradle Java plugin allows you to run the compiler as a separate process by setting `options.fork = true`. This feature can lead to much less garbage collection and make Gradle’s infrastructure faster. This project has more than 1000 source files. We can consider enabling this feature.\n"
            } else if(strategy == GradleStrategy.GRADLE_INCREMENTAL_COMPILATION){
                description += "\n[Incremental compilation](https://docs.gradle.org/current/userguide/performance.html#incremental_compilation). Gradle recompile only the classes that were affected by a change. This feature is the default since Gradle 4.10. For an older versions, we can activate it by setting `options.incremental = true`.\n"
            } else if (strategy == GradleStrategy.GRADLE_PARALLEL_BUILDS){
                description += "\n[Parallel builds](https://docs.gradle.org/current/userguide/multi_project_configuration_and_execution.html#sec:parallel_execution). This project contains multiple modules. Parallel builds can improve the build speed by executing tasks in parallel. We can enable this feature by setting `org.gradle.parallel=true`.\n"
            } else if (strategy == GradleStrategy.GRADLE_FILE_SYSTEM_WATCHING){
                description += "\n[File system watching](https://blog.gradle.org/introducing-file-system-watching). Since Gradle 6.5, File system watching was introduced which can help to avoid unnecessary I/O. This feature is the default since 7.0. For an older version, we can enable this feature by setting `org.gradle.vfs.watch=true`.\n"
            } else if (strategy == GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND){
                description += "\n[Configuration on demand](https://docs.gradle.org/current/userguide/multi_project_configuration_and_execution.html#sec:configuration_on_demand). Configuration on demand tells Gradle to configure modules that only are relevant to the requested tasks instead of configuring all of them. We can enable this feature by setting `org.gradle.configureondemand=true`.\n"
            } else if (strategy == GradleStrategy.GRADLE_CACHING){
                description += "\n[gradle caching](https://docs.gradle.org/current/userguide/build_cache.html). Shared caches can reduce the number of tasks you need to execute by reusing outputs already generated elsewhere. This can significantly decrease build times. We can enable this feature by setting `org.gradle.caching=true`.\n"
            } else if (strategy == GradleStrategy.GRADLE_DAEMON){
                description += "\n[Gradle daemon](https://docs.gradle.org/current/userguide/gradle_daemon.html#header). The Daemon is a long-lived process that help to avoid the cost of JVM startup for every build. Since Gradle 3.0, Gradle daemon is enabled by default. For an older version, you should enable it by setting `org.gradle.daemon=true`.\n"
            }

        }

        description += '\n=====================\nIf there are any inappropriate modifications in this PR, please give me a reply and I will change them.\n'
        return [title, description, outFilePaths]
    }


    static Boolean createGradlePullRequest(Repository repository, List<GradleStrategy> strategies){
        String repoName = repository.repoName
        def PRCreated = false
        try {
            PRCreated = run(repository,strategies)
        } catch (Exception e) {
            e.printStackTrace()
        }
        return PRCreated
    }

    static Map<GradleCategory, List<Repository>> getRepositoriesMap(){
        Map<GradleCategory, List<Repository>> repositoriesMap = [(GradleCategory.PROPERTIES): [],
                                                                 (GradleCategory.COMPILATION): [],
                                                                 (GradleCategory.TEST): [],
                                                                 ]

        for (Repository repository : MysqlUtil.getRepositories()) {
            if(repository.buildTool == 2) {
                if (repository.javaFilesNum>=1000){
                    repositoriesMap.get(GradleCategory.COMPILATION).add(repository)
                }else if(repository.id > 42471 && repository.id <= 701383){
                    repositoriesMap.get(GradleCategory.PROPERTIES).add(repository)
                }else{
                    repositoriesMap.get(GradleCategory.TEST).add(repository)
                }
            }
        }

        return repositoriesMap
    }

    static Map<GradleStrategy, List<Repository>> getExplicitRepositoriesMap(){

        Map<GradleStrategy,List<Repository>> ExplicitRepoMap = [
                (GradleStrategy.GRADLE_DAEMON):[]
        ]

        for (Repository repository : MysqlUtil.getRepositories()){
            if(repository.buildTool==2 && repository.gradleDaemon==0) {
                ExplicitRepoMap.get(GradleStrategy.GRADLE_DAEMON).add(repository)
            }
        }
        return ExplicitRepoMap
    }

    static void createGradlePullRequest(boolean isExplicit) {
        if(isExplicit){
            def repositoriesMap = getExplicitRepositoriesMap()
            repositoriesMap.each { GradleStrategy strategy, List<Repository>repositories ->
                int count = 0
                for (int i = 0; i < repositories.size() && count<50; i++) {
                    def PRCreated = createGradlePullRequest(repositories[i],[strategy])
                    if(PRCreated){
                        count++
                        goSleep()
                    }
                }
            }
        }else{
            def repositoriesMap = getRepositoriesMap()
            repositoriesMap.each { GradleCategory category, List<Repository>repositories ->
                int count = 0
                for (int i = 0; i < repositories.size() && count<50; i++) {
                    def PRCreated = createGradlePullRequest(repositories[i],strategiesOfCategory.get(category))
                    if(PRCreated){
                        count++
                        goSleep()
                    }
                }
            }
        }
    }

    static void main(String[] args) {
    }
}