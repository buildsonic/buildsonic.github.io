import model.Repository
import smell.checker.maven.MavenChecker
import smell.fixer.Maven.MavenFixer
import util.*
import static util.MavenUtil.*
import static PullRequestCreator.*

class PullRequestMavenCreator {

    static Boolean run(Repository repository, List<MavenStrategy> strategies) {
        def repoInfos = initGitAndRepo(repository,"MAVEN")
        def (repoPath,originRepoName, branchName, defaultBranchName, branchSuffix) = repoInfos

        def onlyStrategies = pullRequestExist(repository.repoName,strategies)
        if(onlyStrategies==null){
            return false
        }
        checkAndFix(repository,repoPath,onlyStrategies)

        return pushAndMakePullRequest(repoInfos,onlyStrategies)
    }



    static String getPRTitle(MavenStrategy strategy){
        def reportTitles = [
                'How about turning off the default build reports generation feature',
                            'Disable the default builds report generation function',
                            'Build reports are not always needed',
                            'Improve build performance by turning off report generation',
                            'Do not actively generate build reports when not needed',
        ]
        def forkTitles = ['Configure Maven Fork Test parameters',
                'Improve performance in the Test phase',
                'Run all the tests in multiple forked VM',
                'Dynamically adjust the number of Forked VM based on the number of CPU cores',
                'How about add more Forked VM when run all tests in build'
        ]
        def parallelTestTitles = [
                'Parallel test execution maxParallelForks',
                'Enable parallel test feature',
                'Take full advantage of multi-core cpus while execute test',
                'Improve Build Performance By Enable Parallel Test',
                'Running JUnit Tests in Parallel with Maven'
        ]
        int randomNum = new Random().nextInt(5)
        if(strategy==MavenStrategy.MAVEN_REPORT_GENERATION){
            return reportTitles[randomNum]
        }
        if(strategy==MavenStrategy.MAVEN_FORK_TEST){
            return forkTitles[randomNum]
        }
        if(strategy==MavenStrategy.MAVEN_PARALLEL_TEST){
            return parallelTestTitles[randomNum]
        }
        return null
    }

    static List<String> getDescription(List<MavenStrategy> strategies) {
        String title = getPRTitle(strategies[0])
        title = title==null?'Improve MAVEN build Performance':title
        String description = ""
        List<String> outFilePaths = []
        for (MavenStrategy strategy : strategies) {
            outFilePaths << Util.getPullRequestListFilePath(strategy)
            if (strategy == MavenStrategy.MAVEN_PARALLEL_EXECUTION) {
                description += "\n[Parallel builds in Maven 3](https://cwiki.apache.org/confluence/display/MAVEN/Parallel+builds+in+Maven+3) Maven 3.x has the capability to perform parallel builds.\n"
            } else if (strategy == MavenStrategy.MAVEN_FORK_TEST) {
                description += "\nMaven will run all tests in a single forked VM by default. This can be problematic if there are a lot of tests or some very memory-hungry ones. We can fork more test VM by setting `<fork>1.5C</fork>`.\n"
            } else if (strategy == MavenStrategy.MAVEN_REPORT_GENERATION) {
                description += "\nThat report generation takes time, slowing down the overall build. Reports are definitely useful, but do you need them every time you run the build. We can conditionally disable generating test reports by setting `<disableXmlReport>true<disableXmlReport>`. If you need to generate reports, just add `-DcloseTestReports=false` to the end of mvn build command.\n"
            } else if (strategy == MavenStrategy.MAVEN_COMPILER_DAEMON) {
                description += "\nMaven allows you to run the compiler as a separate process by setting `<fork>true</fork>`. This feature can lead to much less garbage collection and make Maven build faster. This project has more than 1000 source files. We can consider enabling this feature.\n"
            }
//            else if (strategy == MavenStrategy.MAVEN_INCREMENTAL_COMPILATION) {
//                description += "\nMaven can recompile only the classes that were affected by a change. This feature is the default. We can activate it by setting `<useIncrementalCompilation>true</useIncrementalCompilation>`.\n"
//            } else if (strategy == MavenStrategy.MAVEN_DYNAMIC_VERSION) {
//                description += '\nAccording to [Minimize dynamic and snapshot versions](https://docs.gradle.org/current/userguide/performance.html#minimize_dynamic_and_snapshot_versions), we should avoid using snapshot versions. And a build configuration should always specify exact versions of external libraries to make a build reproduceable. A lack of exact versions can cause problems when new versions of a dependency become available in the future that might introduce incompatible changes.\n'
//            } else if (strategy == MavenStrategy.MAVEN_UNUSED_DEPENDENCY) {
//                description += '\n[Apache Maven Dependency Plugin](https://maven.apache.org/plugins/maven-dependency-plugin/index.html) can be used to find unused dependencies. And I found following list. Maybe we can remove them.\n'
//                String path = Paths.get(System.getProperty("user.dir"), "resources", "mavenUnusedDependencies", "${originRepoName.replace('/', '@')}.txt").normalize().toString();
//                def (buildSuccess, contain_unused_dependency, logDependencies) = parser.MavenLogParser.parse(path)
//                logDependencies.each {k, list ->
//                    description += k + "\n"
//                    list.each {description += it.toString() + "\n"}
//                }
//                description += "\n"
//            }
            else if (strategy == MavenStrategy.MAVEN_PARALLEL_TEST) {
                description += '\nAccording to [Maven parallel test](https://www.baeldung.com/maven-junit-parallel-tests), we can run tests in parallel.\n'
            }
        }
        description += '\n=====================\nIf there are any inappropriate modifications in this PR, please give me a reply and I will change them.\n'
        return [title, description, outFilePaths]
    }

    static void checkAndFix(Repository repository, String repoPath, List<MavenStrategy> onlyStrategies){
        def checkedFileWithStrategy = MavenChecker.check(repository,repoPath)

        if (checkedFileWithStrategy.keySet().size() == 0){
            return
        }

        MavenFixer fixer = new MavenFixer(repoPath,repository.repoName,checkedFileWithStrategy)
        fixer.fix(onlyStrategies)
    }




    static Boolean createMavenPullRequest(Repository repository, List<MavenStrategy> strategies){
        String repoName = repository.repoName
        try {
           return run(repository,strategies)
        } catch (Exception e) {
            e.printStackTrace()
        }
    }

    static Map<MavenCategory, List<Repository>> getRepositoriesMap(){
        Map<MavenCategory, List<Repository>> repositoriesMap = [(MavenCategory.TEST)       : [],
                                                                (MavenCategory.COMPILATION): [],
                                                                (MavenCategory.PROPERTIES): []
        ]
        for (Repository repository : MysqlUtil.getRepositories()) {
            if(repository.buildTool == 1){
                if(repository.getJavaFilesNum()>=1000){
                        repositoriesMap.get(MavenCategory.COMPILATION).add(repository)
                } else if(repository.id > 678 && repository.id <= 769560){
                    repositoriesMap.get(MavenCategory.TEST).add(repository)
                }else{
                    repositoriesMap.get(MavenCategory.PROPERTIES).add(repository)
                }
            }
        }

        return repositoriesMap
    }

    static Map<MavenStrategy, List<Repository>> getExplicitRepositoriesMap(){
        Map<MavenStrategy, List<Repository>> repositoriesMap = [
                (MavenStrategy.MAVEN_PARALLEL_TEST)  : [],
                (MavenStrategy.MAVEN_REPORT_GENERATION)  : [],
                (MavenStrategy.MAVEN_FORK_TEST)  : [],
        ]

        for (Repository repository : MysqlUtil.getRepositories()) {
            if(repository.id>403272 && repository.buildTool==1 && repository.parallelTest==0){
                repositoriesMap.get(MavenStrategy.MAVEN_PARALLEL_TEST) << repository
            }
            if(repository.buildTool==1 && repository.mavenReportGeneration==0){
                repositoriesMap.get(MavenStrategy.MAVEN_REPORT_GENERATION) << repository
            }
            if (repository.buildTool==1 && repository.mavenForkTest==0){
                repositoriesMap.get(MavenStrategy.MAVEN_FORK_TEST) << repository
            }
        }

        return repositoriesMap
    }

    static void createMavenPullRequest(boolean isExplicit=false) {
        if(isExplicit){
            def repositoriesMap = getExplicitRepositoriesMap()
            int count = 0
            repositoriesMap.each { strategy,repositories ->
                for(int i=0; i<repositories.size() && count<50;i++){
                    def PRCreated =  createMavenPullRequest(repositories[i],[strategy])
                    if(PRCreated){
                        count++
                        goSleep()
                    }
                }
            }
        }else{
            Map<MavenCategory, List<Repository>> repositoriesMap = getRepositoriesMap()
            int count = 0
            repositoriesMap.each { MavenCategory category, List<Repository> repositories ->
                for (int i = 0; count<50 && i<repositories.size(); i++) {
                    def PRCreated = createMavenPullRequest(repositories[i],strategiesOfCategory.get(category))
                    if(PRCreated){
                        count ++
                        goSleep()
                    }
                }
            }
        }
    }



    static void main(String[] args) {
//        createMavenPullRequest(true)
    }
}
