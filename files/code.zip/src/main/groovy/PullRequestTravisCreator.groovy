import model.Repository
import smell.StateFlag
import smell.checker.TravisChecker
import smell.TravisFixer
import util.GitUtil
import util.GithubUtil
import util.HubUtil
import util.MysqlUtil
import util.Util
import java.nio.file.Files
import java.nio.file.Paths
import util.TravisUtil.TravisStrategy
class PullRequestTravisCreator {



    static void run(Repository repository, List<TravisStrategy> strategies) {
        String originRepoName = repository.getRepoName()
        // fork原项目
        GithubUtil.forkRepo(originRepoName)

        //得到默认的分支名
        String defaultBranchName = GithubUtil.getDefaultBranchName(originRepoName)

        //fork项目名
        def (userName, repoName) = Util.splitFullRepoName(originRepoName)
        String forkRepoName = "${GithubUtil.USER_NAME}/${repoName}"

        // 存储项目代码的目录，如果不存在就创建
        Util.createDir(Util.forkDirectoryPath.toString())
        //clone项目代码到指定文件夹
        String repoPath = Paths.get(Util.forkDirectoryPath, forkRepoName.replace("/", "@")).toString()
        if (!Files.exists(Paths.get(repoPath))) {
            HubUtil.cloneRepo(repoPath, forkRepoName)
        }
        //更新fork仓库代码
        //git remote add upstream
        GitUtil.setUpstream(repoPath, originRepoName)
        HubUtil.fetchAndMergeUpStream(repoPath, defaultBranchName)

        // 已存在分支的话，会切换到相应分支
        String branchName = GitUtil.createAndCheckoutBranch(repoPath, "Modify_Travis", defaultBranchName)

        //获取要执行的修复策略
        if (strategies == null) {
            return
        }
        def strategyWithFlag= getTravisStrategies(repository,repoPath, originRepoName,strategies)
        if (strategyWithFlag.size()==0) {
            return
        }

        //进行修复操作 写入到文件中 并提交commit

        applyFix(repoPath,repository,strategyWithFlag)

        String commitMessage = 'Improve Travis CI build Performance'

//        if (strategyCombine == StrategyCombine.TRAVIS) {
//            commitMessage = 'Improve Travis CI build Performance'
//        }
        GitUtil.addAndCommit(repoPath, commitMessage)

        //push
        HubUtil.push(repoPath, branchName)

        //发起pull request
        String head = "${GithubUtil.USER_NAME}:${branchName}"
        def (title, description, outFilePaths) = getDescription(strategies)
        GithubUtil.pullRequest(originRepoName, head, defaultBranchName, title, description, outFilePaths)
    }

    static List<String> getDescription(List<TravisStrategy> strategies) {
        String title = 'Improve Travis CI build Performance'
        String description = ""
        List<String> outFilePaths = []
        for (TravisStrategy strategy : strategies) {
            if (strategy == TravisStrategy.TRAVIS_CACHE) {
                description += "\n[Caching Dependencies and Directories](https://docs.travis-ci.com/user/caching/) Travis CI can cache content that does not often change, to speed up the build process.\n"
                outFilePaths << Util.TRAVIS_CACHE_LIST_PATH
            } else if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
                description += '\nAccording to [git-clone-depth](https://docs.travis-ci.com/user/customizing-the-build#git-clone-depth), Travis CI provide a way to shallow clone a repository. This has the obvious benefit of speed, since you only need to download a small number of commits.\n'
                outFilePaths << Util.TRAVIS_SHALLOW_CLONE_LIST_PATH
            } else if (strategy == TravisStrategy.TRAVIS_RETRY) {
                description += '\nDoes travis_retry really solve the build issues? According to the data in paper [An empirical study of the long duration of continuous integration builds](https://dl.acm.org/doi/10.1007/s10664-019-09695-9), travis_retry can only solve 3% of the build failures. And it may cause unstable build and increase build time.\n'
                outFilePaths << Util.TRAVIS_RETRY_LIST_PATH
            } else if (strategy == TravisStrategy.TRAVIS_WAIT) {
                description += '\nAccording to [Build times out because no output was received](https://docs.travis-ci.com/user/common-build-problems/#build-times-out-because-no-output-was-received), we should carefully use travis_wait, as it may make the build unstable and extend the build time.\n'
                outFilePaths << Util.TRAVIS_WAIT_LIST_PATH
            } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
                description += '\nAccording to the official document [Fast Finishing](https://docs.travis-ci.com/user/build-matrix/#fast-finishing), if some rows in the build matrix are allowed to fail, we can add fast_finish: true to the .travis.yml to get faster feedbacks.\n'
                outFilePaths << Util.TRAVIS_FAST_FINISH_LIST_PATH
            }
        }
        description += '\n=====================\nIf there are any inappropriate modifications in this PR, please give me a reply and I will change them.\n'
        return [title, description, outFilePaths]
    }

    static StateFlag useTravisStrategy(String originRepoName, String ymlFilePath, TravisStrategy strategy) {
        String contentFilePath = null
        if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
            contentFilePath = Util.TRAVIS_SHALLOW_CLONE_LIST_PATH
        } else if (strategy == TravisStrategy.TRAVIS_RETRY) {
            contentFilePath = Util.TRAVIS_RETRY_LIST_PATH
        } else if (strategy == TravisStrategy.TRAVIS_WAIT) {
            contentFilePath = Util.TRAVIS_WAIT_LIST_PATH
        } else if (strategy == TravisStrategy.TRAVIS_CACHE) {
            contentFilePath = Util.TRAVIS_CACHE_LIST_PATH
        } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
            contentFilePath = Util.TRAVIS_FAST_FINISH_LIST_PATH
        }
        File contentFile = new File(contentFilePath)
        String content = contentFile.exists() ? contentFile.text : ""
        if (content.contains(originRepoName) && originRepoName != 'ChenZhangg/CILink')
            return null

//        if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
////            def shallowCloneValue = TravisChecker.shallowCloneCheck(ymlFilePath)
////            if (shallowCloneValue == null) {
////                return true
////            }
//            //暂时不提交这个策略
//            return false
//        } else if (strategy == TravisStrategy.TRAVIS_RETRY) {
//            List<String> travisRetryResult = TravisChecker.retryCheck(ymlFilePath)
//            if (travisRetryResult.size() > 0) {
//                return true
//            }
//        } else if (strategy == TravisStrategy.TRAVIS_WAIT) {
//            List<Integer> travisWaitResult = TravisChecker.waitCheck(ymlFilePath)
//            if (travisWaitResult.size() > 0) {
//                return true
//            }
//        } else if (strategy == TravisStrategy.TRAVIS_CACHE) {
//            def result = TravisChecker.cacheCheck(ymlFilePath)
//            if (result == null) {
//                return true
//            }
//        } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
//            def  (allow_failures, fast_finish) = TravisChecker.fastFinishCheck(ymlFilePath)
//            if (allow_failures == true && fast_finish == null) {
//                return true
//            }
//        }
        TravisChecker checker = new TravisChecker(ymlFilePath)
        return checker.check(strategy)
    }

    static Map<TravisStrategy, StateFlag> getTravisStrategies(Repository repository,String repoPath, String originRepoName, List<TravisStrategy> strategies) {
        Map<TravisStrategy,StateFlag> strategyWithFlag = new HashMap<>()
        String ymlFilePath = Paths.get(repoPath, ".travis.yml").normalize().toString()
        strategies.each{strategy->
            def flag = useTravisStrategy(originRepoName, ymlFilePath, strategy)
            if(flag!=null){
                strategyWithFlag.put(strategy,flag)
            }
        }
        return strategyWithFlag
    }

    static void applyFix(String repoPath, Repository repository, Map<TravisStrategy,StateFlag> strategyWithFlag) {
        String travisFilePath = Paths.get(repoPath, ".travis.yml")
        File travisFile = new File(travisFilePath)
        if (!travisFile.exists()) {
            throw new Exception("不存在文件${travisFilePath}}")
        }
        TravisFixer fixer = new TravisFixer(travisFilePath)
        fixer.travisSmellFixer(strategyWithFlag,repository.buildTool)
    }

    static void createTravisPullRequest() {
        File file = new File(Util.TRAVIS_CACHE_LIST_PATH)
        String cacheContent = file.exists() ? file.text : ""
        List<Repository> repositories = MysqlUtil.getRepositories()
        List<String> spRepoNames = ['oshi/oshi', 'java-native-access/jna']
        for (Repository repository : repositories) {
            String repoName = repository.repoName
            //提交过shall clone的项目暂时不发pull request 后续会删除该语句
            //if (shallowCloneContent.contains(repoName))
            //    continue

            if (repository.id <= 83541) {//4945
                continue
            }
            if (cacheContent.contains(repoName) || spRepoNames.contains(repoName))
                continue

            if (/*repository.getTravisGitDepth() == null || repository.getTravisRetry() || repository.getTravisWait() || */repository.getTravisCache() == null /*|| (repository.getTravisAllowFailures() && repository.getTravisFastFinish() == null)*/) {
                println("开始处理项目${repository.id}: ${repoName}")
                try {
                    run(repository, null)
                } catch (Exception e){
                    e.printStackTrace()
                }
                println("处理完项目${repository.id}: ${repoName}")
            }
        }
    }

    static void main(String[] args) {
        //Travis的smell中 cache、fast finish、shallow clone分显式引入和隐式引入
        // wait和retry都只有显式引入
        createTravisPullRequest()
    }
}
