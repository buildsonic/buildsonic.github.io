import model.Repository
import smell.checker.TravisChecker
import smell.fixer.TravisFixer
import util.MysqlUtil
import util.Util
import java.nio.file.Paths
import util.TravisUtil.TravisStrategy
import static PullRequestCreator.*

class PullRequestTravisCreator {


    static Boolean run(Repository repository, List<TravisStrategy> strategies) {
        def repoInfos = initGitAndRepo(repository,"TRAVIS")
        def (repoPath,originRepoName, branchName, defaultBranchName, branchSuffix) = repoInfos

        def onlyStrategies = pullRequestExist(repository.repoName,strategies)
        if(onlyStrategies==null){
            return false
        }

        checkAndFix(repository,repoPath,onlyStrategies)

        return pushAndMakePullRequest(repoInfos,onlyStrategies)
    }

    static void checkAndFix(Repository repository, String repoPath, List<TravisStrategy> onlyStrategies){
        String ymlFilePath = Paths.get(repoPath, ".travis.yml").normalize().toString()
        if(!new File(ymlFilePath).exists()){
            return
        }

        TravisChecker checker = new TravisChecker(ymlFilePath)
        def strategyWithFlag = checker.check()
        if (strategyWithFlag.keySet().size() == 0){
            return
        }

        TravisFixer fixer = new TravisFixer(ymlFilePath,strategyWithFlag,repository.buildTool)
        fixer.fix(onlyStrategies)
    }

    static String getPRTitle(TravisStrategy strategy){
        def cachingTitles = [
                'How about turning on the Travis CI Cache feature',
                'Enable caching for Travis CI build',
                'The cache of Travis CI can improve build performance',
                'Build times can be reduced by cache in Travis',
        ]
        int randomNum = new Random().nextInt(4)
        if(strategy== TravisStrategy.TRAVIS_CACHE){
            return cachingTitles[randomNum]
        }
        return ""
    }
    //[Caching Dependencies and Directories](https://docs.travis-ci.com/user/caching/) Travis CI can cache content that does not often change, to speed up the build process.

    static List<String> getDescription(List<TravisStrategy> strategies) {
        String title = getPRTitle(strategies[0])
        title = title==""?'Improve Travis CI build Performance':title
        String description = ""
        List<String> outFilePaths = []
        for (TravisStrategy strategy : strategies) {
            outFilePaths << Util.getPullRequestListFilePath(strategy)
            if (strategy == TravisStrategy.TRAVIS_CACHE) {
                description += "\n[Caching Dependencies and Directories](https://docs.travis-ci.com/user/caching/) Travis CI can cache content that does not often change, to speed up the build process.\n"
            } else if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
                description += '\nAccording to [git-clone-depth](https://docs.travis-ci.com/user/customizing-the-build#git-clone-depth), Travis CI provide a way to shallow clone a repository. This has the obvious benefit of speed, since you only need to download a small number of commits.\n'
            } else if (strategy == TravisStrategy.TRAVIS_RETRY) {
                description += '\nDoes travis_retry really solve the build issues? According to the data in paper [An empirical study of the long duration of continuous integration builds](https://dl.acm.org/doi/10.1007/s10664-019-09695-9), travis_retry can only solve 3% of the build failures. And it may cause unstable build and increase build time.\n'
            } else if (strategy == TravisStrategy.TRAVIS_WAIT) {
                description += '\nAccording to [Build times out because no output was received](https://docs.travis-ci.com/user/common-build-problems/#build-times-out-because-no-output-was-received), we should carefully use travis_wait, as it may make the build unstable and extend the build time.\n'
            } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
                description += '\nAccording to the official document [Fast Finishing](https://docs.travis-ci.com/user/build-matrix/#fast-finishing), if some rows in the build matrix are allowed to fail, we can add fast_finish: true to the .travis.yml to get faster feedbacks.\n'
            }
        }
        description += '\n=====================\nIf there are any inappropriate modifications in this PR, please give me a reply and I will change them.\n'
        return [title, description, outFilePaths]
    }


    static List<Repository> getTestTimeRepositories(){
        List<Repository> repositories = MysqlUtil.getRepositories()
        def cacheRepositories = []
        for(Repository repository :repositories ){
            if(repository.travisCache!=null && !repository.travisCache){
                cacheRepositories << repository
            }
        }
        return cacheRepositories
    }

    static Boolean createTravisPullRequest(Repository repository,List<TravisStrategy> strategies){
        try {
            return run(repository,strategies)
        } catch (Exception e) {
            e.printStackTrace()
        }
        return null
    }

    static void createTravisPullRequest() {
        for (Repository repository : MysqlUtil.getRepositories()) {
            String repoName = repository.repoName
            try {
                def PRCreated = createTravisPullRequest(repository, TravisStrategy.values().toList())
                if(PRCreated){
                    goSleep()
                }
            } catch (Exception e){
                e.printStackTrace()
            }
        }
    }


    static void main(String[] args) {
//        createTravisPullRequest()
    }
}
