import model.Repository
import smell.StateFlag
import smell.checker.TravisChecker
import smell.checker.gradle.GradleChecker
import smell.checker.maven.MavenChecker
import util.*

import java.nio.file.Paths

import static util.MavenUtil.*
import static util.GradleUtil.*
import static util.TravisUtil.*

/**
 * 创建一个固定Github仓库:86 zc/Performance，用于触发Travis CI
 * 项目的PR状态：merged / notMerged
 * merged：../sequence/fork中到找相应的仓库，切换到默认分支
 * notMerged: 解压对应的codeZIP，将其中的文件复制到TravisTrigger仓库
 *
 */
class TravisTrigger {
    static void run(String repoInfo, Object strategy, Boolean isMerged) {
        // 1.初始化触发仓库
        TriggerUtil.initTravisTriggerRepo(repoInfo,isMerged)
        String originRepoName = isMerged?TriggerUtil.urlToRepo(repoInfo)[0]:repoInfo   // owner/repo

        // 2.没有修复smell的code push到github，触发travis ci
        // 如果存在该repo的原始代码的build,可以跳过
        String commitMessageOfOriginal = "Original code: ${originRepoName}"
        GitUtil.addAndCommit(Util.TravisTriggerRepoPath, commitMessageOfOriginal)
        HubUtil.push(Util.TravisTriggerRepoPath, 'master')

        // 3.根据strategy修复code
        if(strategy.class.simpleName == "TravisStrategy"){
            Repository repository = MysqlUtil.getRepositoryByName(originRepoName)
            String ymlFilePath = Paths.get(Util.TravisTriggerRepoPath,'.travis.yml')
            TravisChecker checker = new TravisChecker(ymlFilePath)
            def flag = checker.check((TravisStrategy)strategy)
            Map<TravisStrategy,StateFlag> strategyWithFlag = [(TravisStrategy)strategy:flag]
            PullRequestTravisCreator.applyFix(Util.TravisTriggerRepoPath,repository,strategyWithFlag)

        } else if(strategy.class.simpleName == "GradleStrategy"){
            GradleCategory category = getGradleCategory((GradleStrategy)strategy)
            List<GradleStrategy> strategies = [(GradleStrategy)strategy]
            def flag = GradleChecker.check(Util.TravisTriggerRepoPath,originRepoName,(GradleStrategy)strategy)
            if(flag== StateFlag.CLOSE){
                PullRequestGradleCreator.applyFix(Util.TravisTriggerRepoPath, strategies, category,true)
            }else if(flag== StateFlag.DEFAULT){
                PullRequestGradleCreator.applyFix(Util.TravisTriggerRepoPath, strategies, category,false)
            }

        } else if(strategy.class.simpleName == "MavenStrategy"){
            def flag = MavenChecker.check(Util.TravisTriggerRepoPath,originRepoName,(MavenStrategy)strategy)
            if(flag== StateFlag.CLOSE){
                PullRequestMavenCreator.applyFix(Util.TravisTriggerRepoPath, originRepoName,(MavenStrategy)strategy,true)
            }else if(flag== StateFlag.DEFAULT){
                PullRequestMavenCreator.applyFix(Util.TravisTriggerRepoPath, originRepoName,(MavenStrategy)strategy,false)
            }
        }

        // 4.将修复后的code push到github，触发travis ci
        String commitMessageOfStrategy = "${strategy.toString()}:${originRepoName}"
        GitUtil.addAndCommit(Util.TravisTriggerRepoPath, commitMessageOfStrategy)
        HubUtil.push(Util.TravisTriggerRepoPath, 'master')
    }

    static List<Object> getAllStrategy(){
        List<Object> strategies = new ArrayList<>()
        for(GradleStrategy strategy: GradleStrategy.values()){
            strategies << strategy
        }
        for(MavenStrategy strategy: MavenStrategy.values()){
            strategies << strategy
        }
        for(TravisStrategy strategy: TravisStrategy.values()){
            strategies << strategy
        }
        return strategies
    }


    static void createTrigger(){
       def strategies = getAllStrategy()
       for(Object strategy : strategies){
           def (notMergedRepo, mergedRepo) = TriggerUtil.getReposBySmell(strategy.toString())
           for(String repoName : notMergedRepo){
               run(repoName, strategy, false)   // repoName: owner/repo
           }
           for(String repoURL : mergedRepo){
               run(repoURL, strategy, true)     // repoName:https://github.com/{owner/repo}/pull/{number}
           }
       }

    }

    static void main(String[] args) {
//        TriggerUtil.preparation()
//        createTrigger()
    }
}
