import model.Repository
import smell.fixer.TravisFixer
import smell.checker.TravisChecker
import util.*

import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern

import static util.MavenUtil.*
import static util.GradleUtil.*
import static util.TravisUtil.*


class TravisTrigger {
    static void run(String repoInfo, Object strategy, Boolean isMerged) {
        def (originRepoName, pulls) = TriggerUtil.urlToRepo(repoInfo)  // owner/repo + pulls
        def triggerRepoPath = Util.getTriggerRepoPath(strategy)
        if(!new File(triggerRepoPath).exists()){
            return
        }

        String originBranch = "${originRepoName}-${pulls}-origin"
        def originBranchExit =  GitUtil.CheckoutAndCreate(triggerRepoPath,originBranch,"master")
        if (originBranchExit==null){
            return
        }
        if (!originBranchExit){
            boolean init = TriggerUtil.initTravisTriggerRepo(triggerRepoPath,repoInfo,originRepoName,isMerged)
            if(!init){
                return
            }
            sleep(1000*5)
            TravisFixer travisFixer = new TravisFixer(Paths.get(triggerRepoPath,'.travis.yml').normalize().toString())
            travisFixer.updateBranches(originBranch)
            sleep(1000*5)
            String commitMessageOfOrigin = "${originRepoName}:original code"
            GitUtil.addAndCommit(triggerRepoPath, commitMessageOfOrigin)
            HubUtil.push(triggerRepoPath, originBranch)
            sleep(1000*60)
        }else{
            sleep(1000*5)
        }

        String smellBranch = "${originRepoName}-${pulls}-${strategy.toString()}"
        GitUtil.CheckoutAndCreate(triggerRepoPath,smellBranch,originBranch)

        Repository repository = MysqlUtil.getRepositoryByName(originRepoName)
        if(strategy instanceof TravisStrategy){
            PullRequestTravisCreator.checkAndFix(repository,triggerRepoPath,[strategy])

        } else if(strategy instanceof GradleStrategy){
            PullRequestGradleCreator.checkAndFix(repository,triggerRepoPath,[strategy])

        } else if(strategy instanceof MavenStrategy){
            PullRequestMavenCreator.checkAndFix(repository,triggerRepoPath,[strategy])
        }

        sleep(1000*5)
        TravisFixer travisFixer = new TravisFixer(Paths.get(triggerRepoPath,'.travis.yml').normalize().toString())
        travisFixer.updateBranches(smellBranch)
        sleep(1000*5)
        String commitMessageOfStrategy = "${originRepoName}:fixed ${strategy.toString()}"
        GitUtil.addAndCommit(triggerRepoPath, commitMessageOfStrategy)
        HubUtil.push(triggerRepoPath, smellBranch)
    }

    static Integer getGitDepth(String repoInfo, boolean isMerged){
        String originRepoPath = isMerged?TriggerUtil.initTriggerIsMerged(repoInfo):TriggerUtil.initTriggerNotMerged(repoInfo)
        String ymlFilePath = Paths.get(originRepoPath, ".travis.yml").normalize().toString()
        println(originRepoPath)
        if(!new File(ymlFilePath).exists()){
            return null
        }
        TravisChecker checker = new TravisChecker(ymlFilePath)
        def depth = checker.shallowCloneValue()
        if(depth==50){
            return 49
        }
        if(depth==null || depth==-1){
            return 50
        }
        return depth
    }

    static Double getCloneTime(String repoName, int depth){
        String repoPah = Paths.get(Util.gitDepthTestPath,repoName.split('/')[1]).normalize().toString()
        if(new File(repoPah).exists()){
            def rmRepo = "rm -rf ${repoPah}".execute()
            rmRepo.waitFor()
        }
        def cloneCommand = "time git clone -q --depth ${depth} git@github.com:${repoName}.git"
        def cloneExecute = cloneCommand.execute(null,new File(Util.gitDepthTestPath))
        def out = new StringBuffer()
        def error = new StringBuffer()
        cloneExecute.waitForProcessOutput(out,error)
        Pattern pattern = ~/(.*)system(.*)elapsed(.*)/
        Matcher matcher = pattern.matcher(error.toString().trim())
        if(matcher.find()){
            String elapsed = matcher.group(2)   // 0:22.38
            double cloneTime = (elapsed.split(':')[0].toInteger())*60 + elapsed.split(':')[1].toDouble()
            return cloneTime
        }
        return null
    }

    static void shallowCloneTrigger(List<String> reposInfo){
        Map<String,List<Double>> repoCloneInfos = new HashMap<>()
        reposInfo.each {repoInfo->
            boolean isMerged = repoInfo.startsWith("https://github.com")
            String originRepoName = isMerged?TriggerUtil.urlToRepo(repoInfo)[0]:repoInfo
            def depth = getGitDepth(repoInfo,isMerged)
            if(depth < 50){
                return true
            }
            def originalCloneTime = getCloneTime(originRepoName,depth)
            def fixedCloneTime = getCloneTime(originRepoName,3)
            repoCloneInfos.put(originRepoName,[originalCloneTime,fixedCloneTime])
        }
        repoCloneInfos.each {repoName,cloneTimes->
            println(repoName+":"+cloneTimes[0]+"  "+cloneTimes[1])
        }
    }


    static void createTrigger(Object strategy){
        def (notMergedPR, mergedPR) = TriggerUtil.getPRUrlBySmell(strategy.toString())
        println("notMergedRepo size : "+notMergedPR.size())
        println("mergedRepo size : "+mergedPR.size())


        for(String PRUrl : notMergedPR){
            try{
                run(PRUrl, strategy, false)
            }catch (Exception e){
                e.printStackTrace()
            }
            sleep(1000*60)
        }
        for(String PRUrl : mergedPR){
            try{
                run(PRUrl, strategy, false)
            }catch (Exception e){
                e.printStackTrace()
            }
            sleep(1000*60)
        }
    }


    static void travisSmellTrigger(){
        createTrigger(TravisStrategy.TRAVIS_FAST_FINISH)
        createTrigger(TravisStrategy.TRAVIS_CACHE)
    }

    static void threadRun(){
//        TriggerUtil.preparation()

        def gradleBuilds = [
                GradleStrategy.GRADLE_COMPILER_DAEMON,
                GradleStrategy.GRADLE_INCREMENTAL_COMPILATION,
                GradleStrategy.GRADLE_FORK_TEST,
                GradleStrategy.GRADLE_REPORT_GENERATION,
        ]
        def gradleProperties = [
                                GradleStrategy.GRADLE_FILE_SYSTEM_WATCHING,
                                GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND,
                                GradleStrategy.GRADLE_PARALLEL_BUILDS,
                                GradleStrategy.GRADLE_DAEMON]
        def gradleSmells = [gradleBuilds,gradleProperties]

        def mavenTest = [MavenStrategy.MAVEN_PARALLEL_TEST,MavenStrategy.MAVEN_REPORT_GENERATION,MavenStrategy.MAVEN_FORK_TEST]
        def mavenCompile = [ MavenStrategy.MAVEN_PARALLEL_EXECUTION,MavenStrategy.MAVEN_COMPILER_DAEMON]
        def mavenSmells = [mavenTest, mavenCompile]

        def smells = gradleSmells + mavenSmells
        smells.each {strategies->
            Thread.start {
                strategies.each {strategy->
                    createTrigger(strategy)
                }
            }
        }
    }

    static void main(String[] args) {
//        threadRun()
    }
}
