package parser

import groovy.json.JsonSlurper
import model.Repository
import util.MysqlUtil
import util.Util

import java.nio.file.Paths


class OptionParser {
    String repoPath
    String originRepoName
    Map<String, Object> options = new HashMap<>()

    OptionParser(String repoPath){
        this.repoPath = repoPath
    }
    OptionParser(String repoPath, String originRepoName) {
        this.repoPath = repoPath
        this.originRepoName = originRepoName
    }

    enum FileType {
        YAML, SHELL, PROPERTIES
    }

    Map<String, Object> getOptions() {
        if (this.options.size() > 0)
            return this.options
        List<String> yml = getYamlBuildCommands()
        options.put(FileType.YAML, yml)
        List<String> shell = getShellBuildCommands()
        options.put(FileType.SHELL, shell)
        Map<String, String> properties = parseGradleProperties()
        options.put(FileType.PROPERTIES, properties)
        return this.options
    }

    def getGradleOptions() {
        List<String> yamlGradleCommands = getYamlGradleBuildCommands()
        List<String> shellGradleCommands = getShellBuildCommands()
        shellGradleCommands.removeIf {!it.contains("gradle")}
        Map<String, String> gradleProperties = parseGradleProperties()
        return [yamlGradleCommands,  shellGradleCommands, gradleProperties]
    }

    List<String> getYamlBuildCommands() {
        String ymlFilePath = Paths.get(this.repoPath, ".travis.yml").normalize().toString()
        //println(ymlFilePath)
        LinkedHashMap<String, Object> map = YmlParser.parse(ymlFilePath)
        List<String> commands = YmlParser.getCommands(map)
        List<String> result = []
        commands.each {
            if (it.contains("mvn") || it.contains("gradle"))
                result << it
        }
        return result
    }

    List<String> getYamlMavenBuildCommands() {
        List<String> commands = getYamlBuildCommands()
        commands.removeIf {!it.contains("mvn")}
        return commands
    }

    List<String> getYamlGradleBuildCommands() {
        List<String> commands = getYamlBuildCommands()
        commands.removeIf {!it.contains("gradle")}
        return commands
    }

    void extractAndStoreShell() {
        String pyDir = Paths.get(System.getProperty("user.dir"), "py").normalize().toString()
        List<String> shellFilePaths = Util.getShellFilePaths(this.repoPath)
        if (shellFilePaths.size() == 0)
            return
        List<String> com = ["python", "shell_parser.py"] + shellFilePaths
        Process process = com.execute(null, new File(pyDir))
        process.waitForProcessOutput(System.out, System.err)
    }

    List<String> getShellBuildCommands() {
        List<String> list= []
        String filePath = Paths.get(System.getProperty("user.dir"), "resources", "shellCommandJson", this.originRepoName.replace('/', '@') + '.json').normalize().toString()
        File file = new File(filePath)
        if (file.exists() == false)
            return list
        def object = new JsonSlurper().parseText(file.text)
        object.each {
            list << it["command"]["command"]
        }
        return list
    }

    Map<String, List<String>> getShellBuildCommandsMap() {
        Map<String, List<String>> map = new LinkedHashMap<>()
        String filePath = Paths.get(System.getProperty("user.dir"), "resources", "shellCommandJson", this.originRepoName.replace('/', '@') + '.json').normalize().toString()
        File file = new File(filePath)
        if (file.exists() == false)
            return map

        def object = new JsonSlurper().parseText(file.text)
        object.each {
            if (map.get(it['filePath']) == null) {
                map.put(it['filePath'], [])
            }
            map.get(it['filePath']) << it["command"]["command"]
        }
        return map
    }

    Map<String, String> parseGradleProperties() {
        String filePath = Paths.get(this.repoPath, "gradle.properties").normalize().toString()
        File file = new File(filePath)
        if (file.exists() == false)
            return [:]
        Properties properties = new Properties()
        file.withInputStream {
            properties.load(it)
        }
        return properties
    }

    static void main(String[] args) {
    }
}
