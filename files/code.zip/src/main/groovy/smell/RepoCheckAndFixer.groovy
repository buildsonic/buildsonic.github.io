package smell

import com.mysql.cj.log.Log
import groovy.io.FileType
import model.Repository
import org.codehaus.groovy.ast.expr.BinaryExpression
import parser.GradleParser
import parser.GradleVisitor
import parser.OptionParser
import parser.YmlParser
import smell.checker.CheckerUpdate
import smell.checker.TravisChecker
import smell.checker.gradle.BuildGradleChecker
import smell.checker.gradle.GradleChecker
import smell.checker.gradle.GradlePropertyChecker
import smell.checker.maven.MavenChecker
import smell.fixer.Gradle.GradleFixer
import smell.fixer.Maven.MavenFixer
import smell.fixer.Maven.ParallelBuildFixer
import smell.fixer.TravisFixer
import util.MysqlUtil

import java.util.regex.Pattern

import static util.TravisUtil.*
import static util.MavenUtil.*
import static util.GradleUtil.*
import util.TriggerUtil
import util.Util

import java.nio.file.Paths

class RepoCheckAndFixer {
    String repoPath
    String repoName
    int buildTool

    String ymlFilePath
    Map<TravisStrategy,StateFlag> TravisStrategyWithFlag = new HashMap<>()
    Map<String,Map<MavenStrategy,StateFlag>> MavenCheckedFileWithStrategy = new HashMap<>()
    Map<String,Map<GradleStrategy,StateFlag>> GradleCheckedFileWithStrategy = new HashMap<>()

    Map<Object,StateFlag> AllSmellsWithFlag = new HashMap<>()
    Map<String,Map<Object,StateFlag>> AllCheckedFileWithStrategy = new HashMap<>()

    RepoCheckAndFixer(String repoPath, String originRepoName, int buildTool) {
        this.repoPath = repoPath
        this.repoName = originRepoName
        this.buildTool = buildTool
        this.ymlFilePath = Paths.get(repoPath, ".travis.yml").normalize().toString()
    }

    void checkAndFix(){
        check()
        fix()
    }

    void check(){
        checkTravis()

        if(this.buildTool == 1){
            this.MavenCheckedFileWithStrategy = MavenChecker.check(this.repoPath, this.repoName)
        }else if(this.buildTool == 2 ){
            this.GradleCheckedFileWithStrategy = GradleChecker.check(this.repoPath, this.repoName)
        }
    }

    void checkTravis(){
        if(!new File(ymlFilePath).exists()){
            println("There is no .travis.yml file")
            return
        }

        TravisChecker checker = new TravisChecker(ymlFilePath)
        this.TravisStrategyWithFlag =  checker.check()
    }

    void fix(){
        if(new File(this.ymlFilePath).exists()){
            TravisFixer travisFixer = new TravisFixer(ymlFilePath,TravisStrategyWithFlag,buildTool)
            travisFixer.fix()
        }

        if(this.buildTool == 1){
            MavenFixer mavenFixer = new MavenFixer(repoPath,repoName,MavenCheckedFileWithStrategy)
            mavenFixer.fix()
        }else if(this.buildTool == 2 ){
            GradleFixer gradleFixer = new GradleFixer(repoPath,repoName,GradleCheckedFileWithStrategy)
            gradleFixer.fix()
        }
    }

    void parse(){
        initAllSmellsWithFlag()
        AllCheckedFileWithStrategy()
    }

    void AllCheckedFileWithStrategy(){
        Closure filtrateOpenSmell = { Object strategy, StateFlag flag->
            if( flag == StateFlag.OPEN){
                return false
            }
            return true
        }
        CheckerUpdate.removeTwoLayersMapElement(this.MavenCheckedFileWithStrategy,filtrateOpenSmell)
        CheckerUpdate.removeTwoLayersMapElement(this.GradleCheckedFileWithStrategy,filtrateOpenSmell)
        Map<String,Map<TravisStrategy,StateFlag>> TravisCheckedFileWithStrategy = [(this.ymlFilePath):this.TravisStrategyWithFlag]
        CheckerUpdate.removeTwoLayersMapElement(TravisCheckedFileWithStrategy,filtrateOpenSmell)

        this.AllCheckedFileWithStrategy.putAll(MavenCheckedFileWithStrategy)
        this.AllCheckedFileWithStrategy.putAll(GradleCheckedFileWithStrategy)
        this.AllCheckedFileWithStrategy.putAll(TravisCheckedFileWithStrategy)
    }

    void initAllSmellsWithFlag(){
         this.AllSmellsWithFlag.putAll(TravisStrategyWithFlag)

         Closure putAllToMap = { Map<Object,StateFlag> strategyWithFlag->
             strategyWithFlag.each{strategy,flag->
                 if(!AllSmellsWithFlag.containsKey(strategy) || AllSmellsWithFlag[strategy] == StateFlag.DEFAULT){
                     AllSmellsWithFlag.put(strategy,flag)
                 }
                 if(AllSmellsWithFlag[strategy] == StateFlag.OPEN && flag==StateFlag.CLOSE){
                     AllSmellsWithFlag.put(strategy,flag)
                 }
             }
         }

         MavenCheckedFileWithStrategy.each {filePath,strategyWithFlag->
             putAllToMap.call(strategyWithFlag)
         }

         GradleCheckedFileWithStrategy.each {filePath,strategyWithFlag->
             putAllToMap.call(strategyWithFlag)
         }

    }



    static Boolean run(Repository repository){
        String fixFileSavePath = Paths.get(Util.CheckAndFixDirectoryPath,repository.repoName.replace('/','@')).normalize().toString()
        File fixFileSaveDir = new File(fixFileSavePath)
        if(fixFileSaveDir.exists()){
            fixFileSaveDir.delete()
            new File(fixFileSavePath).createNewFile()
        }
        String repoPath = Paths.get(Util.codeDirectoryPath,repository.repoName.replace('/','@')).normalize().toString()

        RepoCheckAndFixer repoCheckAndFixer = new RepoCheckAndFixer(repoPath,repository.repoName,repository.buildTool)

        def start = System.currentTimeMillis()
        repoCheckAndFixer.check()
        def checkTime = System.currentTimeMillis() - start


        repoCheckAndFixer.parse()
        Map<Object,StateFlag> AllSmellsWithFlag = repoCheckAndFixer.AllSmellsWithFlag
        Map<String,Map<Object,StateFlag>> AllCheckedFileWithStrategy = repoCheckAndFixer.AllCheckedFileWithStrategy

        printSmellInfo(AllSmellsWithFlag,repository)

        start = System.currentTimeMillis()
        repoCheckAndFixer.fix()
        def fixTime = System.currentTimeMillis() - start

        println("check time :" + checkTime)
        println("fix time :" + fixTime)
        return true
    }

    static void printSmellInfo(Map<Object,StateFlag> AllSmellsWithFlag, Repository repository){
        def TravisSmellWithFlag = CheckerUpdate.travisSmellsChecker(repository)
        for(TravisStrategy strategy:TravisStrategy.values()){
            print("${strategy} : ${AllSmellsWithFlag.get(strategy)} || ${TravisSmellWithFlag.get(strategy)}")
            if(AllSmellsWithFlag.get(strategy) != TravisSmellWithFlag.get(strategy) ){
                println("    error")
            }else{
                println()
            }
        }
        if(repository.buildTool==1){

            def MavenSmellWithFlag = CheckerUpdate.mavenSmellsChecker(repository)
            for(MavenStrategy strategy:MavenStrategy.values()){
                print("${strategy} : ${AllSmellsWithFlag.get(strategy)} || ${MavenSmellWithFlag.get(strategy)}")
                if(AllSmellsWithFlag.get(strategy) != MavenSmellWithFlag.get(strategy) ){
                    println("    error")
                }else{
                    println()
                }
            }

        }else{

            def GradleSmellWithFlag = CheckerUpdate.gradleSmellsChecker(repository)
            for(GradleStrategy strategy:GradleStrategy.values()){
                print("${strategy} : ${AllSmellsWithFlag.get(strategy)} || ${GradleSmellWithFlag.get(strategy)}")
                if(AllSmellsWithFlag.get(strategy) != GradleSmellWithFlag.get(strategy) ){
                    println("    error")
                }else{
                    println()
                }
            }
        }
    }


    static void copy(List<String> srcFilePaths, String scrDirPath, String destDirPath) {
        if(srcFilePaths.size() == 0){
            return
        }

        def destDir = new File(destDirPath)
        if (!destDir.exists()) {
            destDir.mkdirs()
        }

        srcFilePaths.each {srcFilePath->
            File srcFile = new File(srcFilePath)
            String relativePath = srcFilePath.substring(scrDirPath.length())
            if (relativePath.startsWith('/')){
                relativePath = relativePath.substring(1)
            }

            String destFilePath = Paths.get(destDirPath,relativePath.replace('/','@')).normalize().toString()
            File destFile = new File(destFilePath)
            if(!destFile.exists()){
                destFile.createNewFile()
            }
            try{
                srcFile.withDataInputStream {input ->
                    destFile.withDataOutputStream {
                        output -> output << input
                    }
                }
            }catch (Exception e){
                println(e.toString())
            }
        }
    }

    static void run(){
        def failed = []
        def error = []
        for(Repository repository: MysqlUtil.getRepositories()){
            if(repository.buildTool!=2){
                continue
            }
            println("处理项目${repository.repoName}")
            try{
               def ok = run(repository)
                if(ok==null||!ok){
                    failed << repository.repoName
                }
            }catch (Exception e){
                println(e.toString())
                error << repository.repoName
            }
            println("")
        }
        failed.each {println(it)}
        error.each {println(it)}
    }

    static void main(String[] args) {
    }
}
