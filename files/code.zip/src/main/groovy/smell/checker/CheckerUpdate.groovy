package smell.checker

import model.Repository
import org.hibernate.Session
import org.hibernate.Transaction
import smell.StateFlag
import smell.checker.gradle.BuildGradleChecker
import smell.checker.maven.POMChecker
import smell.checker.maven.TestChecker
import util.MysqlUtil
import util.SessionUtil
import util.Util

import java.nio.file.Paths

import static util.GradleUtil.*
import static util.MavenUtil.*

class CheckerUpdate {

    static void updateGradleSmell() throws Exception{
        List<GradleStrategy>  gradleStrategies = [GradleStrategy.GRADLE_PARALLEL_TEST,
                                                  GradleStrategy.GRADLE_FORK_TEST,
                                                  GradleStrategy.GRADLE_REPORT_GENERATION,
                                                  GradleStrategy.GRADLE_COMPILER_DAEMON,
                                                  GradleStrategy.GRADLE_INCREMENTAL_COMPILATION]
        for(GradleStrategy gradleStrategy : gradleStrategies){
            BuildGradleChecker.check(gradleStrategy)
        }
    }

    static void updateMavenSmell() throws Exception{
        List<MavenStrategy> mavenStrategies =[MavenStrategy.MAVEN_PARALLEL_TEST,
                                              MavenStrategy.MAVEN_FORK_TEST,
                                              MavenStrategy.MAVEN_REPORT_GENERATION,
                                              MavenStrategy.MAVEN_COMPILER_DAEMON,
                                              MavenStrategy.MAVEN_INCREMENTAL_COMPILATION]

        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction()
            List<Repository> repositories = MysqlUtil.getRepositories(session)
            for (Repository repository : repositories) {
                if (repository.buildTool == 1) {
                    try {
                        POMChecker checker = new TestChecker(repository)
                        Map<MavenStrategy, StateFlag> map = checker.check(mavenStrategies)
                        for(MavenStrategy strategy:map.keySet()){
                            if(strategy == MavenStrategy.MAVEN_PARALLEL_TEST){
                                repository.setParallelTest(map.get(strategy).getValue())
                            }
                            else if(strategy == MavenStrategy.MAVEN_FORK_TEST){
                                repository.setMavenForkTest(map.get(strategy).getValue())
                            }
                            else if(strategy == MavenStrategy.MAVEN_REPORT_GENERATION){
                                repository.setMavenReportGeneration(map.get(strategy).getValue())
                            }
                            else if(strategy == MavenStrategy.MAVEN_COMPILER_DAEMON){
                                repository.setMavenCompilerDaemon(map.get(strategy).getValue())
                            }
                            else if(strategy == MavenStrategy.MAVEN_INCREMENTAL_COMPILATION){
                                repository.setMavenIncrementalCompilation(map.get(strategy).getValue())
                            }
                        }
                    } catch (Exception e) {
                        println("error repository_id: " + repository.getId())
                        e.printStackTrace()
                    }
                }
            }
            tx.commit()
        }
    }

    static void getTravisCache(){
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction()
            List<Repository> repositories = MysqlUtil.getRepositories(session)
            for (Repository repository : repositories) {
                String repoPath = Paths.get(Util.codeDirectoryPath, repository.getRepoName().replace("/", "@")).toString()
                String ymlFilePath = Paths.get(repoPath, ".travis.yml")
                File ymlFile = new File(ymlFilePath)
                if (!ymlFile.exists()) {
                    throw new Exception("不存在文件${ymlFilePath}}")
                }
                println(repository.getRepoName()+"的Cache情况：")
                TravisChecker.cacheCheck(ymlFilePath)
                println("")
            }
            tx.commit()
        }
    }

    static void getMavenParallelTest(){
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction()
            List<Repository> repositories = MysqlUtil.getRepositories(session)
            for (Repository repository : repositories) {
                if (repository.getBuildTool() == 1){
                    try{
                        POMChecker checker = new TestChecker(repository)
                        Map<String, String> testConfigurations = checker.rootPom.getTestConfigurations()
                        String parallel = testConfigurations.get("parallel")
                        if (parallel == null){
                            continue
                        }
                        String useUnlimitedThreads = testConfigurations.get("useUnlimitedThreads")
                        String perCoreThreadCount = testConfigurations.get("perCoreThreadCount")
                        String threadCount = testConfigurations.get("threadCount")
                        String threadCountClasses = testConfigurations.get("threadCountClasses")
                        String threadCountMethods = testConfigurations.get("threadCountMethods")
                        String threadCountSuites = testConfigurations.get("threadCountSuites")
                        println(repository.getRepoName())
                        println("<parallel> :" + parallel)
                        println("<useUnlimitedThreads> :" + useUnlimitedThreads)
                        println("<perCoreThreadCount> :" + perCoreThreadCount)
                        println("<threadCount> :" + threadCount)
                        println("<threadCountClasses> :" + threadCountClasses)
                        println("<threadCountMethods> :" + threadCountMethods)
                        println("<threadCountSuites> :" + threadCountSuites)

                        if (useUnlimitedThreads == "false" || useUnlimitedThreads == null){
                            if (perCoreThreadCount=="false"){
                                println("情况1")
                            }
                            if ( threadCount == "0"){
                                println("情况2")
                            }
                            if ( threadCount == "1"){
                                println("情况3")
                            }
                        }
                        println("\n\n")

                    } catch(Exception e) {
                        println("error repository_id: " + repository.getId())
                        e.printStackTrace()
                    }
                }

            }
            tx.commit()
        }
    }

    static void getGradleForkTest(){
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction()
            List<Repository> repositories = MysqlUtil.getRepositories(session)
            for(Repository repository: repositories)
            {
                if(repository.buildTool==2){
                    println(repository.getRepoName())
                    println("gradleReportGeneration字段：" + repository.gradleReportGeneration)
                    BuildGradleChecker.check(repository,GradleStrategy.GRADLE_REPORT_GENERATION)
                }
            }
            tx.commit()
        }
    }

    static void run(){
        int count = 0
        File codeDir = new File(Util.codeDirectoryPath)
        codeDir.listFiles().each {file->
            String path = Paths.get(file.absolutePath,"shellCommandJson").normalize().toString()
            File shellFile = new File(path)
            if(shellFile.exists()){
                println(file.absolutePath)
                count++
            }
            if(count==3){
                return null
            }
        }
    }

    static void main(String[] args) {
        run()
//        println("开始更新Gradle的字段\n")
//        updateGradleSmell()
//        println("开始更新Maven的字段\n")
//        updateMavenSmell()
//        getTravisCache()
//        getMavenParallelTest()
//        getGradleForkTest()
    }
}
