package smell.checker

import model.Repository
import smell.StateFlag
import smell.checker.gradle.GradleChecker
import util.MysqlUtil
import static util.GradleUtil.*
import static util.MavenUtil.*
import static util.TravisUtil.*

class CheckerUpdate {

    static void checkFiled(Map<Object,StateFlag> smellWithFlag, Object strategy, Integer field, Boolean isImplicit){
        if(field == null){
            return
        }

        if(field == 0){
            if(strategy == GradleStrategy.GRADLE_PARALLEL_BUILDS && !isImplicit){
                return
            }
            smellWithFlag.put(strategy,StateFlag.CLOSE)
        }else if(field == 1){
            smellWithFlag.put(strategy,StateFlag.OPEN)
        }else if(isImplicit){
            smellWithFlag.put(strategy,StateFlag.DEFAULT)
        }
    }


    static Map<Object,StateFlag> gradleSmellsChecker(Repository repository){
        if(repository.buildTool!=2){
            return null
        }
        Map<Object,StateFlag> smellWithFlag = new HashMap<>()
        // properties
        checkFiled(smellWithFlag, GradleStrategy.GRADLE_PARALLEL_BUILDS, repository.parallelExecution, repository.multiModule)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_FILE_SYSTEM_WATCHING, repository.fileSystemWatch, GradleChecker.compareVersion(repository.version, "7.0") < 0)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND, repository.configureOnDemand, repository.multiModule)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_DAEMON, repository.gradleDaemon, GradleChecker.compareVersion(repository.version, "3.0") < 0)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_CACHING,repository.gradleCache, true)


        // Build
        checkFiled(smellWithFlag, GradleStrategy.GRADLE_COMPILER_DAEMON, repository.gradleCompilerDaemon, repository.javaFilesNum>=1000)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_INCREMENTAL_COMPILATION, repository.gradleIncrementalCompilation, GradleChecker.compareVersion(repository.version, "4.10") < 0)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_PARALLEL_TEST, repository.parallelTest,  repository.containTest==1)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_REPORT_GENERATION, repository.gradleReportGeneration, repository.containTest==1)

        checkFiled(smellWithFlag, GradleStrategy.GRADLE_FORK_TEST, repository.gradleForkTest, repository.containTest==1)

        return smellWithFlag
    }

    static Map<Object,StateFlag> mavenSmellsChecker(Repository repository){
        if(repository.buildTool!=1){
            return null
        }

        Map<Object,StateFlag> smellWithFlag = new HashMap<>()

        checkFiled(smellWithFlag, MavenStrategy.MAVEN_PARALLEL_EXECUTION, repository.parallelExecution, repository.multiModule)

        checkFiled(smellWithFlag, MavenStrategy.MAVEN_COMPILER_DAEMON, repository.mavenCompilerDaemon, repository.javaFilesNum>=1000)

        checkFiled(smellWithFlag, MavenStrategy.MAVEN_PARALLEL_TEST, repository.parallelTest, repository.containTest==1)

        checkFiled(smellWithFlag, MavenStrategy.MAVEN_REPORT_GENERATION, repository.mavenReportGeneration, repository.containTest==1)

        checkFiled(smellWithFlag, MavenStrategy.MAVEN_FORK_TEST, repository.mavenForkTest, repository.containTest==1)

        return smellWithFlag
    }

    static Map<Object,StateFlag> travisSmellsChecker(Repository repository){
        Map<Object,StateFlag> smellWithFlag = new HashMap<>()

        if(repository.travisCache==null) {
            smellWithFlag.put(TravisStrategy.TRAVIS_CACHE,StateFlag.DEFAULT)
        } else if(repository.travisCache){
            smellWithFlag.put(TravisStrategy.TRAVIS_CACHE,StateFlag.OPEN)
        } else{
            smellWithFlag.put(TravisStrategy.TRAVIS_CACHE,StateFlag.CLOSE)
        }

        if(repository.travisAllowFailures) {
            if (repository.travisFastFinish == null || !repository.travisFastFinish) {
                smellWithFlag.put(TravisStrategy.TRAVIS_FAST_FINISH, StateFlag.CLOSE)
            } else {
                smellWithFlag.put(TravisStrategy.TRAVIS_FAST_FINISH, StateFlag.OPEN)
            }
        }

        if(repository.travisRetry){
            smellWithFlag.put(TravisStrategy.TRAVIS_RETRY, StateFlag.CLOSE)
        }

        if(repository.travisGitDepth != null){
            if(repository.travisGitDepth == 'false'){
                smellWithFlag.put(TravisStrategy.TRAVIS_SHALLOW_CLONE, StateFlag.CLOSE)
            }else if(repository.travisGitDepth.toInteger() >= 50){
                smellWithFlag.put(TravisStrategy.TRAVIS_SHALLOW_CLONE, StateFlag.CLOSE)
            }else{
                smellWithFlag.put(TravisStrategy.TRAVIS_SHALLOW_CLONE, StateFlag.OPEN)
            }
        }


        if(repository.travisWait!=null){
            smellWithFlag.put(TravisStrategy.TRAVIS_WAIT, StateFlag.CLOSE)
        }
        return smellWithFlag
    }

    static List getRandomNumList(int nums,int start,int end){
        List<Integer> randomList = []

        Random random = new Random()
        while(randomList.size() != nums){
            int num = random.nextInt(end-start) + start
            if(!randomList.contains(num)){
                randomList << num
            }
        }

        return randomList
    }


    static void run(){
        Map<Repository, Map<Object,StateFlag> > ReposWithSmells = new HashMap<>()
        int gradleRepoSize = 0
        int mavenRepoSize = 0
        def repositories = MysqlUtil.getRepositories()
        for(int i = 0 ; i< repositories.size() ; i++  ){
            def repository = repositories[i]

            Map<Object,StateFlag> repoSmell = new HashMap<>()

            if(repository.buildTool==2){
                gradleRepoSize++
                def gradleSmells = gradleSmellsChecker(repository)
                def travisSmells = travisSmellsChecker(repository)
                repoSmell.putAll(gradleSmells)
                repoSmell.putAll(travisSmells)
            }else if(repository.buildTool==1){
                mavenRepoSize++
                def mavenSmells = mavenSmellsChecker(repository)
                def travisSmells = travisSmellsChecker(repository)
                repoSmell.putAll(mavenSmells)
                repoSmell.putAll(travisSmells)
            }

            ReposWithSmells.put(repository,repoSmell)
        }

        println("gradle repos size:" + gradleRepoSize)
        println("maven repos size:" + mavenRepoSize)
        println(ReposWithSmells.size())


        Closure getRepoSmellNum ={ Map<Object,StateFlag> map->
            def count = 0
            map.each {
                if(it.value == StateFlag.CLOSE || it.value == StateFlag.DEFAULT){
                    count++
                }
            }
            return count
        }

        Map<Object,int[]> statistic = new HashMap<>()

        Closure expAndImp = { Map<Object,StateFlag> map->
            def (travisPCS,mavenPCS,gradlePCS) = [0,0,0]
            map.each {smell,flag->
                if(statistic[smell]==null){
                    statistic[smell] = new int[2]
                }

                if(flag == StateFlag.CLOSE || flag== StateFlag.DEFAULT){
                    if(flag == StateFlag.CLOSE){
                        statistic[smell][0]++
                    }else {
                        statistic[smell][1]++
                    }
                    if(smell instanceof TravisStrategy){
                        travisPCS=1
                    }
                    if(smell instanceof MavenStrategy){
                        mavenPCS=1
                    }
                    if(smell instanceof GradleStrategy){
                        gradlePCS=1
                    }
                }
            }
            return [travisPCS,mavenPCS,gradlePCS]
        }

        def smellNumber = new int[5]
        int travisProject=0
        int mavenProject=0
        int gradleProject=0

        int noPCSProject = 0
        ReposWithSmells.each {repo,map->
            def repoSmellNum = getRepoSmellNum.call(map)
            if(repoSmellNum>4){
                smellNumber[4]++
            }else if(repoSmellNum<=4 && repoSmellNum>0){
                smellNumber[repoSmellNum-1]++
            }

            if(repoSmellNum==0){
                noPCSProject++
            }
            def (travisPCS,mavenPCS,gradlePCS) = expAndImp.call(map)
            travisProject+=travisPCS
            mavenProject+=mavenPCS
            gradleProject+=gradlePCS
        }

        println("one PCS: " + smellNumber[0])
        println("two PCS: " + smellNumber[1])
        println("three PCS: " + smellNumber[2])
        println("four PCS: " + smellNumber[3])
        println("more than four PCS: " +smellNumber[4])
        println("no PCS project size: " + noPCSProject)

        def (explicit,implicit) = [0,0]

        statistic.each {smell,value->
            println(smell)
            println("显式： "+value[0]+"  " + "隐式： "+value[1])
            explicit +=value[0]
            implicit +=value[1]
        }

        println("explicit PCS：" + explicit)
        println("implicit PCS：" + implicit)

        println("Travis PCS project:" + travisProject)
        println("Maven PCS project:" + mavenProject)
        println("Gradle PCS project:" + gradleProject)

    }

    static void removeTwoLayersMapElement(Map<String, Map<Object,StateFlag>> TwoLayersMap, Closure<?> conditionalClosure) {

        Closure removeInnerMap = { Map<Object,StateFlag> innerMap->
            for (Iterator<Map.Entry<Object, StateFlag>> it = innerMap.entrySet().iterator(); it.hasNext();){
                Map.Entry<Object, StateFlag> item = it.next()
                def repairable = conditionalClosure.call(item.key, item.value)
                if(!repairable){
                    it.remove()
                }
            }
        }


        for (Iterator< Map.Entry< String, Map<Object,StateFlag> > > it = TwoLayersMap.entrySet().iterator(); it.hasNext();){
            Map.Entry<String,Map<Object,StateFlag>> item = it.next()

            def innerMap = item.value

            removeInnerMap.call(innerMap)
            if(innerMap.keySet().size() == 0){
                it.remove()
            }
        }

    }


    static void main(String[] args) {
        run()
    }
}
