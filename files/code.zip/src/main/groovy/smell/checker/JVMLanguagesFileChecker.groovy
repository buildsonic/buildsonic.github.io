package smell.checker

import groovy.io.FileType
import model.Repository
import org.hibernate.Session
import org.hibernate.Transaction
import util.MysqlUtil
import util.SessionUtil
import util.Util

import java.nio.file.Paths

class JVMLanguagesFileChecker {

    static void updateJavaFilesNum() throws Exception{
        Session session = SessionUtil.getSession()
        Transaction tx = session.beginTransaction()
        List<Repository> repositories = MysqlUtil.getRepositories(session)

        for(Repository repository : repositories){
            int JavaFilesNum = javaFilesCheck(repository.getRepoName())[0]
            repository.setJavaFilesNum(JavaFilesNum)
            session.update(repository)
        }
        tx.commit()
        session.close()
    }

    static void updateContainTest(){
        Session session = SessionUtil.getSession()
        Transaction tx = session.beginTransaction()

        for(Repository repository: MysqlUtil.getRepositories(session))
        {
            String repoPath = Paths.get(Util.codeDirectoryPath.toString(), repository.getRepoName().replace('/', '@')).normalize().toString()
            def findTest = javaFilesCheck(repoPath)[1]
            if(findTest==1){
                repository.setContainTest(1)
                session.update(repository)
            }
        }
        tx.commit()
        session.close()
    }

    static int[] javaFilesCheck(String repoPath){
        File repo = new File(repoPath)

        int containTest = 0
        int javaFilesNum = 0

        repo.eachFileRecurse(FileType.FILES){f->
            def fileName = f.name
            if(fileName.endsWith(".java") || fileName.endsWith(".groovy") || fileName.endsWith(".kt") || fileName.endsWith(".scala")|| fileName.endsWith(".clj")){
                javaFilesNum ++
            }
            if(fileName.endsWith("Test.java") || fileName.endsWith("Test.groovy") || fileName.endsWith("Test.kt") || fileName.endsWith("Test.scala")|| fileName.endsWith("Test.clj")){
                containTest = 1
            }
        }

        return [javaFilesNum, containTest]
    }

    static void main(String[] args) {
        updateJavaFilesNum()
    }
}
