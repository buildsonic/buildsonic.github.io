package smell.checker

import parser.YmlParser
import smell.StateFlag
import static util.TravisUtil.*


import java.util.regex.Matcher

class TravisChecker {
    String TravisFilePath
    String TravisContent
    LinkedHashMap<String, Object> map
    List<String> commands
    List<String> keys = []
    TravisChecker(String travisFilePath) {
        this.TravisFilePath = travisFilePath
        this.TravisContent = new File(this.travisFilePath).text
        this.map = YmlParser.parse(this.TravisFilePath)
        this.commands = YmlParser.getCommands(map)
        YmlParser.getKeys(this.map, this.keys)
    }

    def shallowCloneValue(){
        if (keys.contains("git") && keys.contains("depth")) {
            String value = map.get("git").get("depth").toString()
            if(value.contains('false')){
                return -1
            }else if(value.isInteger()){
                 return value.toInteger()
            }
        }
        return null
    }

    StateFlag shallowCloneCheck() {
        def depth = shallowCloneValue()
        if(depth == null){
            return null
        }else if(depth==-1 || depth >=50){
            return StateFlag.CLOSE
        }else if(depth < 50){
            return StateFlag.OPEN
        }
    }

    StateFlag retryCheck() {
        List<String> result = []
        commands.each {
            if (it.contains("travis_retry")) {
                result << it
            }
            else {
                Matcher matcher = (it =~ /--retry (\d+)/)
                if (matcher && matcher.group(1).toInteger() > 1) {
                    result << it
                }
            }
        }
        return result.size()>=1?StateFlag.CLOSE:null
    }

    StateFlag waitCheck() {
        List<Integer> result = []
        commands.each {
            if (it.contains("travis_wait")) {
                Matcher matcher = (it =~ /travis_wait (\d+)/)
                if (matcher) {
                    int waitTime = matcher.group(1).toInteger()
                    if(waitTime>10){
                        result << matcher.group(1).toInteger()
                    }
                } else {
                    result << 20
                }
            }
        }
        return result.size()>0?StateFlag.CLOSE:null
    }


    StateFlag cacheCheck() {
        List<Object> result = []
        YmlParser.getCacheValues(map, result)
        if (result.size() == 0) {
            return StateFlag.DEFAULT
        }
        return result.any { it != false }?StateFlag.OPEN:StateFlag.CLOSE
    }

    StateFlag fastFinishCheck() {
        List<Object> allowFailuresList = []
        YmlParser.getKeyValues(map, allowFailuresList, "allow_failures")
        Boolean allow_failures = allowFailuresList.any { it != null }
        if(!allow_failures){
            return null
        }
        List<Object> fastFinishList = []
        YmlParser.getKeyValues(map, fastFinishList, "fast_finish")
        if (fastFinishList.size() > 0) {
            return fastFinishList.any { it == true }?StateFlag.OPEN:StateFlag.CLOSE
        }
        return StateFlag.CLOSE
    }

    StateFlag check(TravisStrategy strategy){
        if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
            return shallowCloneCheck()
        } else if (strategy == TravisStrategy.TRAVIS_RETRY) {
            return retryCheck()
        } else if (strategy == TravisStrategy.TRAVIS_WAIT) {
            return waitCheck()
        } else if (strategy == TravisStrategy.TRAVIS_CACHE) {
            return cacheCheck()
        } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
            return fastFinishCheck()
        }
    }

    Map<TravisStrategy,StateFlag> check(){
        Map<TravisStrategy,StateFlag> strategyWithFlag = new HashMap<>()
        for(TravisStrategy strategy : TravisStrategy.values()){
            def flag = check(strategy)
            if(flag!=null){
                strategyWithFlag.put(strategy,flag)
            }
        }
        return strategyWithFlag
    }

     static void main(String[] args) {

    }
}
