package smell.checker

import parser.YmlParser
import smell.StateFlag


import static util.TravisUtil.*


import java.util.regex.Matcher

class TravisChecker {
    String TravisFilePath
    String TravisContent
    LinkedHashMap<String, Object> map
    List<String> commands
    List<String> keys = []
    TravisChecker(String travisFilePath) {
        this.TravisFilePath = travisFilePath
        this.TravisContent = new File(this.travisFilePath).text
        this.map = YmlParser.parse(this.TravisFilePath)
        this.commands = YmlParser.getCommands(map)
        YmlParser.getKeys(this.map, this.keys)
    }

    StateFlag shallowCloneCheck() {
        if (keys.contains("git") && keys.contains("depth")) {
            String value = map.get("git").get("depth").toString()
            if(value.contains('false')){
                return StateFlag.CLOSE
            }else if(value.isInteger()){
                int gitDepth = value.toInteger()
                return gitDepth>=50?StateFlag.CLOSE:StateFlag.OPEN
            }
        }
        return StateFlag.DEFAULT
    }

    StateFlag retryCheck() {
        List<String> result = []
        commands.each {
            if (it.contains("travis_retry")) {
                result << it
            } else {
                Matcher matcher = (it =~ /--retry (\d+)/)
                if (matcher && matcher.group(1).toInteger() > 1) {
                    result << it
//                    println(matcher.group(1).toInteger())
                }
            }
        }
        //字段travis_retry在数据库中为null表示消除smell（StateFlag.OPEN）
        return result.size()>=1?StateFlag.CLOSE:StateFlag.OPEN
    }

    StateFlag waitCheck() {
        List<Integer> result = []
        commands.each {
            if (it.contains("travis_wait")) {
                Matcher matcher = (it =~ /travis_wait (\d+)/)
                if (matcher) {
                    int waitTime = matcher.group(1).toInteger()
                    if(waitTime>10){
                        result << matcher.group(1).toInteger()
                    }
                } else {
                    result << 20
                }
            }
        }
        //字段travis_wait在数据库中为null表示消除smell（StateFlag.OPEN）
        return result.size()>0?StateFlag.CLOSE:StateFlag.OPEN
    }

    StateFlag cacheCheck() {
        def cache = map?.get("cache")
        if (cache == null) {
            return StateFlag.DEFAULT
        }
        List<Object> result = []
        YmlParser.getCacheValues(map, result)
        if (result.size() == 0) {
            return StateFlag.DEFAULT
        }
        return result.any { it != false }?StateFlag.OPEN:StateFlag.CLOSE
    }

    StateFlag fastFinishCheck() {
        List<Object> fastFinishList = []
        YmlParser.getKeyValues(map, fastFinishList, "fast_finish")
        if (fastFinishList.size() > 0) {
            return fastFinishList.any { it == true }?StateFlag.OPEN:StateFlag.CLOSE
        }
        return StateFlag.DEFAULT
//        List<Object> allowFailuresList = []
//        YmlParser.getKeyValues(map, allowFailuresList, "allow_failures")
//        Boolean allow_failures = allowFailuresList.any { it != null }

    }

    StateFlag check(TravisStrategy strategy){
        if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
            return shallowCloneCheck()
        } else if (strategy == TravisStrategy.TRAVIS_RETRY) {
            return retryCheck()
        } else if (strategy == TravisStrategy.TRAVIS_WAIT) {
            return waitCheck()
        } else if (strategy == TravisStrategy.TRAVIS_CACHE) {
            return cacheCheck()
        } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
            return fastFinishCheck()
        }
    }
    
//     void run() {
//        try (Session session = SessionUtil.getSession()) {
//            Transaction tx =session.beginTransaction();
//            List<Repository> repositories = MysqlUtil.getRepositories(session)
//            for (Repository repository : repositories) {
//                //shallow clone
//                /*
//                def shallowCloneValue = shallowCloneCheck(repository)
//                if (shallowCloneValue != null) {
//                    repository.setTravisGitDepth(shallowCloneValue.toString())
//                }
//
//                //travis_retry
//                List<String> travisRetryResult = retryCheck(repository)
//                if (travisRetryResult.size() > 0) {
//                    repository.setTravisRetry(true)
//                } else {
//                    repository.setTravisRetry(false)
//                }
//
//                //travis_wait
//                List<Integer> travisWaitResult = waitCheck(repository)
//                if (travisWaitResult.size() > 0) {
//                    repository.setTravisWait(travisWaitResult)
//                }
//
//
//                //cache
//                def result = cacheCheck(repository)
//                if (result == null) {
//                    repository.setTravisCache(null)
//                } else if (result == false) {
//                    repository.setTravisCache(false)
//                } else {
//                    repository.setTravisCache(true)
//                }
//
//                 */
//
//                //fast_finish
//                def (allow_failures, fast_finish) = fastFinishCheck(repository)
//                repository.setTravisAllowFailures(allow_failures)
//                repository.setTravisFastFinish(fast_finish)
//            }
//            tx.commit()
//        }
//    }
    
     static void main(String[] args) {
        //TravisSmell.shallowCloneCheck()
        //TravisSmell.retryCheck()
        //TravisSmell.waitCheck()
        //TravisSmell.cacheCheck()
        //TravisChecker.fastFinishCheck()
//        run()
    }
}
