package smell.checker.gradle

import model.Repository
import org.codehaus.groovy.ast.expr.BinaryExpression
import parser.GradleParser
import parser.GradleVisitor
import smell.StateFlag
import util.Util

import java.nio.file.Paths

import static util.GradleUtil.*

class BuildGradleChecker {
    static Map<GradleStrategy, Closure> predicatesMap = [
            (GradleStrategy.GRADLE_COMPILER_DAEMON): { List<BinaryExpression> expressions ->
                for (BinaryExpression expression : expressions) {
                    if (expression.leftExpression.text.endsWith("options.fork")) {
                        if (expression.rightExpression.text.trim() == "false" ) {
                            return StateFlag.CLOSE
                        } else {
                            return StateFlag.OPEN
                        }
                    }
                }
                return StateFlag.DEFAULT
            },

            (GradleStrategy.GRADLE_INCREMENTAL_COMPILATION): { List<BinaryExpression> expressions ->
                for (BinaryExpression expression : expressions) {
                    if (expression.leftExpression.text.endsWith("options.incremental")) {
                        if (expression.rightExpression.text.trim() == "false") {
                            return StateFlag.CLOSE
                        } else {
                            return StateFlag.OPEN
                        }
                    }
                }
                return StateFlag.DEFAULT
            },

            (GradleStrategy.GRADLE_PARALLEL_TEST): { List<BinaryExpression> expressions ->
                for (BinaryExpression expression : expressions) {
                    if (expression.leftExpression.text.trim() == "maxParallelForks" ) {
                        if (expression.rightExpression.text.trim() == "1") {
                            return StateFlag.CLOSE
                        } else {
                            return StateFlag.OPEN
                        }
                    }
                }
                return StateFlag.DEFAULT
            },

            (GradleStrategy.GRADLE_FORK_TEST): { List<BinaryExpression> expressions ->
                for (BinaryExpression expression : expressions) {
                    if (expression.leftExpression.text.trim() == "forkEvery") {
                        if (expression.rightExpression.text.trim() == "0" || expression.rightExpression.text.startsWith('-')) {
                            return StateFlag.CLOSE
                        } else {
                            return StateFlag.OPEN
                        }
                    }
                }
                return StateFlag.DEFAULT
            },

            (GradleStrategy.GRADLE_REPORT_GENERATION): { List<BinaryExpression> expressions ->
                for (BinaryExpression expression : expressions) {
                    if (expression.leftExpression.text.contains("html.required") || expression.leftExpression.text.contains("junitXml.required")) {
                        println(expression.text)
                        if (expression.rightExpression.text.trim() == "true") {
                            return StateFlag.CLOSE
                        } else {
                            return StateFlag.OPEN
                        }
                    }
                }
                return StateFlag.DEFAULT
            }
    ]

    static Map<String, Map<GradleStrategy,StateFlag>> check(String repoPath) {
        Map<String, Map<GradleStrategy,StateFlag>> checkedFileWithStrategy = new HashMap<>()

        List<String> buildFilePaths = Util.getGradleFilePaths(repoPath)
        if (buildFilePaths.size() == 0){
            println("cannot find *.gradle file")
            return checkedFileWithStrategy
        }
        for (String buildFilePath : buildFilePaths) {
            def strategyWithFlag = buildFileCheck(buildFilePath)
            if(strategyWithFlag.keySet().size() != 0){
                checkedFileWithStrategy.put(buildFilePath,strategyWithFlag)
            }
        }
        return checkedFileWithStrategy
    }

    static Map<GradleStrategy,StateFlag> buildFileCheck(String buildFilePath){
        Map<GradleStrategy,StateFlag> strategyWithFlag = new HashMap<>()

        GradleParser parser = new GradleParser(buildFilePath)
        GradleVisitor visitor = parser.getVisitor()
        List<BinaryExpression> expressions = visitor.binaryExpressions

        for(GradleStrategy strategy: strategiesOfCategory.get(GradleCategory.COMPILATION)+strategiesOfCategory.get(GradleCategory.TEST)){
            def flag = buildFileCheck(expressions, strategy)
            strategyWithFlag.put(strategy,flag)
        }

        return strategyWithFlag
    }

    static StateFlag buildFileCheck(List<BinaryExpression> expressions, GradleStrategy strategy){
        def predicate = predicatesMap.get(strategy)
        return predicate.call(expressions)
    }

    static Map<String, Map<GradleStrategy,StateFlag>> check(Repository repository) {
        String repoPath = Paths.get(Util.codeDirectoryPath.toString(), repository.getRepoName().replace('/', '@')).normalize().toString()
        return check(repoPath)
    }

}
