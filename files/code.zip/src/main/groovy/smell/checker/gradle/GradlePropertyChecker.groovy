package smell.checker.gradle

import parser.OptionParser
import java.nio.file.Paths
import smell.StateFlag
import static util.GradleUtil.*


class GradlePropertyChecker {

    static StateFlag parallelExecutionChecker(List<String> yml_shell_commands, Map<String, String> gradleProperties) {
        if (gradleProperties.get("org.gradle.parallel") == "true" || yml_shell_commands.any{it.contains("--parallel") || (it =~ /org.gradle.parallel\s*=\s*true/)})
            return StateFlag.OPEN

        if (gradleProperties.get("org.gradle.parallel") == "false" || yml_shell_commands.any{it.contains("--no-parallel") || (it =~ /org.gradle.parallel\s*=\s*false/)})
            return StateFlag.CLOSE

        return StateFlag.DEFAULT
    }

    static StateFlag fileSystemWatchingChecker(List<String> yml_shell_commands, Map<String, String> gradleProperties) {
        if (gradleProperties.get("org.gradle.vfs.watch") == "true" || yml_shell_commands.any{it.contains("--watch-fs") || (it =~ /org.gradle.vfs.watch\s*=\s*true/)})
            return StateFlag.OPEN

        if (gradleProperties.get("org.gradle.vfs.watch") == "false" || yml_shell_commands.any{it.contains("--no-watch-fs") || (it =~ /org.gradle.vfs.watch\s*=\s*false/)})
            return StateFlag.CLOSE

        return StateFlag.DEFAULT
    }

    static StateFlag configureOnDemandChecker(List<String> yml_shell_commands, Map<String, String> gradleProperties) {
        if (gradleProperties.get("org.gradle.configureondemand") == "true" || yml_shell_commands.any{it.contains("--configure-on-demand") || (it =~ /org.gradle.configureondemand\s*=\s*true/)})
            return StateFlag.OPEN

        if (gradleProperties.get("org.gradle.configureondemand") == "false" || yml_shell_commands.any{it.contains("--no-configure-on-demand") || (it =~ /org.gradle.configureondemand\s*=\s*false/)})
            return StateFlag.CLOSE

        return StateFlag.DEFAULT
    }

    static StateFlag cacheChecker(List<String> yml_shell_commands, Map<String, String> gradleProperties) {
        if (gradleProperties.get("org.gradle.caching") == "true" || yml_shell_commands.any{it.contains("--build-cache") || (it =~ /org.gradle.caching\s*=\s*true/)})
            return StateFlag.OPEN

        if (gradleProperties.get("org.gradle.caching") == "false" || yml_shell_commands.any{it.contains("--no-build-cache") || (it =~ /org.gradle.caching\s*=\s*false/)})
            return StateFlag.CLOSE

        return StateFlag.DEFAULT
    }

    static StateFlag daemonChecker(List<String> yml_shell_commands, Map<String, String> gradleProperties) {
        if (gradleProperties.get("org.gradle.daemon") == "true" || yml_shell_commands.any{it.contains("--daemon") || (it =~ /org.gradle.daemon\s*=\s*true/)})
            return StateFlag.OPEN

        if (gradleProperties.get("org.gradle.daemon") == "false" || yml_shell_commands.any{it.contains("--no-daemon") || (it =~ /org.gradle.daemon\s*=\s*false/)})
            return StateFlag.CLOSE

        return StateFlag.DEFAULT
    }

    static Map<String,Map<GradleStrategy,StateFlag>> check(String repoPath, String originRepoName) {
        Map<String,Map<GradleStrategy,StateFlag>> checkedFileWithStrategy = new HashMap<>()

        String ymlFilePath = Paths.get(repoPath, ".travis.yml").normalize().toString()
        String propertyPath = Paths.get(repoPath,"gradle.properties").normalize().toString()


        OptionParser optionParser = new OptionParser(repoPath, originRepoName)

        def gradleProperties = optionParser.parseGradleProperties()

        Map<GradleStrategy,StateFlag> propertyStrategyWithFlag = new HashMap<>()
        strategiesOfCategory.get(GradleCategory.PROPERTIES).each {strategy->
            def flag = check([],gradleProperties,strategy)
            propertyStrategyWithFlag.put(strategy,flag)
        }
        if(propertyStrategyWithFlag.keySet().size() !=0){
            checkedFileWithStrategy.put(propertyPath,propertyStrategyWithFlag)
        }


        def shellBuildCommandsMap = optionParser.getShellBuildCommandsMap()
        shellBuildCommandsMap.put(".travis.yml",optionParser.getYamlGradleBuildCommands())

        shellBuildCommandsMap.keySet().each {shellFileName->
            def yml_shell_commands = shellBuildCommandsMap.get(shellFileName)
            def shellFilePath = Paths.get(repoPath,shellFileName).normalize().toString()
            Map<GradleStrategy,StateFlag> strategyWithFlag = new HashMap<>()

            strategiesOfCategory.get(GradleCategory.PROPERTIES).each {strategy->
                def flag = check(yml_shell_commands,[:],strategy)
                strategyWithFlag.put(strategy,flag)
            }
            if(strategyWithFlag.keySet().size() !=0){
                checkedFileWithStrategy.put(shellFilePath,strategyWithFlag)
            }
        }

        return  checkedFileWithStrategy
    }

    static StateFlag check(List<String> yml_shell_commands, Map<String, String> gradleProperties, GradleStrategy strategy){
        if (strategy == GradleStrategy.GRADLE_PARALLEL_BUILDS) {
            return parallelExecutionChecker(yml_shell_commands, gradleProperties)
        } else if (strategy == GradleStrategy.GRADLE_FILE_SYSTEM_WATCHING) {
            return fileSystemWatchingChecker(yml_shell_commands, gradleProperties)
        } else if (strategy == GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND) {
            return configureOnDemandChecker(yml_shell_commands, gradleProperties)
        } else if (strategy == GradleStrategy.GRADLE_CACHING) {
            return cacheChecker(yml_shell_commands, gradleProperties)
        } else if (strategy == GradleStrategy.GRADLE_DAEMON) {
            return daemonChecker(yml_shell_commands, gradleProperties)
        }
        return null
    }


    static void main(String[] args) {
    }
}
