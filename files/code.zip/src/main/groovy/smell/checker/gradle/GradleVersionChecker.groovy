package smell.checker.gradle

import model.Repository
import org.apache.commons.configuration2.Configuration
import org.apache.commons.configuration2.FileBasedConfiguration
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder
import org.hibernate.Session
import org.hibernate.Transaction
import util.MysqlUtil
import util.SessionUtil
import util.Util

import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern

class GradleVersionChecker {
    static String getVersion(String filePath) {
        String version = null
        File file = new File(filePath)
        Pattern pattern = ~/gradle-([\.\d]+)-(bin|all).zip/
        if (file.exists()) {
            FileBasedConfigurationBuilder<FileBasedConfiguration> builder = Util.getConfigurationBuilder(filePath)
            Configuration config = builder.getConfiguration()
            String distributionUrl = config.getString("distributionUrl")
            Matcher matcher = pattern.matcher(distributionUrl)
            if (matcher.find()) {
                version = matcher.group(1)
            }
        }
        return version
    }

    static String getRepoGradleVersion(Repository repository) {
        String filePath = Paths.get(Util.codeDirectoryPath.toString(), repository.getRepoName().replace('/', '@'), "gradle", "wrapper", "gradle-wrapper.properties").normalize().toString()
        return getVersion(filePath)
    }

    static String getRepoGradleVersion(String repoPath){
        String filePath = Paths.get(repoPath, "gradle", "wrapper", "gradle-wrapper.properties").normalize().toString()
        return getVersion(filePath)
    }

    static void getRepoGradleVersion() {
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction()
            List<Repository> repositories = MysqlUtil.getRepositories(session)
            for (Repository repository : repositories) {
                if (repository.getBuildTool() == 2) {
                    String version = getRepoGradleVersion(repository)
                    repository.setVersion(version)
                }
            }
            tx.commit()
        }
    }
}
