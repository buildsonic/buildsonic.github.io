package smell.checker.maven

import model.Repository
import smell.StateFlag
import util.MavenUtil.MavenStrategy

class CompilationChecker extends POMChecker {
    CompilationChecker(String repoPath) {
        super(repoPath)
    }

    CompilationChecker(Repository repository) {
        super(repository)
    }

    @Override
    StateFlag check(MavenStrategy strategy) {
        //这里只检测的根pom，后面根据实际情况看是否要检测其它pom文件
        Map<String, String> compilationConfigurations = this.rootPom.getCompilationConfigurations();
        Closure predicate = POMChecker.predicatesMap.get(strategy)
        return predicate.call(compilationConfigurations)
    }
}
