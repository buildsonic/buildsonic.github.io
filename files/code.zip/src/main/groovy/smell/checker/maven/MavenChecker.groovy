package smell.checker.maven

import model.Repository
import smell.StateFlag
import smell.checker.CheckerUpdate
import smell.checker.JVMLanguagesFileChecker
import static util.MavenUtil.*

class MavenChecker {

    static Map<String,Map<MavenStrategy,StateFlag>> check(String repoPath, String originRepoName){
        Repository repository = new Repository()

        repository.setRepoName(originRepoName)

        Boolean isMultiModule = MultiModuleChecker.isMultiModule(repoPath)
        repository.setMultiModule(isMultiModule)

        int[] javaFilesInfo = JVMLanguagesFileChecker.javaFilesCheck(repoPath)
        repository.setJavaFilesNum(javaFilesInfo[0])
        repository.setContainTest(javaFilesInfo[1])

        return check(repository,repoPath)
    }


    static Map<String,Map<MavenStrategy,StateFlag>> check(Repository repository,String repoPath) {
        def checkedFileWithStrategy = checkAllStrategies(repoPath,repository.repoName)

        Closure filtrateDefaultSmell = { MavenStrategy strategy, StateFlag flag->
            if( flag != StateFlag.DEFAULT){
                return true
            }
            def repairable = false
            if(strategy == MavenStrategy.MAVEN_PARALLEL_EXECUTION){
                repairable = checkParallelBuild(repository)
            } else if(strategy == MavenStrategy.MAVEN_COMPILER_DAEMON){
                repairable = checkMavenCompilation(repository)
            }else{
                repairable = checkMavenTest(repository,strategy)
            }
            return repairable
        }

        CheckerUpdate.removeTwoLayersMapElement(checkedFileWithStrategy,filtrateDefaultSmell)


        return checkedFileWithStrategy
    }


    static Map<String,Map<MavenStrategy,StateFlag>> checkAllStrategies(String repoPath, String originRepoName) {
        def checkedFileWithStrategyOfShell = ParallelBuildChecker.check(repoPath,originRepoName)

        def checkedFileWithStrategyOfPOM= POMChecker.check(repoPath)

        Map<String,Map<MavenStrategy,StateFlag>> checkedFileWithStrategy = new HashMap<>()
        checkedFileWithStrategy.putAll(checkedFileWithStrategyOfShell)
        checkedFileWithStrategy.putAll(checkedFileWithStrategyOfPOM)

        return checkedFileWithStrategy
    }

    static Boolean checkMavenTest(Repository repository, MavenStrategy strategy){
        if(repository.containTest==1){
            return true
        }
        return false
    }

    static Boolean checkMavenCompilation(Repository repository){
        if(repository.getJavaFilesNum()>=1000){
            return true
        }
       return false
    }

    static Boolean checkParallelBuild(Repository repository){
        if(repository.multiModule) {
            return true
        }
        return false
    }
}
