package smell.checker.maven

import maven.POM
import maven.POMTree
import model.Repository
import org.codehaus.groovy.ast.expr.BinaryExpression
import smell.StateFlag
import util.Util

import java.nio.file.Paths

import static util.MavenUtil.MavenStrategy

abstract class POMChecker {
    POMTree pomTree;
    POM rootPom;

    POMChecker(String repoPath) {
        this.pomTree = new POMTree(repoPath)
        this.rootPom = pomTree.createPomTree()
    }

    POMChecker(Repository repository) {
        this(Paths.get(Util.forkDirectoryPath.toString(), repository.getRepoName().replace('/', '@')).normalize().toString())
    }

    abstract StateFlag check(MavenStrategy strategy)

    Map<MavenStrategy, StateFlag> check(List<MavenStrategy> strategies) {
        Map<MavenStrategy, StateFlag> map = new HashMap<>()
        for (MavenStrategy strategy : strategies) {
            StateFlag flag = check(strategy)
            map.put(strategy, flag)
        }
        return map
    }

    static Map<MavenStrategy, Closure> predicatesMap = [
            (MavenStrategy.MAVEN_PARALLEL_TEST): { Map<String, String> testConfigurations ->
                String parallel = testConfigurations.get("parallel")
                String unlimited = testConfigurations.get("useUnlimitedThreads")
                String perCoreCount = testConfigurations.get("perCoreThreadCount")
                String threadCount = testConfigurations.get("threadCount")
                if(parallel == null) {
                    return StateFlag.DEFAULT
                } else if(parallel.equals("none") || parallel.equals("false")) {
                    return StateFlag.CLOSE
                } else if(threadCount==1 && perCoreCount =='false' && (unlimited ==null||unlimited=='false')) {
                    return StateFlag.CLOSE
                }
                return StateFlag.OPEN
            },

            (MavenStrategy.MAVEN_FORK_TEST): { Map<String, String> testConfigurations ->
                String val = testConfigurations.get("forkCount")
                //println("'"+val+"'")
                if(val == null) {
                    return StateFlag.DEFAULT
                } else if(val == "1" || val == "0"){
                    return StateFlag.CLOSE
                } else{
                    return StateFlag.OPEN
                }
            },

            (MavenStrategy.MAVEN_REPORT_GENERATION): { Map<String, String> testConfigurations ->
                String val = testConfigurations.get("disableXmlReport")
                //println("'"+val+"'")
                if(val == null) {
                    return StateFlag.DEFAULT
                } else if (val.equals("true")){
                    return StateFlag.OPEN
                } else {
                    return StateFlag.CLOSE
                }
            },

            (MavenStrategy.MAVEN_COMPILER_DAEMON): { Map<String, String> compilationConfigurations ->
                String val = compilationConfigurations.get("fork")
                //println("'"+val+"'")
                if(val == null) {
                    return StateFlag.DEFAULT
                } else if (val.equals("true")){
                    return StateFlag.OPEN
                } else {
                    return StateFlag.CLOSE
                }
            },

            (MavenStrategy.MAVEN_INCREMENTAL_COMPILATION): { Map<String, String> compilationConfigurations ->
                String val = compilationConfigurations.get("useIncrementalCompilation")
                //println("'"+val+"'")
                if(val == null) {
                    return StateFlag.DEFAULT
                } else if (val.equals("true")){
                    return StateFlag.OPEN
                } else {
                    return StateFlag.CLOSE
                }
            },
    ]
}
