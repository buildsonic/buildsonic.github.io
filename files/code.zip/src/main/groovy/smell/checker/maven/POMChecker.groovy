package smell.checker.maven

import groovy.io.FileType
import maven.POM
import maven.POMParser
import smell.StateFlag


import static util.MavenUtil.*


class POMChecker {
    static List<String> getPOMPaths(String repoPath) {
        List<String> pomPaths = new ArrayList<>()
        File dir = new File(repoPath)
        dir.eachFileRecurse(FileType.FILES){
            if(it.name=='pom.xml'){
                pomPaths << it.absolutePath
            }
        }
        return pomPaths
    }

    static Map<MavenStrategy, StateFlag> checkPOM(String pomPath){
        Map<MavenStrategy, StateFlag> stateWithFlag= new HashMap<>()

        POM pom = new POMParser().parse(pomPath)

        Map<String, String> testConfigurations = pom.getTestConfigurations()
        if (testConfigurations.keySet().size()!=0){
            for(MavenStrategy strategy: strategiesOfCategory.get(MavenCategory.TEST)){
                Closure predicate = POMChecker.predicatesMap.get(strategy)
                StateFlag flag = predicate.call(testConfigurations)
                stateWithFlag.put(strategy,flag)
            }
        }else{
            for(MavenStrategy strategy: strategiesOfCategory.get(MavenCategory.TEST)){
                stateWithFlag.put(strategy,StateFlag.DEFAULT)
            }
        }

        Map<String, String> compilationConfigurations = pom.getCompilationConfigurations()
        if (compilationConfigurations.keySet().size()!=0){
            for(MavenStrategy strategy: strategiesOfCategory.get(MavenCategory.COMPILATION)){
                Closure predicate = POMChecker.predicatesMap.get(strategy)
                StateFlag flag = predicate.call(testConfigurations)
                if(flag != StateFlag.OPEN){
                    stateWithFlag.put(strategy,flag)
                }
            }
        }else{
            for(MavenStrategy strategy: strategiesOfCategory.get(MavenCategory.COMPILATION)){
                stateWithFlag.put(strategy,StateFlag.DEFAULT)
            }
        }

        return stateWithFlag
    }

    static Map<String, Map<MavenStrategy, StateFlag>> check(String repoPath) {
        Map<String, Map<MavenStrategy, StateFlag>> checkedFileWithStrategy = new HashMap<>()

        List<String> pomPaths = getPOMPaths(repoPath)

        pomPaths.each {pomPath->
            try{
                def stateWithFlag = checkPOM(pomPath)
                if(stateWithFlag.keySet().size() != 0){
                    checkedFileWithStrategy.put(pomPath, stateWithFlag)
                }
                if(stateWithFlag.get(MavenStrategy.MAVEN_REPORT_GENERATION) == StateFlag.CLOSE){
                    println(pomPath)
                }
            }catch (Exception e){
                println(pomPath+" error")
            }
        }

        return checkedFileWithStrategy
    }

    static Map<MavenStrategy, Closure> predicatesMap = [
            (MavenStrategy.MAVEN_PARALLEL_TEST): { Map<String, String> testConfigurations ->
                String parallel = testConfigurations.get("parallel")
                String unlimited = testConfigurations.get("useUnlimitedThreads")
                String perCoreCount = testConfigurations.get("perCoreThreadCount")
                String threadCount = testConfigurations.get("threadCount")
                if(parallel == null) {
                    return StateFlag.DEFAULT
                }
                if(parallel == "none" || parallel == "false") {
                    return StateFlag.CLOSE
                } else if(threadCount==1 && perCoreCount =='false' && (unlimited ==null||unlimited=='false')) {
                    return StateFlag.CLOSE
                }
                return StateFlag.OPEN
            },

            (MavenStrategy.MAVEN_FORK_TEST): { Map<String, String> testConfigurations ->
                String val = testConfigurations.get("forkCount")
                if(val == null) {
                    return StateFlag.DEFAULT
                }
                println("forkCount:"+val)
                if(val == "1" || val == "0"){
                    return StateFlag.CLOSE
                } else{
                    return StateFlag.OPEN
                }
            },

            (MavenStrategy.MAVEN_REPORT_GENERATION): { Map<String, String> testConfigurations ->
                String val = testConfigurations.get("disableXmlReport")
                if(val == null) {
                    return StateFlag.DEFAULT
                }
                println("disableXmlReport:"+val)
                if (val == "true"){
                    return StateFlag.OPEN
                } else {
                    return StateFlag.CLOSE
                }
            },

            (MavenStrategy.MAVEN_COMPILER_DAEMON): { Map<String, String> compilationConfigurations ->
                String val = compilationConfigurations.get("fork")
                if(val == null) {
                    return StateFlag.DEFAULT
                }
                println("fork:"+val)
                if (val == "true"){
                    return StateFlag.OPEN
                } else {
                    return StateFlag.CLOSE
                }
            },

//            (MavenStrategy.MAVEN_INCREMENTAL_COMPILATION): { Map<String, String> compilationConfigurations ->
//                String val = compilationConfigurations.get("useIncrementalCompilation")
//                //println("'"+val+"'")
//                if(val == null) {
//                    return StateFlag.DEFAULT
//                } else if (val.equals("true")){
//                    return StateFlag.OPEN
//                } else {
//                    return StateFlag.CLOSE
//                }
//            },
    ]
}
