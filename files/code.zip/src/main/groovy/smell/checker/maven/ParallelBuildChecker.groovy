package smell.checker.maven

import parser.OptionParser
import smell.StateFlag
import static util.MavenUtil.*

import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern

class ParallelBuildChecker {
    static Pattern pattern = ~/ -T\s+(\S+)/
    static StateFlag parallelExecutionChecker(List<String> commands) {
        def flag = StateFlag.DEFAULT
        for (String command : commands) {
            if (command.contains("mvn") && command.contains("-T")) {
                Matcher matcher = pattern.matcher(command)
                if (matcher.find()) {
                    String num = matcher.group(1)
                    println('==========')
                    println(num)
                    if (num == '1') {
                        return StateFlag.CLOSE
                    } else {
                        flag = StateFlag.OPEN
                    }
                }
            }
        }
        return flag
    }

    static Map<String,Map<MavenStrategy,StateFlag>> check(String repoPath, String originRepoName){
        Map<String,Map<MavenStrategy,StateFlag>> checkedFileWithStrategy = new HashMap<>()

        OptionParser optionParser = new OptionParser(repoPath, originRepoName)


        Map<String,List<String>> shellBuildCommandsMap = optionParser.getShellBuildCommandsMap()
        shellBuildCommandsMap.put(".travis.yml",optionParser.getYamlMavenBuildCommands())

        shellBuildCommandsMap.each { shellFileName,commands->
            def shellFilePath = Paths.get(repoPath,shellFileName).normalize().toString()
            def flag = parallelExecutionChecker(commands)
            checkedFileWithStrategy.put(shellFilePath,[(MavenStrategy.MAVEN_PARALLEL_EXECUTION):flag])
        }

        return checkedFileWithStrategy
    }

}
