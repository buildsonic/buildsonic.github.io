package smell.checker.maven

import maven.POM
import maven.POMTree
import model.Repository
import org.hibernate.Session
import org.hibernate.Transaction
import smell.StateFlag
import util.MysqlUtil
import util.SessionUtil
import util.Util

import java.nio.file.Paths

import util.MavenUtil.MavenStrategy

class TestChecker extends POMChecker {

    TestChecker(String repoPath) {
        super(repoPath)
    }

    TestChecker(Repository repository) {
        super(repository)
    }

    @Override
    StateFlag check(MavenStrategy strategy) {
        //这里只检测的根pom，后面根据实际情况看是否要检测其它pom文件
        Map<String, String> testConfigurations = this.rootPom.getTestConfigurations();
        Closure predicate = POMChecker.predicatesMap.get(strategy)
        return predicate.call(testConfigurations)
    }

    static void check() {
        try (Session session = SessionUtil.getSession()) {
            //Transaction tx = session.beginTransaction();
            List<Repository> repositories = MysqlUtil.getRepositories(session)
            for (Repository repository : repositories) {
                if (repository.buildTool != 1)
                    continue
                println("处理${repository.getRepoName()}")
                try {
                    POMChecker checker = new TestChecker(repository)
                    checker.check(MavenStrategy.MAVEN_PARALLEL_TEST)
                } catch (Exception e) {
                    e.printStackTrace()
                }
                //boolean flag = check(repository)
                //repository.setParallelTest(flag)
            }
            //tx.commit()
        }
    }
}
