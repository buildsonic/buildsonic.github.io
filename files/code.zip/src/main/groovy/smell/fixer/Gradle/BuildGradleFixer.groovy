package smell.fixer.Gradle

import smell.StateFlag
import static util.GradleUtil.GradleStrategy

class BuildGradleFixer {

    static void buildImplicitFixer(String buildFilePath, List<GradleStrategy> strategies){
        File file = new File(buildFilePath)
        if(!file.exists()) {
            throw new IOException("${buildFilePath} not exists")
        }
        List<String> contents = file.readLines()
        def allProjectIndex = contents.findIndexOf{ it.startsWith("allproject")}

        String addContent = getAddContentOfCompilation(strategies)
        addContent += getAddContentOfTest(strategies)
        addContent += getAddContentOfCompilation(strategies)

        if(allProjectIndex == -1){
            contents.add("\nallprojects {")
            contents.add(addContent)
            contents.add("}\n")
        }else{
            contents.add(allProjectIndex + 1, addContent)
        }
        new File(buildFilePath).text = contents.join('\n')
    }

    static String getAddContentOfCompilation(List<GradleStrategy> strategies){
        if(strategies.size() == 0){
            return ""
        }
        List<String> addContent = new ArrayList<>()
        addContent.add("    tasks.withType(JavaCompile).configureEach {");
        String compilerDaemon = "        options.fork = true";
        String incrementalCompilation  = "        options.incremental = true"
        if (strategies.contains(GradleStrategy.GRADLE_COMPILER_DAEMON)) {
            addContent.add(compilerDaemon)
        }
        if (strategies.contains(GradleStrategy.GRADLE_INCREMENTAL_COMPILATION)) {
            addContent.add(incrementalCompilation)
        }
        addContent.add("    }\n")
        return addContent.join('\n')
    }

    static String getAddContentOfTest(List<GradleStrategy> strategies){
        if(strategies.size() == 0){
            return ""
        }
        List<String> addContent = new ArrayList<>()
        addContent.add("    tasks.withType(Test).configureEach {")
        String parallelTest = "        maxParallelForks = Runtime.runtime.availableProcessors().intdiv(2) ?: 1"
        String processForkingOptions = "        forkEvery = 100"
        String disableReportGeneration="        if (!project.hasProperty(\"createReports\")) {\n" +
                "            reports.html.required = false\n" +
                "            reports.junitXml.required = false\n" +
                "        }"
        if(strategies.contains(GradleStrategy.GRADLE_PARALLEL_TEST)) {
            addContent.add(parallelTest)
        }
        if(strategies.contains(GradleStrategy.GRADLE_FORK_TEST)) {
            addContent.add(processForkingOptions)
        }
        if(strategies.contains(GradleStrategy.GRADLE_REPORT_GENERATION)) {
            addContent.add(disableReportGeneration)
        }
        addContent.add("    }\n")
        return addContent.join('\n')
    }


    static void buildExplicitFixer(String buildFilePath, List<GradleStrategy> strategies){
        List<String> buildFileContent = new File(buildFilePath).readLines()
        boolean changed = false
        strategies.each {strategy->
            if(strategy == GradleStrategy.GRADLE_COMPILER_DAEMON) {
                buildFileContent.eachWithIndex{ line, index ->
                    if(line.replace(" ","").contains('options.fork')){
                        println(index+":"+line)
                        buildFileContent[index] = line.replace('false','true')
                        changed = true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_INCREMENTAL_COMPILATION) {
                buildFileContent.eachWithIndex{ line, index ->
                    if(line.replace(" ","").contains('options.incremental')){
                        println(index+":"+line)
                        buildFileContent[index] = line.replace('false','true')
                        changed = true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_PARALLEL_TEST){
                buildFileContent.eachWithIndex{ line, index ->
                    if(line.replace(" ","").contains('maxParallelForks')){
                        println(index+":"+line)
                        buildFileContent[index] = line.replace('1','Runtime.runtime.availableProcessors().intdiv(2) ?: 1')
                        changed = true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_FORK_TEST) {
                buildFileContent.eachWithIndex{ line, index ->
                    if(line.replace(" ","").contains('forkEvery')){
                        println(index+":"+line)
                        buildFileContent[index] = line.replace('1','100')
                        changed = true
                    }
                }
            }
            if(strategy ==GradleStrategy.GRADLE_REPORT_GENERATION){
                buildFileContent.eachWithIndex{ line, index ->
                    if(line.replace(" ","").contains('html.required') || line.trim().contains('junitXml.required')){
                        println(index+":"+line)
                        buildFileContent[index] = line.replace('true','false')
                        changed = true
                    }
                }
            }
        }
        if(changed){
            new File(buildFilePath).text = buildFileContent.join('\n')
        }
    }

    static void fix(String buildFilePath, Map<GradleStrategy, StateFlag> strategyWithFlag){
        def implicitSmell = []
        def explicitSmell = []
        strategyWithFlag.each {strategy,flag->
            if(flag == StateFlag.DEFAULT){
                implicitSmell << strategy
            }
            if(flag == StateFlag.CLOSE){
                explicitSmell << strategy
            }
        }
        if(implicitSmell.size()!=0){
            buildImplicitFixer(buildFilePath,implicitSmell)
        }
        if(explicitSmell.size()!=0){
            buildExplicitFixer(buildFilePath,explicitSmell)
        }
    }

    static void main(String[] args) {
    }
}