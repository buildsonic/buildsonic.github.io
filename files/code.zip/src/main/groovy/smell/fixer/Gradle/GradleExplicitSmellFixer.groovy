package smell.fixer.Gradle


import parser.OptionParser
import smell.TravisFixer
import util.GitUtil
import util.GradleUtil
import smell.StateFlag
import util.Util
import smell.checker.gradle.BuildGradleChecker
import java.nio.file.Paths

import static util.GradleUtil.*

class GradleExplicitSmellFixer {
    String repoPath
    List<String> buildFilePaths
    String travisFilePath
    GradleStrategy strategy
    GradleCategory category

    GradleExplicitSmellFixer(String repoPath) {
        this.repoPath = repoPath
        this.strategy = strategy
        this.category = getGradleCategory(this.strategy)
        this.buildFilePaths = Util.getGradleFilePaths(repoPath)
        this.travisFilePath = Paths.get(repoPath,".travis.yml").normalize().toString()
    }

    void fixer(List<GradleStrategy> strategies){
        strategies.each {strategy->
            fixer(strategy)
        }
    }

    void fixer(GradleStrategy strategy){
        this.strategy = strategy
        println("修复显式引入Gradle smell---${this.strategy.toString()}")
        println("smell类型属于：${category == GradleCategory.PROPERTIES?'PROPERTIES':'Build'}")
        if (category == GradleCategory.TEST || category == GradleCategory.COMPILATION || category == GradleCategory.FORK){
            buildFixer()
        } else if (category == GradleCategory.PROPERTIES){
            propertiesFixer()
        }
    }

    void buildFixer(){
        buildFilePaths.each {buildFilePath->
            def flag = BuildGradleChecker.singleFileCheck(buildFilePath, strategy)
            if(flag == StateFlag.CLOSE){
                List<String> buildFileContent = new File(buildFilePath).readLines()
                buildFixer(buildFileContent)
                new File(buildFilePath).text = buildFileContent
            }
        }
    }

    void buildFixer(List<String> buildFileContent){
        if(this.strategy == GradleStrategy.GRADLE_COMPILER_DAEMON) {
            buildFileContent.eachWithIndex{ line, index ->
                if(line.trim().contains('options.fork=false')){
                    buildFileContent[index] = line.replace('false','true')
                }
            }
            return
        }
        if(this.strategy == GradleStrategy.GRADLE_INCREMENTAL_COMPILATION) {
            buildFileContent.eachWithIndex{ line, index ->
                if(line.trim().contains('options.incremental=false')){
                    buildFileContent[index] = line.replace('false','true')
                }
            }
            return
        }
        if(this.strategy == GradleStrategy.GRADLE_PARALLEL_TEST){
            buildFileContent.eachWithIndex{ line, index ->
                if(line.trim().contains('maxParallelForks=1')){
                    buildFileContent[index] = line.replace('1','Runtime.runtime.availableProcessors().intdiv(2) ?: 1')
                }
            }
            return
        }
        if(this.strategy == GradleStrategy.GRADLE_FORK_TEST) {
            buildFileContent.eachWithIndex{ line, index ->
                if(line.trim().contains('forkEvery=1')){
                    buildFileContent[index] = line.replace('1','100')
                }
            }
            return
        }
        if (this.strategy ==GradleStrategy.GRADLE_REPORT_GENERATION){
            buildFileContent.eachWithIndex{ line, index ->
                if(line.trim().contains('html.required=true') || line.trim().contains('junitXml.required=true')){
                    buildFileContent[index] = line.replace('true','false')
                }
            }
        }
    }

    void propertiesFixer(){
        // properties的修改(gradle.properties)
        OptionParser optionParser = new OptionParser(this.repoPath)
        def gradleProperties = optionParser.parseGradleProperties()
        propertiesFixer(gradleProperties)
        // GradleCommandLine的修改(.travis.yml)
        TravisFixer fixer = new TravisFixer(this.travisFilePath)
        fixer.gradleCommandFixer(strategy)
    }

    void  propertiesFixer(Map<String, String> gradleProperties){
        def strategies = [strategy]   //调用GradlePropertiesFixer(传入List<>)
        if(this.strategy == GradleStrategy.PARALLEL_BUILDS){
            if(gradleProperties.get("org.gradle.parallel") == "false"){
                GradlePropertiesFixer.modifyProperties(this.repoPath,strategies)
            }
        }
        if(this.strategy == GradleStrategy.FILE_SYSTEM_WATCHING){
            if(gradleProperties.get("org.gradle.vfs.watch") == "false"){
                GradlePropertiesFixer.modifyProperties(this.repoPath,strategies)
            }
        }
        if(this.strategy == GradleStrategy.CONFIGURATION_ON_DEMAND){
            if(gradleProperties.get("org.gradle.configureondemand") == "false"){
                GradlePropertiesFixer.modifyProperties(this.repoPath,strategies)
            }
        }
        if(this.strategy == GradleStrategy.CACHING){
            if(gradleProperties.get("org.gradle.caching") == "false"){
                GradlePropertiesFixer.modifyProperties(this.repoPath,strategies)
            }
        }
        if(this.strategy == GradleStrategy.GRADLE_DAEMON){
            if(gradleProperties.get("org.gradle.daemon") == "false"){
                GradlePropertiesFixer.modifyProperties(this.repoPath,strategies)
            }
        }
    }
}
