package smell.fixer.Gradle

import smell.StateFlag
import static util.GradleUtil.*

class GradleFixer {
    String repoName
    String repoPath
    Map<String,Map<GradleStrategy,StateFlag>> strategyWithCheckedFile = new HashMap()



    GradleFixer(String repoPath, String originRepoName, Map<String,Map<GradleStrategy,StateFlag>> checkedFileWithStrategy){
        this.repoName = originRepoName
        this.repoPath = repoPath
        this.strategyWithCheckedFile = checkedFileWithStrategy
    }


    void fix(){
        this.strategyWithCheckedFile.keySet().each { String filePath->
            Map<GradleStrategy,StateFlag> strategyWithFlag =  this.strategyWithCheckedFile[filePath]

            if (filePath.endsWith('.gradle')){
                BuildGradleFixer.fix(filePath, strategyWithFlag)
            }else{
                propertyFixer(filePath, strategyWithFlag)
            }
        }
    }


    void fix(List<GradleStrategy> onlyStrategies){
        Map<String,Map<GradleStrategy,StateFlag>> onlyStrategyWithCheckedFile = new HashMap<>()

        this.strategyWithCheckedFile.keySet().each { String filePath->
            Map<GradleStrategy,StateFlag> strategyWithFlag =  this.strategyWithCheckedFile[filePath]
            Map<GradleStrategy,StateFlag> onlyStrategyWithFlag = new HashMap<>()

            strategyWithFlag.each {strategy,flag->
                if(onlyStrategies.contains(strategy)){
                    onlyStrategyWithFlag.put(strategy,flag)
                }
            }

            if(onlyStrategyWithFlag.keySet().size() != 0){
                onlyStrategyWithCheckedFile.put(filePath,onlyStrategyWithFlag)
            }
        }

        this.strategyWithCheckedFile = onlyStrategyWithCheckedFile
        fix()
    }

    static void propertyFixer(String filePath, Map<GradleStrategy,StateFlag> strategyWithFlag){
        if(filePath.endsWith(".properties")){
            GradlePropertiesFixer.modifyProperties(filePath, strategyWithFlag)
        }else{
            GradlePropertiesFixer.commandsFixer(filePath,strategyWithFlag)
        }
    }

}
