package smell.fixer.Gradle


import org.apache.commons.configuration2.Configuration
import org.apache.commons.configuration2.FileBasedConfiguration
import org.apache.commons.configuration2.PropertiesConfiguration
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder
import org.apache.commons.configuration2.builder.fluent.Parameters
import smell.StateFlag
import static util.GradleUtil.GradleStrategy


class GradlePropertiesFixer {
    static void modifyProperties(String propertyFilePath, Map<GradleStrategy,StateFlag> strategyWithFlag){
        def strategies = []
        strategyWithFlag.each {strategy,flag->
            if(flag==StateFlag.DEFAULT || flag == StateFlag.CLOSE){
                strategies << strategy
            }
        }
        if(strategies.size()==0){
            return
        }

        File file = new File(propertyFilePath)
        if (!file.exists()) {
            try {
                file.createNewFile()
            } catch (IOException e) {
                e.printStackTrace()
            }
        }

        Parameters params = new Parameters();
        FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
                new FileBasedConfigurationBuilder<FileBasedConfiguration>(PropertiesConfiguration.class)
                        .configure(params.properties()
                                .setFileName(propertyFilePath))


        HashMap<String,String> properties = getProperties(strategies)
        Configuration config = builder.getConfiguration()
        for(String key: properties.keySet()){
            String value = properties.get(key)
            config.setProperty(key,value)
        }
        builder.save()
    }

    static HashMap<String, String> getProperties(List<GradleStrategy> strategies){
        HashMap<String, String> properties = new HashMap<>()
        for(GradleStrategy strategy : strategies){
            if(strategy == GradleStrategy.GRADLE_PARALLEL_BUILDS){
                properties.put("org.gradle.parallel", "true")
            } else if(strategy  == GradleStrategy.GRADLE_FILE_SYSTEM_WATCHING){
                properties.put("org.gradle.vfs.watch", "true")
            } else if(strategy == GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND){
                properties.put("org.gradle.configureondemand", "true")
            } else if(strategy == GradleStrategy.GRADLE_CACHING){
                properties.put("org.gradle.caching", "true")
            } else if(strategy == GradleStrategy.GRADLE_DAEMON){
                properties.put("org.gradle.daemon", "true")
            }
        }
        return properties
    }


    static void commandsFixer(String shellFilePath, Map<GradleStrategy, StateFlag> strategyWithFlag){
        List<String> content = new File(shellFilePath).readLines()
        boolean changed = false
        strategyWithFlag.keySet().each {strategy->
            if(strategyWithFlag.get(strategy) != StateFlag.CLOSE){
                return
            }
            if(strategy == GradleStrategy.GRADLE_PARALLEL_BUILDS){
                content.eachWithIndex{line,index->
                    if(line.contains('--no-parallel')){
                        content[index] = line.replace('--no-parallel','--parallel')
                        changed=true
                    }
                    if(line=~ /org.gradle.parallel\s*=\s*false/){
                        content[index] = line.replace('false','true')
                        changed=true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_FILE_SYSTEM_WATCHING){
                content.eachWithIndex{line,index->
                    if(line.contains('--no-watch-fs')){
                        content[index] = line.replace('--no-watch-fs','--watch-fs')
                        changed=true
                    }
                    if(line=~ /org.gradle.vfs.watch\s*=\s*false/){
                        content[index] = line.replace('false','true')
                        changed=true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_CONFIGURATION_ON_DEMAND){
                content.eachWithIndex{line,index->
                    if(line.contains('--no-configure-on-demand')){
                        content[index] = line.replace('--no-configure-on-demand','--configure-on-demand')
                        changed=true
                    }
                    if(line=~ /org.gradle.configureondemand\s*=\s*false/){
                        content[index] = line.replace('false','true')
                        changed=true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_CACHING){
                content.eachWithIndex{line,index->
                    if(line.contains('--no-build-cache')){
                        content[index] = line.replace('--no-build-cache','--build-cache')
                        changed=true
                    }
                    if(line=~ /org.gradle.caching\s*=\s*false/){
                        content[index] = line.replace('false','true')
                        changed=true
                    }
                }
            }
            if(strategy == GradleStrategy.GRADLE_DAEMON){
                content.eachWithIndex{line,index->
                    if(line.contains('--no-daemon')){
                        content[index] = line.replace('--no-daemon','--daemon')
                        changed=true
                    }
                    if(line=~ /org.gradle.daemon\s*=\s*false/){
                        content[index] = line.replace('false','true')
                        changed=true
                    }
                }
            }
        }

        if(changed){
            new File(shellFilePath).text = content.join('\n')
        }
    }
}
