package smell.fixer.Maven

import smell.StateFlag


class CompilationFixer {
    static boolean compilerDaemon(POMFixer fixer, StateFlag flag) {
        if (fixer.getCompilerPlugin() == null)
            return false
        if(flag == StateFlag.CLOSE){
            return  fixer.updatePluginNodeConfiguration('maven-compiler-plugin','fork','true')
        }
        Map<String, String> map = new LinkedHashMap<>()
        map.put("fork", "true")
        fixer.editCompilerNode(map)
        return true
    }

//    static boolean incrementalCompilation(String rootXmlPath) {
//        POMFixer fixer = new POMFixer(rootXmlPath)
//        if (fixer.getCompilerPlugin() == null)
//            return false
//        //fixer.updateCompilerNode("useIncrementalCompilation", "true")
//        Map<String, String> map = new LinkedHashMap<>()
//        map.put("useIncrementalCompilation", "true")
//        fixer.editCompilerNode(map)
//        fixer.printToFile(rootXmlPath)
//        return true
//    }


}
