package smell.fixer.Maven

import maven.POM
import maven.POMTree
import smell.StateFlag
import util.MavenUtil.MavenStrategy

import java.nio.file.Paths

class MavenExplicitSmellFixer {
    String repoPath
    String rootXmlPath
    MavenStrategy strategy
    POM rootPom
    Map<String, String> testConfigurations
    Map<String, String> compilationConfigurations
    MavenExplicitSmellFixer(String repoPath, MavenStrategy strategy) {
        this.repoPath = repoPath
        this.strategy = strategy
        this.rootXmlPath = Paths.get(repoPath,'pom.xml').normalize().toString()
        this.rootPom = new POMTree(repoPath).createPomTree()
        this.testConfigurations = this.rootPom.getTestConfigurations()
        this.compilationConfigurations = this.rootPom.getCompilationConfigurations()
    }

    void fixer(){
        POMFixer fixer = new POMFixer(rootXmlPath)
        if(strategy == MavenStrategy.MAVEN_PARALLEL_TEST){
            String parallel = testConfigurations.get("parallel")
            String unlimited = testConfigurations.get("useUnlimitedThreads")
            String perCoreCount = testConfigurations.get("perCoreThreadCount")
            String threadCount = testConfigurations.get("threadCount")
            if(parallel == null) {
                println("没有配置parallel")
                return
            }
            if(parallel=="none" || parallel=="false") {
                fixer.updatePluginNodeConfiguration('maven-surefire-plugin','parallel','classes')
                if(unlimited==null){
                    // parallel在pluginManagement里面，这个被插入到其它地方？可不可能出现？
                    fixer.editSurefireNode(['useUnlimitedThreads':'true'])
                }else if(unlimited=='false'){
                    fixer.updatePluginNodeConfiguration('maven-surefire-plugin','useUnlimitedThreads','true')
                }
                fixer.printToFile(rootXmlPath)
            } else if(threadCount==1 && perCoreCount =='false' && (unlimited ==null||unlimited=='false')) {
                if(unlimited==null){
                    // parallel在pluginManagement里面，这个被插入到其它地方？可不可能出现？
                    fixer.editSurefireNode(['useUnlimitedThreads':'true'])
                }else if(unlimited=='false'){
                    fixer.updatePluginNodeConfiguration('maven-surefire-plugin','useUnlimitedThreads','true')
                }
                fixer.printToFile(rootXmlPath)
            }
        }
    }
}
