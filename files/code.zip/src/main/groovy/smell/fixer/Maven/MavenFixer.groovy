package smell.fixer.Maven


import smell.StateFlag
import static util.MavenUtil.*

class MavenFixer {
    String repoName
    String repoPath
    Map<String,Map<MavenStrategy,StateFlag>> strategyWithCheckedFile = new HashMap()

    MavenFixer(String repoPath, String originRepoName, Map<String,Map<MavenStrategy,StateFlag>> checkedFileWithStrategy){
        this.repoPath = repoPath
        this.repoName = originRepoName
        this.strategyWithCheckedFile = checkedFileWithStrategy
    }


    void fix(){
        this.strategyWithCheckedFile.keySet().each { String filePath->
            Map<MavenStrategy,StateFlag> strategyWithFlag =  this.strategyWithCheckedFile[filePath]

            if (filePath.endsWith('pom.xml')){
                pomFix(filePath,strategyWithFlag)
            }else{
                ParallelBuildFixer.parallelExecutionFix(filePath, strategyWithFlag[MavenStrategy.MAVEN_PARALLEL_EXECUTION])
            }
        }
    }


    void fix(List<MavenStrategy> onlyStrategies){
        Map<String,Map<MavenStrategy,StateFlag>> onlyStrategyWithCheckedFile = new HashMap<>()

        this.strategyWithCheckedFile.keySet().each { String filePath->
            Map<MavenStrategy,StateFlag> strategyWithFlag =  this.strategyWithCheckedFile[filePath]
            Map<MavenStrategy,StateFlag> onlyStrategyWithFlag = new HashMap<>()

            strategyWithFlag.each {strategy,flag->
                if(onlyStrategies.contains(strategy)){
                    onlyStrategyWithFlag.put(strategy,flag)
                }
            }

            if(onlyStrategyWithFlag.keySet().size() != 0){
                onlyStrategyWithCheckedFile.put(filePath,onlyStrategyWithFlag)
            }
        }

        this.strategyWithCheckedFile = onlyStrategyWithCheckedFile
        fix()
    }


    static void pomFix(String pomPath, Map<MavenStrategy,StateFlag> strategyWithFlag){
        strategyWithFlag.each {strategy,flag->

            if(flag == StateFlag.OPEN){
                return
            }

            POMFixer fixer = new POMFixer(pomPath)
            def isChanged = false

            if(strategy == MavenStrategy.MAVEN_PARALLEL_TEST) {
                if (flag == StateFlag.CLOSE){
                    isChanged = TestFixer.parallelTestExplicit(pomPath,fixer)
                }else{
                    isChanged = TestFixer.parallelTest(fixer)
                }

            } else if(strategy == MavenStrategy.MAVEN_FORK_TEST) {
                isChanged = TestFixer.forkTest(fixer,flag)

            } else if (strategy == MavenStrategy.MAVEN_REPORT_GENERATION) {
                isChanged = TestFixer.report(fixer,flag)

            } else if(strategy == MavenStrategy.MAVEN_COMPILER_DAEMON){
                isChanged = CompilationFixer.compilerDaemon(fixer,flag)
            }

            if(isChanged){
                fixer.printToFile(pomPath)
            }
        }
    }

}
