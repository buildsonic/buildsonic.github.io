package smell.fixer.Maven

import smell.StateFlag
import java.util.regex.Matcher
import java.util.regex.Pattern

class ParallelBuildFixer {
    static Pattern pattern = ~/ -T\s+(\S+)/

    static void parallelExecutionFix(String filePath, StateFlag flag) {
        if(flag == StateFlag.OPEN){
            return
        }
        File file = new File(filePath)
        String content = file.text

        if(flag == StateFlag.CLOSE){
            List<String> contents = new File(filePath).readLines()
            contents.eachWithIndex {line,index->
                if(line.contains('mvn') || line.contains("mvnw")){
                    Matcher matcher = pattern.matcher(line)
                    if(matcher.find()){
                        contents[index] = matcher.replaceFirst(' -T 1C')
                    }
                }
            }
        }
        else{
            content = content.replaceAll('mvn ', 'mvn -T 1C ')
            content = content.replaceAll('mvnw ', 'mvnw -T 1C ')
        }
        new File(filePath).text = content
    }

}
