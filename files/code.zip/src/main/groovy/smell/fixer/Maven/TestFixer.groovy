package smell.fixer.Maven

import maven.POM
import maven.POMParser
import smell.StateFlag


class TestFixer {

    static boolean parallelTestExplicit(String pomPath, POMFixer fixer){
        POM pom = new POMParser().parse(pomPath)
        Map<String, String> testConfigurations = pom.getTestConfigurations()
        String parallel = testConfigurations.get("parallel")
        String unlimited = testConfigurations.get("useUnlimitedThreads")
        String perCoreCount = testConfigurations.get("perCoreThreadCount")
        String threadCount = testConfigurations.get("threadCount")

        if(parallel == null || testConfigurations.size()==0) {
            return false
        }

        if(parallel=="none" || parallel=="false") {
            fixer.updatePluginNodeConfiguration('maven-surefire-plugin','parallel','classes')
            if(unlimited==null){
                fixer.editSurefireNode(['useUnlimitedThreads':'true'])
            }else if(unlimited=='false'){
                fixer.updatePluginNodeConfiguration('maven-surefire-plugin','useUnlimitedThreads','true')
            }
        } else if(threadCount==1 && perCoreCount =='false' && (unlimited ==null||unlimited=='false')) {
            if(unlimited==null){
                fixer.editSurefireNode(['useUnlimitedThreads':'true'])
            }else if(unlimited=='false'){
                fixer.updatePluginNodeConfiguration('maven-surefire-plugin','useUnlimitedThreads','true')
            }
        }
        return true
    }

    static boolean parallelTest(POMFixer fixer) {
        if (fixer.getSurefirePlugin() == null)
            return false

        Map<String, String> map = new LinkedHashMap<>()
        map.put("parallel", "classes")
        map.put("useUnlimitedThreads", "true")
        fixer.editSurefireNode(map)
        return true
    }

    static boolean forkTest(POMFixer fixer, StateFlag flag) {
        if (fixer.getSurefirePlugin() == null)
            return false

        if(flag==StateFlag.CLOSE){
             return fixer.updatePluginNodeConfiguration('maven-surefire-plugin','forkCount','1.5C')
        }

        Map<String, String> map = new LinkedHashMap<>()
        map.put("forkCount", "1.5C")
        fixer.editSurefireNode(map)
        return true
    }

    static boolean report(POMFixer fixer, StateFlag flag) {
        if (fixer.getSurefirePlugin() == null)
            return false
        if(flag == StateFlag.CLOSE){
            return  fixer.updatePluginNodeConfiguration('maven-surefire-plugin','disableXmlReport','true')
        }
        Map<String, String> map = new LinkedHashMap<>()
        map.put("disableXmlReport", '${closeTestReports}')
        fixer.editSurefireNode(map)
        fixer.insertProperty("closeTestReports", "true")
        return true
    }

}
