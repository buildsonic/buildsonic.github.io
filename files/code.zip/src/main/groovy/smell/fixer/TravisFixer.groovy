package smell.fixer

import org.yaml.snakeyaml.Yaml
import parser.YmlParser
import smell.StateFlag
import util.TravisUtil.TravisStrategy
import java.util.regex.Matcher
import java.util.regex.Pattern

class TravisFixer {

    String TravisFilePath
    String TravisContent
    LinkedHashMap<String, Object> map
    List<String> keys = []
    Map<TravisStrategy, StateFlag> strategyWithFlag = new HashMap()
    int buildTool

    TravisFixer(String travisFilePath) {
        this.TravisFilePath = travisFilePath
        this.TravisContent = new File(this.travisFilePath).text
        this.map = YmlParser.parse(this.TravisFilePath)
        YmlParser.getKeys(this.map, this.keys)
    }

    TravisFixer(String travisFilePath,Map<TravisStrategy,StateFlag> strategyWithFlag, int buildTool) {
        this(travisFilePath)
        this.strategyWithFlag = strategyWithFlag
        this.buildTool = buildTool
    }

    void fix(){
        this.strategyWithFlag.each {strategy, flag->
            if(flag==null || flag==StateFlag.OPEN){
                return
            }
            travisSmellFixer(strategy,flag)
        }
    }

    void fix(List<TravisStrategy> onlyStrategies){
        this.strategyWithFlag.each {strategy, flag->
            if(onlyStrategies.contains(strategy)){
                travisSmellFixer(strategy,flag)
            }
        }
    }

    void travisSmellFixer(TravisStrategy strategy, StateFlag flag){
        if (strategy == TravisStrategy.TRAVIS_CACHE) {
            if(flag==StateFlag.DEFAULT){
                addCache(buildTool)
            }else{
                modifyCache(buildTool)
            }
        } else if (strategy == TravisStrategy.TRAVIS_SHALLOW_CLONE) {
            new File(this.TravisFilePath).text = modifyGitDepth()
        } else if (strategy == TravisStrategy.TRAVIS_RETRY && flag==StateFlag.CLOSE) {
            new File(this.TravisFilePath).text = removeTravisRetry()
        } else if (strategy == TravisStrategy.TRAVIS_WAIT && flag==StateFlag.CLOSE) {
            new File(this.TravisFilePath).text = removeTravisWait()
        } else if (strategy == TravisStrategy.TRAVIS_FAST_FINISH) {
            modifyOrAddFastFinish()
        }
    }

    String modifyGitDepth() {
        if (keys.contains("git") && keys.contains("depth")) {
            String value = map.get("git").get("depth").toString()
            Pattern pattern = ~/(?ms)(git:.*?depth:.*?)${value}/
            Matcher matcher = pattern.matcher(TravisContent)
            return matcher.replaceFirst('$13')
        } else if (keys.contains("git")){
            Pattern pattern = ~/(?ms)git:.*?\n/
            Matcher matcher = pattern.matcher(TravisContent)
            return matcher.replaceFirst('$0  depth: 3\n')
        } else {
            return TravisContent + '\ngit:\n  depth: 3\n'
        }
    }

    String removeTravisRetry() {
        if (TravisContent.contains("travis_retry")) {
            List<String> lines = TravisContent.split('\n')
            TravisContent = lines.collect {line ->
                if (line.contains("travis_retry") && line.trim().startsWith("#") == false) {
                    line = line.replaceAll(/\s*travis_retry\s+/, ' ')
                }
                line
            }.join('\n')
            return TravisContent + '\n'
        } else {
            throw new Exception("${this.TravisFilePath} doesn't contain Travis_retry")
        }
    }

    String removeTravisWait() {
        if (TravisContent.contains("travis_wait")) {
            List<String> lines = TravisContent.split('\n')
            Pattern pattern = ~/travis_wait\s+(\d+)?/
            TravisContent = lines.collect {line ->
                if (line.contains("travis_wait") && !line.trim().startsWith("#")) {
                    Matcher matcher = pattern.matcher(line)
                    while (matcher.find()) {
                        println(matcher.groupCount())
                        if (matcher.group(1) == null) {
                            line = line.replaceAll(/\s*travis_wait\s+/, ' ')
                            break
                        } else {
                            int time = matcher.group(1).toInteger()
                            if (time > 10) {
                                line = line.replaceAll(/\s*travis_wait\s+(\d+)?\s+/, ' ')
                                break
                            }
                        }
                    }
                }
                line
            }.join('\n')
            return TravisContent + '\n'
        } else {
            throw new Exception("${TravisFilePath} doesn't contain Travis_wait")
        }
    }

    void addCache(int buildTool = 1) {
        def outFile = new File(this.TravisFilePath)

        if (buildTool == 1) {
            outFile.withWriterAppend {writer ->
                writer.writeLine("\ncache:")
                writer.writeLine("  directories:")
                writer.writeLine('  - $HOME/.m2')
            }
        } else {
            outFile.withWriterAppend {writer ->
                writer.writeLine("\ncache:")
                writer.writeLine("  directories:")
                writer.writeLine('  - $HOME/.gradle/caches/')
                writer.writeLine('  - $HOME/.gradle/wrapper/')
            }
        }
    }

    void modifyCache(int buildTool=1){
        def content = new File(this.TravisFilePath).readLines()
        content.eachWithIndex{  line,index ->
            if(line.trim().contains('cache:false')){
                if(buildTool==1){
                    content[index]='\ncache:\n  directories:\n  - $HOME/.m2\n'
                }else{
                    content[index]='\ncache:\n  directories:\n  - $HOME/.gradle/caches/\n  - $HOME/.gradle/wrapper/\n'
                }
            }
        }
        new File(this.TravisFilePath).text = content.join('\n')
    }

    void modifyOrAddFastFinish(){
        if(!modifyFastFinish()){
            new File(this.TravisFilePath).text = addFastFinish()
        }
    }

    String addFastFinish() {
        if (this.keys.contains("jobs")) {
            Pattern pattern = ~/(?m)(jobs:.*?)(\r\n|\r|\n)/
            Matcher matcher = pattern.matcher(TravisContent)
            return matcher.replaceFirst('$0  fast_finish: true\n')
        } else if (this.keys.contains("matrix")) {
            Pattern pattern = ~/(?m)(matrix:.*?)(\r\n|\r|\n)/
            Matcher matcher = pattern.matcher(TravisContent)
            return matcher.replaceFirst('$0  fast_finish: true\n')
        } else {
            return TravisContent + '\njobs:\n  fast_finish: true'
        }
    }

    boolean modifyFastFinish() {
        def modified = false
        def content = new File(this.TravisFilePath).readLines()
        content.eachWithIndex{  line,index ->
            if(line.trim().contains('fast_finish:false')){
                content[index]= line.replace('false','true')
                modified = true
            }
        }
        if(modified){
            new File(this.TravisFilePath).text = content.join('\n')
        }
        return modified
    }


    void updateBranches(String newBranchName){
        def only = ["only":[newBranchName]]
        this.map.put("branches",only)
        Yaml yaml = new Yaml()
        new File(this.TravisFilePath).text = yaml.dump(this.map)
    }


}
