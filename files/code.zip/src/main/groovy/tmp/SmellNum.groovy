package tmp

class SmellNum {

}
