package util

import org.apache.poi.xssf.usermodel.XSSFCell
import org.apache.poi.xssf.usermodel.XSSFRow
import org.apache.poi.xssf.usermodel.XSSFSheet
import org.apache.poi.xssf.usermodel.XSSFWorkbook


class ExcelUtil {
    private XSSFWorkbook Workbook = null
    XSSFSheet sheet = null
    String excelPath
    ExcelUtil(String excelPath){
        this.excelPath = excelPath
        try {
            this.Workbook = new XSSFWorkbook(new FileInputStream(excelPath))
        } catch (Exception e) {
            e.printStackTrace()
        }
    }

    ExcelUtil(String excelPath, String sheetName){
        try {
            this.excelPath = excelPath
            this.Workbook = new XSSFWorkbook(new FileInputStream(excelPath))
            this.sheet = Workbook.getSheet(sheetName)
        } catch (Exception e) {
            e.printStackTrace()
        }
    }


    List<XSSFSheet> getSheets(){
        List<XSSFSheet> sheets = new ArrayList<>()
        for (int i = 0; i < Workbook.getNumberOfSheets(); i++) {
            sheets << Workbook.getSheetAt(i)
        }
        return sheets
    }

    String getCell(int row, int column){
        def Row = this.sheet.getRow(row)
        if(Row==null){
            return ""
        }
        def value = Row.getCell(column).toString()
        if(value==null || value.trim()=="" || value.trim()=="null"){
            return ""
        }
        return value
    }
    
    List<String> getCells(int column){
        List<String> cells = new ArrayList<>()
        for(int index = sheet.firstRowNum; index <= sheet.lastRowNum ; index++){
            String cell = getCell(index, column).toString()
            if(cell != ""){
                cells << cell
            }
        }
        return cells
    }


    void addCellWithContent(int raw, int column, String content){
        XSSFRow row = sheet.createRow(raw)
        XSSFCell cell = row.createCell(column)
        cell.setCellValue(content)
    }



    List<XSSFRow> getRowsConditionally(Map<Integer,String> columnMap){
        List<XSSFRow> rows = new ArrayList<>()
        for(int index = sheet.firstRowNum; index <= sheet.lastRowNum ; index++){
            if (columnMap.every {getCell(index, it.key) == it.value}){
                rows << sheet.getRow(index)
            }
        }
        return rows
    }


    List<String> getCellsConditionally(Map<Integer,String> columnMap, int column){
        if(columnMap.size()==0){
            return null
        }
        List<XSSFRow> rows = getRowsConditionally(columnMap)
        List<String> cells = new ArrayList<>()
        rows.each {
            cells << it.getCell(column).toString()
        }
        return cells
    }

    static void main(String[] args) {
    }
}

