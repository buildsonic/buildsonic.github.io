package util

import org.eclipse.jgit.api.CreateBranchCommand
import org.eclipse.jgit.api.Git
import org.eclipse.jgit.api.ListBranchCommand
import org.eclipse.jgit.api.Status
import org.eclipse.jgit.api.errors.RefNotFoundException
import org.eclipse.jgit.api.errors.TransportException
import org.eclipse.jgit.lib.Ref
import org.eclipse.jgit.lib.Repository
import org.eclipse.jgit.lib.StoredConfig
import org.eclipse.jgit.storage.file.FileRepositoryBuilder
import org.eclipse.jgit.transport.CredentialsProvider
import org.eclipse.jgit.transport.RefSpec
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider

import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern

class GitUtil {
    static void cloneRepo(int times = 5, String localPath, String fullRepoName) {
        String remoUrl = "git@github.com:${fullRepoName}.git"
        int retries = 0
        while(retries++ < times) {
            Git result = null
            try {
                result = Git.cloneRepository()
                        .setURI(remoUrl)
                        .setDirectory(new File(localPath))
                        .call()
                System.out.println("Clone repository: " + result.getRepository().getDirectory())
            } catch(TransportException e) {
                sleep(5000)
                e.printStackTrace()
            } catch(Exception e) {
                e.printStackTrace()
            } finally {
                result?.close()
            }
            if (result != null)
                break
        }
    }

    static Repository openRepo(String repoPath) {
        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        Repository repository = builder.setGitDir(new File(repoPath))
                .readEnvironment()
                .findGitDir()
                .build()
        return repository
    }

    static String createAndCheckoutBranch(String repoPath, String branchName, String defaultBranchName) {
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        return createAndCheckoutBranch(git, branchName, defaultBranchName)
    }

    static void checkoutToDefaultBranch(String repoPath, String originRepoName){
        def defaultBranchName= GithubUtil.getDefaultBranchName(originRepoName)
        println("defaultBranchName： "+defaultBranchName)
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        git.checkout().setName(defaultBranchName).call()
    }


    static Boolean CheckoutAndCreate(String repoPath, String branchName, String baseBranch){
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        def (localBranches, remoteBranches) = getBranches(repoPath)
        Closure checkoutExecute = { String branch, String base->
            try{
                if (base==null){
                    git.checkout().setName(branch).call()
                }else{
                    git.checkout().setStartPoint("origin/" + base).setCreateBranch(true).setName(branch).call()
                }
                return true
            } catch (Exception e){
                println(e.getClass().simpleName)
            }
            return false
        }


        if (remoteBranches.contains(branchName)){
            if (localBranches.contains(branchName)){
                return checkoutExecute.call(branchName,null)
            }else{
                return checkoutTOriginBranch(git,branchName)
            }
        }else if(localBranches.contains(branchName)){
            return null
        }

        def ok = checkoutExecute.call(branchName,baseBranch)
        if(ok){
            return false
        }else{
            return null
        }
    }


    static Boolean checkoutTOriginBranch(Git git, String branchName){
        try{
            git.checkout().setCreateBranch(true).setName(branchName).
                    setUpstreamMode(CreateBranchCommand.SetupUpstreamMode.TRACK).
                    setStartPoint("origin/" + branchName).call()
            return true
        } catch (Exception e){
            println(e.getClass().simpleName)
        }
        return false
    }

    static List<List<String>> getBranches(String repoPath){
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        List<Ref> Refs = git.branchList().setListMode(ListBranchCommand.ListMode.ALL).call()
        def localBranches = []
        def remoteBranches = []
        Pattern localPattern = ~/refs\/heads\/(.+)/
        Pattern remotePattern = ~/refs\/remotes\/origin\/(.+)/

        Refs.each {ref->
            Matcher localMatcher = localPattern.matcher(ref.getName())
            Matcher remoteMatcher = remotePattern.matcher(ref.getName())
            if (localMatcher.matches()) {
                localBranches << localMatcher.group(1)
            } else if (remoteMatcher.matches()){
                remoteBranches << remoteMatcher.group(1)
            } else{
                println(ref.getName())
            }
        }
        return [localBranches, remoteBranches]

    }

    static String createAndCheckoutBranch(Git git, String strategyName, String defaultBranchName) {
        List<Ref> refs = git.branchList().setListMode(ListBranchCommand.ListMode.ALL).call();
        List<String> branchNames = []
        Pattern pattern = ~/refs\/(heads|remotes\/origin|remotes\/upstream)\/(.+)/
        refs.each {
            Matcher matcher = pattern.matcher(it.getName())
            if (matcher.matches()) {
                branchNames << matcher.group(2)
            }
        }
        println(branchNames)
        String branchName = null
        int count = 0
        Pattern countPattern = ~/${strategyName}_(\d+)/

        for (String bn in branchNames) {
            if (bn.contains(strategyName) && bn ==~ countPattern) {
                println(bn)
                Matcher countMatcher = countPattern.matcher(bn)
                if (countMatcher) {
                    int tmpCount = countMatcher[0][1] as int
                    count = tmpCount > count ? tmpCount : count
                }
            }
        }
        count++
        branchName = "${strategyName}_${count}"
        println("new branch created: " + branchName)
        git.checkout().setStartPoint("upstream/${defaultBranchName}").setCreateBranch(true).setName(branchName).call()
        return branchName
    }

    static void addAndCommit(String repoPath, String commitMessage) {
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        Status status = git.status().call();
        System.out.println("Untracked: " + status.getUntracked().size())
        System.out.println("Added: " + status.getAdded().size())
        System.out.println("Changed: " + status.getChanged().size())
        System.out.println("Modified: " + status.getModified().size())
        System.out.println("Removed: " + status.getRemoved().size())

        List<String> changedFiles = ([] << status.getUntracked() << status.getAdded() << status.getChanged() << status.getModified() << status.getRemoved()).flatten()
        if (changedFiles.size() > 0) {
            addAndCommit(git, changedFiles, commitMessage)
        }
    }
    static void addAndCommit(Git git, List<String> fileList, String commitMessage) {
        fileList.each {
            git.add().addFilepattern(it).call();
        }

        git.commit().setMessage(commitMessage).call();
    }

    static void setUpstream(String repoPath, String upstreamRepoName) {
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        StoredConfig config = repository.getConfig()
        String value = config.getString("remote","upstream", "url")
        if (value == null) {
            config.setString("remote","upstream", "url", "git@github.com:${upstreamRepoName}.git")
            config.setString("remote","upstream", "fetch", '+refs/heads/*:refs/remotes/upstream/*')
            config.save()
        }

    }

    static void deleteAllFiles(String repoPath){
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        File repo = new File(repoPath)
        repo.listFiles().each {
            if (it.name!='.git'){
                git.rm().addFilepattern(it.name).call()
            }
            if (it.name!='.git' && it.exists()){
                def rm = "rm -rf ${it.absolutePath}".execute(null,new File(repoPath))
                rm.waitFor()
            }
        }
        sleep(1000*10)
    }
}
