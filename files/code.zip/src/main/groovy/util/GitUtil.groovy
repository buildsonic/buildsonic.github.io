package util

import org.eclipse.jgit.api.Git
import org.eclipse.jgit.api.ListBranchCommand
import org.eclipse.jgit.api.Status
import org.eclipse.jgit.api.errors.TransportException
import org.eclipse.jgit.lib.Ref
import org.eclipse.jgit.lib.Repository
import org.eclipse.jgit.lib.StoredConfig
import org.eclipse.jgit.storage.file.FileRepositoryBuilder
import org.eclipse.jgit.transport.CredentialsProvider
import org.eclipse.jgit.transport.RefSpec
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider

import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern

class GitUtil {
    static void cloneRepo(int times = 5, String localPath, String fullRepoName) {
        //String remoUrl = "https://github.com/${fullRepoName}.git"
        //String remoUrl = "git://github.com/${fullRepoName}.git"
        String remoUrl = "git@github.com:${fullRepoName}.git"
        int retries = 0
        while(retries++ < times) {
            Git result = null
            try {
                result = Git.cloneRepository()
                        .setURI(remoUrl)
                        .setDirectory(new File(localPath))
                        .call()
                System.out.println("Clone repository: " + result.getRepository().getDirectory());
            } catch(TransportException e) {
                sleep(5000)
                e.printStackTrace()
            } catch(Exception e) {
                e.printStackTrace()
            } finally {
                result?.close()
            }
            if (result != null)
                break
        }
    }

    static Repository openRepo(String repoPath) {
        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        Repository repository = builder.setGitDir(new File(repoPath))
                .readEnvironment() // scan environment GIT_* variables
                .findGitDir() // scan up the file system tree
                .build()
        return repository
    }

    static String createAndCheckoutBranch(String repoPath, String branchName, String defaultBranchName) {
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        return createAndCheckoutBranch(git, branchName, defaultBranchName)
    }

    static void checkoutToDefaultBranch(String repoPath, String originRepoName){
        def defaultBranchName= GithubUtil.getDefaultBranchName(originRepoName)
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        git.checkout().setName(defaultBranchName)
    }

    static String createAndCheckoutBranch(Git git, String strategyName, String defaultBranchName) {
        List<Ref> refs = git.branchList().setListMode(ListBranchCommand.ListMode.ALL).call();
        List<String> branchNames = []
        Pattern pattern = ~/refs\/(heads|remotes\/origin|remotes\/upstream)\/(.+)/
        refs.each {
            Matcher matcher = pattern.matcher(it.getName())
            if (matcher.matches()) {
                branchNames << matcher.group(2)
            }
        }
        println(branchNames)
        String branchName = null
        int count = 0
        Pattern countPattern = ~/${strategyName}_(\d+)/

        for (String bn in branchNames) {
            if (bn.contains(strategyName) && bn ==~ countPattern) {
                println(bn)
                Matcher countMatcher = countPattern.matcher(bn)
                if (countMatcher) {
                    int tmpCount = countMatcher[0][1] as int
                    count = tmpCount > count ? tmpCount : count
                }
            }
        }
        count++
        branchName = "${strategyName}_${count}"
        println("产生新分支: " + branchName)
        git.checkout().setStartPoint("upstream/${defaultBranchName}").setCreateBranch(true).setName(branchName).call()
        return branchName
    }

    static void addAndCommit(String repoPath, String commitMessage) {
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        Status status = git.status().call();
        System.out.println("Untracked: " + status.getUntracked())
        System.out.println("Added: " + status.getAdded());
        System.out.println("Changed: " + status.getChanged());
        System.out.println("Modified: " + status.getModified());
        System.out.println("Removed: " + status.getRemoved());

        List<String> changedFiles = ([] << status.getUntracked() << status.getAdded() << status.getChanged() << status.getModified() << status.getRemoved()).flatten()
        println(changedFiles)
        if (changedFiles.size() > 0) {
            addAndCommit(git, changedFiles, commitMessage)
        }
    }
    static void addAndCommit(Git git, List<String> fileList, String commitMessage) {
        // run the add
        fileList.each {
            git.add().addFilepattern(it).call();
        }

        // and then commit the changes
        git.commit().setMessage(commitMessage).call();
    }

    //如果没有就设置upstream
    static void setUpstream(String repoPath, String upstreamRepoName) {
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        StoredConfig config = repository.getConfig()
        String value = config.getString("remote","upstream", "url")
        if (value == null) {
            config.setString("remote","upstream", "url", "git@github.com:${upstreamRepoName}.git")
            config.setString("remote","upstream", "fetch", '+refs/heads/*:refs/remotes/upstream/*')
            config.save()
        }

    }

    static void deleteAllFiles(String repoPath){
        // delete一个GitHub仓库的所有内容，只保留.git
        Repository repository = openRepo(Paths.get(repoPath, ".git").toString())
        Git git = new Git(repository)
        File repo = new File(repoPath)
        repo.listFiles().each {
            if (it.name!='.git'){
                git.rm().addFilepattern(it.name).call()
            }
            if (it.name!='.git' && it.exists()){
                def rm = "rm -rf ${it.absolutePath}".execute(null,new File(repoPath))
            }
        }
        sleep(1000*10)  // 延迟10s
    }
}
