package util


import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern

class GithubAPIUtil {
    static Properties properties = new Properties()
    static token = properties.get("token")

    static void crawl(String PRUrl) {
        Pattern pattern = ~/https:\/\/github.com\/(.+)\/pull\/(.+)/
        Matcher matcher = pattern.matcher(PRUrl)
        if(!matcher.find()){
            println("url error:" + PRUrl)
            return
        }
        def (repoName, pulls) = [matcher.group(1),matcher.group(2)]
        String infoUrl = "https://api.github.com/repos/${repoName}/pulls/${pulls}"
        String infoSaveName = "${repoName.replace('/','@')}@${pulls}.json"
        String commentUrl = "https://api.github.com/repos/${repoName}/issues/${pulls}/comments"
        String commentSaveName = "${repoName.replace('/','@')}@${pulls}@comments.json"

        Closure crawlAPI = { String host, String jsonFileName->
            String head = "-H \"User-Agent: Mozilla/5.0\" -H \"Content-Type: application/json\"   -H \"Authorization: token ${token}\""
            String jsonFilePath = Paths.get(Util.pullRequestJson,jsonFileName).normalize().toString()
            def command = "curl ${head}  \"${host}\" > ${jsonFilePath}"
            def process = [ 'bash', '-c', command ].execute()
            process.waitFor()
            if(process.err.text.startsWith("error")){
                println(process.err.text)
            }
        }
        crawlAPI.call(infoUrl,infoSaveName)
        crawlAPI.call(commentUrl,commentSaveName)
    }

}
