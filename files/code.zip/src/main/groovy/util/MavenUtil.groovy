package util

class MavenUtil {
    static enum MavenStrategy {
        MAVEN_PARALLEL_EXECUTION,
        MAVEN_COMPILER_DAEMON,
//        MAVEN_DYNAMIC_VERSION,
//        MAVEN_UNUSED_DEPENDENCY,
        MAVEN_PARALLEL_TEST,
        MAVEN_FORK_TEST,
        MAVEN_REPORT_GENERATION,
//        MAVEN_INCREMENTAL_COMPILATION
    }

    static enum MavenCategory {
        PROPERTIES,
        COMPILATION,
        TEST
    }

    static Map<MavenCategory, List<MavenStrategy>> strategiesOfCategory =
            [(MavenCategory.PROPERTIES)       : [MavenStrategy.MAVEN_PARALLEL_EXECUTION],
             (MavenCategory.COMPILATION)      : [MavenStrategy.MAVEN_COMPILER_DAEMON],
             (MavenCategory.TEST)             : [MavenStrategy.MAVEN_PARALLEL_TEST,
                                                 MavenStrategy.MAVEN_REPORT_GENERATION,
                                                 MavenStrategy.MAVEN_FORK_TEST]]

    static MavenCategory getMavenCategory(MavenStrategy strategy){
        for(MavenCategory category : strategiesOfCategory.keySet()){
            def strategies = strategiesOfCategory.get(category)
            if (strategies.contains(strategy)){
                return category
            }
        }
        return null
    }
}