package util

import org.junit.runners.model.MultipleFailureException

import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern
import groovy.json.JsonSlurper
import model.Repository
import util.*

class TriggerUtil {


    /**
     * 根据传入的repoName下载该项目master分支上最新的code(ZIP形式，不包含.git）
     * @param repoName： owner/repo
     * @return Boolean,如果下载失败返回false
     */
    static Boolean downloadZip(String repoName){
        String zipPath =Paths.get(Util.codeZipPath,"${repoName.replace('/','@')}.zip").normalize().toString()
        if(new File(zipPath).exists()){
            return true
        }
        def defaultBranchName = GithubUtil.getDefaultBranchName(repoName)
        def downloadZipCommand = "curl -L https://api.github.com/repos/${repoName}/zipball/${defaultBranchName}  --output ${zipPath}"
        def downloadZipExecute = downloadZipCommand.execute()
        Closure checkZipDownload ={
            int retries = 0
            while(retries++ < 4){
                sleep(1000*60*retries)  // 最多下载3次，每次下载限时增加1min
                def checkZipCRC = "unzip -tq ${zipPath}".execute()  // 检查压缩文件是否正确
                def outputBuffer = new StringBuffer('')
                checkZipCRC.consumeProcessOutputStream(outputBuffer)
                if (outputBuffer.toString().startsWith("No errors") ||outputBuffer.size()==0){
                    println("${repoName.replace('/','@')}.zip下载成功")
                    return true
                }else{
                    //如果检测出错，就重新下载
                    downloadZipCommand.execute()
                    println("第${retries}次下载出错，重新下载${repoName.replace('/','@')}.zip")
                }
            }
            return false
        }
        if (!checkZipDownload.call()){
            println("${repoName.replace('/','@')}.zip下载失败")
            return false
        }
        return true
    }

    /**
     * 解压repo对应项目的code.zip，zip和解压后的文件夹位于Util.codeUnzipPath路径下
     * @param repoName： owner/repo
     * @return 解压失败，返回false；否则返回true
     */
    static boolean unzipCode(String repoName){
        String zipPath =Paths.get(Util.codeZipPath,"${repoName.replace('/','@')}.zip").normalize().toString()
        if (!new File(zipPath).exists()){
            println("${zipPath}不存在,重新下载")
            if(!downloadZip(repoName)){
                println("${zipPath}重新下载失败")
                return false
            }
        }
        Closure checkUnzip ={
            int retries = 0
            while(retries++ < 4){
                def unzipCommand = "unzip -o -d ${Util.codeUnzipPath}  ${zipPath}"
                def unzipExecute = unzipCommand.execute()
                sleep(1000*10*retries)
                def find = new File(Util.codeUnzipPath).listFiles().find() {file->
                    // code.zip解压后的文件名默认为: owner-repo-commitHashNumber
                    if(file.getName().contains(repoName.replace('/','-'))){
                        return true
                    }
                }
                if(find != null){
                    return true
                }
            }
            return false
        }
        if(!checkUnzip.call()){
            println("${zipPath}解压失败")
            return false
        }
        println("${zipPath}解压成功")
        return true
    }

    /**
     * 将sourceDirectory的所有文件，包含隐藏文件，全部复制到targetDirectory中
     * @param targetDirectory:绝对路径
     * @param sourceDirectory:绝对路径
     * @return：如果command执行结果的error内容不为空，返回false，否则返回true
     */
    static Boolean copyAllFilesToAnotherDirectory(String targetDirectory, String sourceDirectory){
        def copyCommand = "cp -r ${sourceDirectory}/. ${targetDirectory}"
        def copyExecute = copyCommand.execute()
        def out = new StringBuffer()
        def error = new StringBuffer()
        copyExecute.consumeProcessOutput(out,error)
        if (error.size()>0){
            println(error.toString())
            return false
        }
        return true
    }

    /**
     * 清空该目录下的所有文件，除了.git
     * @param GitDirectory:绝对路径
     * @return
     */
    static Boolean emptyGitDirectory(String GitDirectory){
        GitUtil.deleteAllFiles(Util.TravisTriggerRepoPath)
        return new File(GitDirectory).listFiles().size() == 1
    }

    /**
     * 根据smell，返回该smell对应的sheet数据：分别是没有merge和merged的repos
     * @param smell：smell和sheet名对应
     * @return [notMergedPR[] , MergedPR[] ]
     */
    static List<List<String>> getReposBySmell(String smell){
        String excelPath = Paths.get(System.getProperty("user.dir"), "resources", "PR详细信息汇总.xlsx")
        ExcelUtil excel = new ExcelUtil(excelPath, smell)
        def notMergedRepo = excel.getCellsConditionally([2:"FALSE"],0)
        def mergedRepo = excel.getCellsConditionally([2:"TRUE"],0)
        notMergedRepo = urlToRepo(notMergedRepo)  // owner/repo
//        mergedRepo = urlToRepo(mergedRepo)      // https://github.com/{owner/repo}/pull/{number}
        return [notMergedRepo, mergedRepo]
    }

    static List<String> urlToRepo(List<String> urls){
        List<String> repos = new ArrayList<>()
        urls.each{
            def (repo, pulls) = urlToRepo(it)
            repos << repo
        }
        return repos
    }

    static List<String> urlToRepo(String urls){
        Pattern pattern = ~/https:\/\/github.com\/(.*)\/pull\/(.*)/
        Matcher matcher = pattern.matcher(urls)
        if(matcher.find()){
            return [matcher.group(1), matcher.group(2)]
        }
        return [null, null]
    }

    /**
     * @return 返回所有发过PR的项目 List<String> repos , repo形式:owner/repo
     */
    static List<String> getAllRepos(){
        List<String> repos = new ArrayList<>()
        String excelPath = Paths.get(System.getProperty("user.dir"), "resources", "PR详细信息汇总.xlsx")
        ExcelUtil excel = new ExcelUtil(excelPath)

        def sheets = excel.getSheets()
        sheets.each {
            excel.setSheet(it)
            def cells = excel.getCells(0)
            repos += cells
        }
        repos = urlToRepo(repos)
        return repos.unique()
    }

    static List<String> downloads(List<String> repoNames){
        List<String> downloadError = new ArrayList<>()
        repoNames.each {
            if (!downloadZip(it)){
                downloadError << it
            }
        }
        return downloadError
    }

    /**
     * 根据repoUrl得到../sequence/fork里面对应repo的绝对路径
     * 由于一些repo，不同的账号可能对其发过多个不同类型的PR
     * 所以在fork里面，存在这种情况：有两个子目录——[账号1@某repo, 账号2@某repo]
     * 所以先要通过./resources/pullRequest@json中的json文件，读取发PR的账号
     * @param repoUrl: PR的url
     * @return forkRepoPath: 绝对路径
     */
    static String getForkRepoPath(String repo, String pulls){
        String repoJsonName = "${repo.replace('/','@')}@${pulls}.json"   //例如：ical4j@ical4j@535.json(新的json文件命名方式）
        String repoJsonPath = Paths.get(Util.pullRequestJson, repoJsonName)
        if(!new File(repoJsonPath).exists()){
            repoJsonName = "${repo.replace('/','@')}@pulls@${pulls}.json"   //例如：ical4j@ical4j@pulls@535.json(旧的json文件命名方式）
            repoJsonPath = Paths.get(Util.pullRequestJson, repoJsonName)
        }
        def jsonSlurper = new JsonSlurper()

        def repoJson = jsonSlurper.parse(new File(repoJsonPath))
        String gitUser = repoJson['user']['login']
        String forkRepoPath = Paths.get(Util.forkDirectoryPath,"${gitUser}@${repo.split('/')[1]}")
        return forkRepoPath
    }

    static boolean initTravisTriggerRepo(String repo, boolean isMerged){
        if(isMerged){
            return initTriggerIsMerged(repo)
        }else{
            return initTriggerNotMerged(repo)
        }
    }

    static boolean initTriggerIsMerged(String repoURL){
        try{
            def (repo, pulls) = urlToRepo(repoURL)

            //得到该repoURL在fork目录下对应的仓库的绝对路径
            String forkRepoPath = getForkRepoPath(repo, pulls)

            //在forkRepo切换到默认分支
            GitUtil.checkoutToDefaultBranch(forkRepoPath, repo)

            println("${repo} 初始化完毕")
        }
        catch (Exception e){
            e.printStackTrace()
            println("merged repo${repo}初始化失败")
            return false
        }

        return true
    }

    static boolean initTriggerNotMerged(String repoName){
        // 1.清空TravisTrigger文件夹的内容（保留.git)
        if(!emptyGitDirectory(Util.TravisTriggerRepoPath)){
            println("清空触发仓库失败")
            return false
        }
        println("1.清空触发仓库成功")

        // 2.找到repo在Util.codeUnzipPath路径下对应的文件夹：owner-repo-commitNumber
        def repoFile = new File(Util.codeUnzipPath).listFiles().find(){file->
            if(file.name.contains(repoName.replace('/','-'))){
                return true
            }
        }
        if(repoFile == null){
            println("没有找到对应的zip和解压文件")
            return false
        }


        // 3.判断是否存在.travis.yml
        String travisPath = Paths.get(repoFile.absolutePath,'.travis.yml')
        if (!new File(travisPath).exists()){
            println(".travis.yml不存在")
            return false
        }

        // 4.将codeDirectory里的内容全部复制到TravisTriggerRepoPath中
        if(!copyAllFilesToAnotherDirectory(Util.TravisTriggerRepoPath, repoFile.absolutePath)){
            println("copy失败")
            return false
        }
        println("3.copy成功")

        println("${repoName} 初始化完毕")
        return true
    }

    /**
     * 触发Travis Ci构建前的准备工作：
     * 1. 下载code.zip至 codeZipPath
     * 2. 解压code.zip至 codeUnzipPath
     */
    static void preparation(){
        //1.下载code.zip
        def repos = getAllRepos()
        def needDownloadRepo = []
        println("repos的长度：" + repos.size())
        Pattern pattern = ~/(.*).zip/
        new File(Util.codeZipPath).listFiles().each {codeFile->
            Matcher matcher = pattern.matcher(codeFile.getName())
            if(matcher.find()){
                if(!repos.contains(matcher.group(1).replace('@','/'))){
                    needDownloadRepo << matcher.group(1).replace('@','/')
                }
            }
        }
        println("需要下载的repos长度：" + needDownloadRepo.size())
        if(needDownloadRepo.size()!=0){
            def downloadError = downloads(needDownloadRepo)
            println("下载完毕")
            if (downloadError.size()>0){
                downloadError.each {
                    println("download error : ${it}")
                }
            }
        }

        //2. 解压code.zip
        new File(Util.codeZipPath).listFiles().each {codeFile->
            Matcher matcher = pattern.matcher(codeFile.getName())
            if(matcher.find()){
                unzipCode(matcher.group(1).replace('@','/'))
            }
        }
    }

    static void getTravisCacheBuildTool(){
        String excelPath = Paths.get(System.getProperty("user.dir"), "resources", "PR详细信息汇总.xlsx")
        ExcelUtil excel = new ExcelUtil(excelPath, 'TRAVIS_CACHE')
        def mergedRepo = excel.getCellsConditionally([2:"TRUE"],0)
        println("被merged的PR长度：" + mergedRepo.size() )
        mergedRepo = urlToRepo(mergedRepo)  //
        int travisCacheWithGradle = 0
        int travisCacheWithMaven = 0
        mergedRepo.each { repo ->
            def repository = MysqlUtil.getRepositoryByName(repo)
            if (repository == null) {
                println(repo)
            } else {
                if (repository.buildTool == 1) {
                    travisCacheWithMaven++
                } else {
                    travisCacheWithGradle++
                    println(repo)
                }
            }
        }
        println("Gradle的数量： ${travisCacheWithGradle}")
        println("Maven的数量： ${travisCacheWithMaven}")
    }

    static void main(String[] args) {
        preparation()
    }
}
