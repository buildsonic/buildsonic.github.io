package util


import java.nio.file.Paths
import java.util.regex.Matcher
import java.util.regex.Pattern
import groovy.json.JsonSlurper

class TriggerUtil {
    static Properties properties = new Properties()
    static String token = properties.get("token")

    static Boolean downloadZip(String repoName){
        String zipPath =Paths.get(Util.codeZipPath,"${repoName.replace('/','@')}.zip").normalize().toString()
        if(new File(zipPath).exists()){
            return true
        }
        def defaultBranchName = GithubUtil.getDefaultBranchName(repoName)
        def downloadZipCommand = "curl -L https://api.github.com/repos/${repoName}/zipball/${defaultBranchName}  --output ${zipPath}"
        def downloadZipExecute = downloadZipCommand.execute()
        def out = new StringBuffer()
        def error = new StringBuffer()
        downloadZipExecute.waitForProcessOutput(out,error)
        Closure checkZipDownload ={
            int retries = 0
            while(retries++ < 4){
                def checkZipCRC = "unzip -tq ${zipPath}".execute()
                def outputBuffer = new StringBuffer('')
                checkZipCRC.consumeProcessOutputStream(outputBuffer)
                if (outputBuffer.toString().startsWith("No errors") ||outputBuffer.size()==0){
                    return true
                }else{
                    downloadZipExecute = downloadZipCommand.execute()
                    downloadZipExecute.waitForProcessOutput(out,error)
                }
            }
            return false
        }
        if (!checkZipDownload.call()){
            println(error.toString())
            return false
        }
        return true
    }

    static String unzipCode(String repoName){
        String zipPath =Paths.get(Util.codeZipPath,"${repoName.replace('/','@')}.zip").normalize().toString()
        if (!new File(zipPath).exists()){
            if(!downloadZip(repoName)){
                return false
            }
        }
        println(zipPath)
        def unzipCommand = "unzip -o -d ${Util.codeUnzipPath}  ${zipPath}"
        def unzipExecute = unzipCommand.execute()
        def out = new StringBuffer()
        def error = new StringBuffer()
        unzipExecute.waitForProcessOutput(out,error)
        def find = new File(Util.codeUnzipPath).listFiles().find() {file->
            if(file.getName().contains(repoName.replace('/','-'))){
                return true
            }
        }
        if(find==null || error.size()>0){
            println(error.toString())
            return null
        }
        return find.absolutePath
    }


    static Boolean copyAllFilesToAnotherDirectory(String targetDirectory, String sourceDirectory){
        def copyCommand = "rsync -a --exclude .git ${sourceDirectory}/. ${targetDirectory}"
        def copyExecute = copyCommand.execute()
        def out = new StringBuffer()
        def error = new StringBuffer()
        copyExecute.waitForProcessOutput(out,error)
        if (error.size()>0){
            println(error.toString())
            return false
        }
        sleep(1000*30)
        return true
    }

    static Boolean emptyGitDirectory(String triggerRepoPath){
        GitUtil.deleteAllFiles(triggerRepoPath)
        return new File(triggerRepoPath).listFiles().size() <= 1
    }


    static List<List<String>> getPRUrlBySmell(String smell){
        ExcelUtil excel = new ExcelUtil(Util.pullRequestInfoPath, smell)
        def notMergedRepo = excel.getCellsConditionally([3:"FALSE"],1)
        def mergedRepo = excel.getCellsConditionally([3:"TRUE"],1)
        return [notMergedRepo, mergedRepo]
    }

    static List<String> urlToRepo(List<String> urls){
        List<String> repos = new ArrayList<>()
        urls.each{
            def (repo, pulls) = urlToRepo(it)
            repos << repo
        }
        return repos
    }

    static List<String> urlToRepo(String urls){
        Pattern pattern = ~/https:\/\/github.com\/(.*)\/pull\/(.*)/
        Matcher matcher = pattern.matcher(urls)
        if(matcher.find()){
            return [matcher.group(1), matcher.group(2)]
        }
        return [null, null]
    }


    static List<String> getAllRepos(){
        List<String> repos = new ArrayList<>()
        ExcelUtil excel = new ExcelUtil(Util.pullRequestInfoPath)
        def strategies = []
        strategies << MavenUtil.MavenStrategy.MAVEN_PARALLEL_TEST.toString()
        strategies << MavenUtil.MavenStrategy.MAVEN_PARALLEL_EXECUTION.toString()
        strategies << MavenUtil.MavenStrategy.MAVEN_FORK_TEST.toString()
        strategies << MavenUtil.MavenStrategy.MAVEN_REPORT_GENERATION.toString()
        strategies << MavenUtil.MavenStrategy.MAVEN_COMPILER_DAEMON.toString()
        def sheets = excel.getSheets()
        sheets.each {
            if(strategies.contains(it.sheetName)){
                excel.setSheet(it)
                def cells = excel.getCells(0)
                repos += cells
            }
        }
        repos = urlToRepo(repos)
        return repos.unique()
    }

    static List<String> downloads(List<String> repoNames){
        List<String> downloadError = new ArrayList<>()
        repoNames.each {
            if (!downloadZip(it)){
                downloadError << it
            }
        }
        return downloadError
    }


    static String getForkRepoPath(String repo, String pulls){
        Closure downloadGithubAPI = { String jsonPath ->
            def host = "https://api.github.com/repos/${repo}/pulls/${pulls}"
            def command = "curl -H \"User-Agent:Mozilla/5.0\" -H \"Authorization: ${token} \" -H \"Accept:application/json\" \"${host}\" > ${jsonPath}"
            try{
                def process = [ 'bash', '-c', command ].execute()
                process.waitFor()
                return true
            } catch (Exception e){
                e.printStackTrace()
                return false
            }
        }
        Closure parseJson = { String jsonPath->
            if(!new File(jsonPath).exists()){
                return null
            }
            def jsonSlurper = new JsonSlurper()
            def repoJson = jsonSlurper.parse(new File(jsonPath))
            def prCreator = repoJson['user']['login']
            return  Paths.get(Util.forkDirectoryPath,"${prCreator}@${repo.split('/')[1]}").normalize().toString()
        }

        String repoJsonName = "${repo.replace('/','@')}@${pulls}.json"
        String repoJsonPath = Paths.get(Util.pullRequestJson, repoJsonName).normalize().toString()
        if(!new File(repoJsonPath).exists()){
           downloadGithubAPI.call(repoJsonPath)
        }

        def forkRepoPath = parseJson.call(repoJsonPath)
        if (forkRepoPath!=null){
            return forkRepoPath
        }

        repoJsonName = "${repo.replace('/','@')}@pulls@${pulls}.json"
        repoJsonPath = Paths.get(Util.pullRequestJson, repoJsonName).normalize().toString()
        forkRepoPath = parseJson.call(repoJsonPath)
        if (forkRepoPath!=null){
            return forkRepoPath
        }

        return null
    }

    static boolean initTravisTriggerRepo(String triggerRepoPath,String repoInfo, String originRepoName, boolean isMerged){
        if(!emptyGitDirectory(triggerRepoPath)){
            return false
        }

        String originRepoPath = isMerged?initTriggerIsMerged(repoInfo):initTriggerNotMerged(originRepoName)
        if(originRepoPath==null){
            return false
        }

        String travisPath = Paths.get(originRepoPath,'.travis.yml')
        if (!new File(travisPath).exists()){
            return false
        }

        if(!copyAllFilesToAnotherDirectory(triggerRepoPath, originRepoPath)){
            return false
        }

        return true
    }

    static String initTriggerIsMerged(String repoURL){
        def (repo, pulls) = urlToRepo(repoURL)
        try{
            String forkRepoPath = getForkRepoPath(repo, pulls)
            if (forkRepoPath==null){
                return null
            }
            println("fork path: ${forkRepoPath}")
            GitUtil.checkoutToDefaultBranch(forkRepoPath, repo)
            return forkRepoPath
        }
        catch (Exception e){
            e.printStackTrace()
            return null
        }
    }

    static String initTriggerNotMerged(String repoName){

        def originRepoPath = unzipCode(repoName)
        sleep(1000*30)
        return originRepoPath

    }


    static void preparation(){
        def repos = getAllRepos()
        Pattern pattern = ~/(.*).zip/
        new File(Util.codeZipPath).listFiles().each {codeFile->
            Matcher matcher = pattern.matcher(codeFile.getName())
            if(matcher.find()){
                def downloadedRepo = matcher.group(1).replace('@','/')
                if(repos.contains(downloadedRepo)){
                    repos.remove(downloadedRepo)
                }
            }
        }
        if(repos.size()!=0){
            def downloadError = downloads(repos)
            if (downloadError.size()>0){
                downloadError.each {
                    println("download error : ${it}")
                }
            }
        }

        repos.each {repoName->
            unzipCode(repoName)
        }
    }


    static void main(String[] args) {
    }
}
