package util

import groovy.io.FileType
import model.Repository
import org.apache.commons.configuration2.FileBasedConfiguration
import org.apache.commons.configuration2.PropertiesConfiguration
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder
import org.apache.commons.configuration2.builder.fluent.Parameters;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Util {
    public static final String codeDirectoryPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "repository").normalize().toString();
    public static final String forkDirectoryPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "fork").normalize().toString();
    // TravisTriggerRepoPath：触发Travis CI构建的git repo--->绑定账号 i-Taozi
    public static final String TravisTriggerRepoPath = Paths.get(System.getProperty("user.dir"), "..", "TravisTrigger").normalize().toString();
    // codeZipPath: 存放需要触发构建的repo的code ZIP ;  codeUnzipPath: 存放需要触发构建的repo的code.zip解压后的文件
    public static final String codeZipPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "codeZip").normalize().toString();
    public static final String codeUnzipPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "codeUnzip").normalize().toString()
    public static final String pullRequestJson = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest@json").normalize().toString()

    //记录pull request的url
    public static final String TRAVIS_CACHE_LIST_PATH = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "travis_cache.txt").normalize().toString();

    public static final String TRAVIS_SHALLOW_CLONE_LIST_PATH = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "travis_shallow_clone.txt").normalize().toString();

    public static final String TRAVIS_RETRY_LIST_PATH = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "travis_retry.txt").normalize().toString();

    public static final String TRAVIS_WAIT_LIST_PATH = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "travis_wait.txt").normalize().toString();

    public static final String TRAVIS_FAST_FINISH_LIST_PATH = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "travis_fast_finish.txt").normalize().toString();

    static String getPullRequestListFilePath(def o) {
        Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "${o.toString()}.txt").normalize().toString();
    }



    static void createDir(String directoryPath) {
        File file = new File(directoryPath)
        if (!file.exists())
            file.mkdir()
    }

    static List<String> splitFullRepoName(String fullRepoName) {
        int index = fullRepoName.indexOf('/')
        return [fullRepoName[0..<index], fullRepoName[index+1..-1]]
    }

    def static retry(int times = 5, Closure errorHandler = {e -> e.printStackTrace}
              , Closure body) {
        int retries = 0
        def exceptions = []
        while(retries++ < times) {
            try {
                return body.call()
            } catch(e) {
                exceptions << e
                errorHandler.call(e)
                sleep(5000)
            }
        }
        throw new Exception("Failed after $times retries", exceptions)
    }

    static String getBuildFileName(String repoPath) {
        String travisConfigFileName = null
        def fileList = []
        new File(repoPath).eachFile(FileType.FILES) {
            fileList << it.name
        }
        fileList.each {
            println(it)
            if (it.equals("pom.xml") || it == "build.gradle") {
                travisConfigFileName = it
                return
            }
        }
        return travisConfigFileName;
    }

    //找到项目中的所有shell文件
    static List<String> getShellFilePaths(String repoPath) {
        List<String> list = []
        File dir = new File(repoPath)
        if (dir.exists()) {
            dir.eachFileRecurse(FileType.FILES) {
                String filePath = it.path
                if (filePath.endsWith(".sh")) {
                    //println(filePath)
                    list << filePath
                }
            }
        }
        return list
    }

    //找到项目中的所有.gradle文件
    static List<String> getGradleFilePaths(String repoPath) {
        List<String> list = []
        File dir = new File(repoPath)
        if (dir.exists()) {
            dir.eachFileRecurse(FileType.FILES) {
                String filePath = it.path
                if (filePath.endsWith(".gradle")) {
                    //println(filePath)
                    list << filePath
                }
            }
        }
        return list
    }

    static void scan() {
        List<Repository> repositories = MysqlUtil.getRepositories();
        for (Repository repository : repositories) {
            String repoName = repository.repoName
            //System.out.println(repository.getId() + " " + repository.getRepoName() + " " + repository.getContainTravisYml());
            String repoPath = Paths.get(Util.codeDirectoryPath.toString(), repository.getRepoName().replace('/', '@')).normalize().toString();
            File file = new File(Paths.get(repoPath, "settings.gradle").toString())
            if (file.exists()) {
                println(repoName)
                println(file.text)
                println("==================")
            }
        }
    }

    static FileBasedConfigurationBuilder<FileBasedConfiguration> getConfigurationBuilder(String path) {
        Parameters params = new Parameters();
        FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
                new FileBasedConfigurationBuilder<FileBasedConfiguration>(PropertiesConfiguration.class)
                        .configure(params.properties()
                                .setFileName(path));
        return builder
    }

    static void main(String[] args) {
        Util.scan()
    }
}
