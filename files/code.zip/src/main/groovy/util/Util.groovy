package util

import groovy.io.FileType
import model.Repository
import org.apache.commons.configuration2.FileBasedConfiguration
import org.apache.commons.configuration2.PropertiesConfiguration
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder
import org.apache.commons.configuration2.builder.fluent.Parameters;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

class Util {
    public static final String codeDirectoryPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "repository").normalize().toString()
    public static final String forkDirectoryPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "fork").normalize().toString()
    public static final String pullRequestInfoPath = Paths.get(System.getProperty("user.dir"), "resources", "pullRequestInfo.xlsx").normalize().toString()
    public static final String codeZipPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "codeZip").normalize().toString()
    public static final String codeUnzipPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "codeUnzip").normalize().toString()
    public static final String gitDepthTestPath = Paths.get(System.getProperty("user.dir"), "..", "sequence", "gitDepth").normalize().toString()
    public static final String pullRequestJson = Paths.get(System.getProperty("user.dir"), "resources", "pullRequest@json").normalize().toString()
    public static final String CheckAndFixDirectoryPath =  Paths.get(System.getProperty("user.dir"), "..", "CheckAndFixDirNew").normalize().toString()

    static String getPullRequestListFilePath(def o) {
        Paths.get(System.getProperty("user.dir"), "resources", "pullRequest", "${o.toString()}.txt").normalize().toString()
    }

    static String getTravisAPIInfoPath(def strategy){
        Paths.get(System.getProperty("user.dir"), "resources", "travisAPIInfo", "${strategy.toString()}.json").normalize().toString()
    }

    static String getTriggerRepoPath(def strategy){
        if (strategy instanceof TravisUtil.TravisStrategy){
            return Paths.get(System.getProperty("user.dir"), "..", "${strategy.toString()}_Trigger").normalize().toString()
        }
        if (strategy instanceof GradleUtil.GradleStrategy){
            def category = GradleUtil.getGradleCategory(strategy)
            if (category == GradleUtil.GradleCategory.PROPERTIES){
                return Paths.get(System.getProperty("user.dir"), "..", "GradlePropertyTrigger").normalize().toString()
            }else{
                return Paths.get(System.getProperty("user.dir"), "..", "GradleBuildTrigger").normalize().toString()
            }
        }
        if (strategy instanceof MavenUtil.MavenStrategy){
            def category = MavenUtil.getMavenCategory(strategy)
            if (category == MavenUtil.MavenCategory.TEST){
                return Paths.get(System.getProperty("user.dir"), "..", "MavenTestTrigger").normalize().toString()
            }else{
                return Paths.get(System.getProperty("user.dir"), "..", "MavenCompileTrigger").normalize().toString()
            }
        }
       return ""
    }




    static void createDir(String directoryPath) {
        File file = new File(directoryPath)
        if (!file.exists())
            file.mkdir()
    }

    static List<String> splitFullRepoName(String fullRepoName) {
        int index = fullRepoName.indexOf('/')
        return [fullRepoName[0..<index], fullRepoName[index+1..-1]]
    }

    def static retry(int times = 5, Closure errorHandler = {e -> e.printStackTrace}
              , Closure body) {
        int retries = 0
        def exceptions = []
        while(retries++ < times) {
            try {
                return body.call()
            } catch(e) {
                exceptions << e
                errorHandler.call(e)
                sleep(5000)
            }
        }
        throw new Exception("Failed after $times retries", exceptions)
    }

    static String getBuildFileName(String repoPath) {
        String travisConfigFileName = null
        def fileList = []
        new File(repoPath).eachFile(FileType.FILES) {
            fileList << it.name
        }
        fileList.each {
            println(it)
            if (it.equals("pom.xml") || it == "build.gradle") {
                travisConfigFileName = it
                return
            }
        }
        return travisConfigFileName;
    }

    static List<String> getShellFilePaths(String repoPath) {
        List<String> list = []
        File dir = new File(repoPath)
        if (dir.exists()) {
            dir.eachFileRecurse(FileType.FILES) {
                String filePath = it.path
                if (filePath.endsWith(".sh")) {
                    list << filePath
                }
            }
        }
        return list
    }

    static List<String> getGradleFilePaths(String repoPath) {
        List<String> list = []
        File dir = new File(repoPath)
        if (dir.exists()) {
            dir.eachFileRecurse(FileType.FILES) {
                String filePath = it.path
                if (filePath.endsWith(".gradle")) {
                    list << filePath
                }
            }
        }
        return list
    }

    static void scan() {
        List<Repository> repositories = MysqlUtil.getRepositories()
        for (Repository repository : repositories) {
            String repoName = repository.repoName
            String repoPath = Paths.get(Util.codeDirectoryPath.toString(), repository.getRepoName().replace('/', '@')).normalize().toString()
            File file = new File(Paths.get(repoPath, "settings.gradle").toString())
            if (file.exists()) {
                println(repoName)
                println(file.text)
                println("==================")
            }
        }
    }

    static FileBasedConfigurationBuilder<FileBasedConfiguration> getConfigurationBuilder(String path) {
        Parameters params = new Parameters()
        FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
                new FileBasedConfigurationBuilder<FileBasedConfiguration>(PropertiesConfiguration.class)
                        .configure(params.properties()
                                .setFileName(path))
        return builder
    }

    static void main(String[] args) {
        Util.scan()
    }
}
