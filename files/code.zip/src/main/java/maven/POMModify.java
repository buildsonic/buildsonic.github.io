package maven;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class POMModify {

    private Document doc;
    private XPath xpath;
    private ArrayList<String> parentModify = new ArrayList<>();

    public POMModify modify(String pomAbsolutePath, ArrayList<POM> pomList , ArrayList<String> targetDependency) throws Exception {
        String relativePath = targetDependency.get(1).substring(5);
        //String pomAbsolutePath = filePath + "/" + relativePath.replace(".","/") + "/pom.xml";
        String content = turnDocumentToString(pomAbsolutePath);

        if (!content.equals("")) {
            doc = getDocument(content);
            XPathFactory xPathfactory = XPathFactory.newInstance();
            xpath = xPathfactory.newXPath();

            for(int i = 2; i < targetDependency.size(); i++){
                String[] targetDep = getStrings(targetDependency.get(i));
                if(!modifyDependencies(targetDep)){
                    if(!modifyProperties(targetDep)){
                        parentModify.add(targetDependency.get(i));
                    }
                }
            }

            TransformerFactory tff = TransformerFactory.newInstance();
            Transformer tf = tff.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult sr = new StreamResult(pomAbsolutePath);
            tf.transform(source, sr);

            if(parentModify!=null){

                POM currentPom = null;
                for (POM pom:pomList){
                    if(pom.getRelativePath().equals(relativePath)){
                        currentPom = pom;
                        break;
                    }
                }
                if(currentPom!=null && currentPom.hasParent()){
                    POM fPom = currentPom.getParent();
                    parentModify.add(0," ");
                    parentModify.add(1,fPom.getRelativePath());
                    POMModify fpomModify = new POMModify().modify(fPom.getPath(),pomList,parentModify);
                }
            }
        }
        return null;
    }

    private String[] getStrings(String string){
        String[] targetDep = new String[4];

        String targetDepRaw = string.substring(19);

        String name = targetDepRaw.split(",")[0].trim();

        String versionContent = targetDepRaw.split(",")[1].split(":")[1].trim();


        String versions = targetDepRaw.split(",")[2];


        String version = versions.split("}")[0].substring(9).trim();

        String modifiedVersion = string.split(">")[1].trim();

        targetDep[0]=name;
        targetDep[1]=versionContent;
        targetDep[2]=version;
        targetDep[3]=modifiedVersion;
        return targetDep;
    }

    private Document getDocument(String content) throws Exception{
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource inputSource = new InputSource(new StringReader(content));
        return builder.parse(inputSource);
    }

    private String replaceProperties(String string) throws Exception {
        String patternString = "(.*?)\\$\\{(.+?)}([^$]*)";
        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(string);

        String replaced = "";

        while(matcher.find()) {
            String prefix = matcher.group(1);
            String propertyName = matcher.group(2);
            String suffix = matcher.group(3);
            replaced = replaced + prefix + propertyName + suffix;
        }
        if (!replaced.equals("")) {
            return replaced;
        }
        return string;
    }

    private boolean modifyProperties(String[] targetDep) throws Exception{
        for (Node node : getNodes("/project/properties/*")) {
            String name = node.getNodeName();
            String value = node.getTextContent();
            String versionContent = replaceProperties(targetDep[1]);
            if (name.equals(versionContent) && value.equals(targetDep[2])){
                node.setTextContent(targetDep[3]);
                System.out.println("Modify property: " + name + ": " + value + "---->" + targetDep[3]);
                return true;
            }
        }
        return false;
    }

    private boolean modifyDependencies(String[] targetDep) throws Exception{
        for (Node node : getNodes(
                "/project/dependencies/dependency|/project/dependencyManagement/dependencies/dependency")) {
            NodeList childNodes = node.getChildNodes();

            String groupID = "";
            String artificatID = "";
            String version = "";

            for (int i=0; i < childNodes.getLength(); i++) {
                Node childNode = childNodes.item(i);
                if (Node.ELEMENT_NODE == childNode.getNodeType()) {

                    String tag = childNode.getNodeName();

                    if (tag.equals("groupId")) {
                        groupID = childNode.getTextContent();
                        groupID = replaceProperties(groupID);
                    } else if (tag.equals("artifactId")) {
                        artificatID = childNode.getTextContent();
                        artificatID = replaceProperties(artificatID);
                    } else if (tag.equals("version")) {
                        version = childNode.getTextContent();
                      //  version = replaceProperties(version);
                    }
                }
            }


            String name = groupID + '/' + artificatID;
            name = name.trim();
          //  System.out.println("dep: " + name + "  version: " + version);

            if(name.equals(targetDep[0])){
             //   System.out.println("the same name,and it's version: "  + version);
                if(version.equals("") || version.startsWith("$")) {
                    return false;
                }else if(version.equals(targetDep[1])){
                    for (int i=0; i < childNodes.getLength(); i++) {
                        Node childNode = childNodes.item(i);
                        if (Node.ELEMENT_NODE == childNode.getNodeType()) {
                            String tag = childNode.getNodeName();
                            if (tag.equals("version")) {
                                childNode.setTextContent(targetDep[3]);
                                System.out.println("Modify dependency<version>: " + targetDep[1] + "---->" +targetDep[3]);
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private String turnDocumentToString(String path) {
        try {
            File fileinput = new File(path);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fileinput);

            DOMSource domSource = new DOMSource(doc);
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.transform(domSource, result);


            return writer.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private ArrayList<Node> getNodes(String name) throws Exception {
        XPathExpression expr = xpath.compile(name);
        NodeList nodes = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        ArrayList<Node> result = new ArrayList<>();

        for (int i=0; i < nodes.getLength(); i++) {
            Node childNode = nodes.item(i);
            if (Node.ELEMENT_NODE == childNode.getNodeType()) {
                result.add(childNode);
            }
        }
        return result;
    }

    private String getValue(String name) throws Exception {
        XPathExpression expr = xpath.compile(name);
        return expr.evaluate(doc);
    }
}
