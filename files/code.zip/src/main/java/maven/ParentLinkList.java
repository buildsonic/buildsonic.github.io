package maven;

import java.util.ArrayList;
import java.util.HashSet;

public class ParentLinkList {

    private HashSet<Node> parentLinkLists = new HashSet<>();
    private ArrayList<Node> Nodes = new ArrayList<>();

    public class Node{
        private POM pom;
        private String name;
        private Node parent;
        private Node child;

        public Node(POM pom){
            this.pom = pom;
            this.name = pom.getRelativePath();
            this.parent = null;
            this.child = null;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public POM getPom() {
            return pom;
        }

        public void setPom(POM pom) {
            this.pom = pom;
        }

        public Node getParent() {
            return parent;
        }

        public void setParent(Node parent) {
            this.parent = parent;
        }

        public Node getChild() {
            return child;
        }

        public void setChild(Node child) {
            this.child = child;
        }

    }

    public HashSet<Node> getParentLinkLists(ArrayList<POM> pomList){
        initNodes(pomList);
        linkNode();
        setParentLinkLists();
        return parentLinkLists;
    }

    public void initNodes(ArrayList<POM> pomList){
        for (POM pom:pomList) {
            Node node = new Node(pom);
            Nodes.add(node);
        }
    }

    public void linkNode(){
        for (Node node:Nodes) {
            POM pom = node.getPom();
            if (pom.hasParent()){
                String fName = pom.getParent().getRelativePath();
                for (Node fnode:Nodes) {
                    if(fnode.getName().equals(fName)){
                        node.setParent(fnode);
                        fnode.setChild(node);
                        break;
                    }
                }
            }
        }
    }

    public void setParentLinkLists(){
        for(Node node:Nodes){
            while(node.getParent()!=null){
                node = node.getParent();
            }
            parentLinkLists.add(node);
        }
    }

}
