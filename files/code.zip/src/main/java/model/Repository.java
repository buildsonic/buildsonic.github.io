package model;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Data
@RequiredArgsConstructor
@Entity
@Table(name = "repositories")
public class Repository {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "repo_name")
    private String repoName;

    @Column(name = "ignore_repo")
    private Boolean ignoreRepo;

    @Column(name = "star_number")
    private Integer starNumber;

    @Column(name = "last_build_number")
    private Integer lastBuildNumber;

    @Column(name = "last_build_started_at")
    private Date lastBuildStartedAt;

    @Column(name = "contain_travis_yml")
    private Boolean containTravisYml;

    @Column(name = "build_tool")
    private Integer buildTool;

    @Column(name = "last_build_time")
    private Date lastBuildTime;

    @Column(name = "travis_git_depth")
    private String travisGitDepth;

    @Column(name = "travis_retry")
    private Boolean travisRetry;

    @Convert(converter = IntegerListConverter.class)
    @Column(name = "travis_wait")
    private List<Integer> travisWait;

    @Column(name = "travis_cache")
    private Boolean travisCache;

    @Column(name = "travis_allow_failures")
    private Boolean travisAllowFailures;

    @Column(name = "travis_fast_finish")
    private Boolean travisFastFinish;

    @Column(name = "multi_module")
    private Boolean multiModule;

    @Column(name = "parallel_execution")
    private Integer parallelExecution;

    @Column(name = "dynamic_version")
    private Boolean dynamicVersion;

    @Column(name = "build_success")
    private Boolean buildSuccess;

    @Column(name = "contain_unused_dependency")
    private Boolean containUnusedDependency;

    @Column(name = "parallel_test")
    private Integer parallelTest;

    @Column(name = "version")
    private String version;

    @Column(name = "file_system_watch")
    private Integer fileSystemWatch;

    @Column(name = " configure_on_demand")
    private Integer configureOnDemand;

    @Column(name = "gradle_cache")
    private Integer gradleCache;

    @Column(name = "gradle_daemon")
    private Integer gradleDaemon;

    @Column(name = "gradle_fork_test")
    private Integer gradleForkTest;

    @Column(name = "gradle_report_generation")
    private Integer gradleReportGeneration;

    @Column(name = "gradle_compiler_daemon")
    private Integer gradleCompilerDaemon;

    @Column(name = "gradle_incremental_compilation")
    private Integer gradleIncrementalCompilation;

    @Column(name = "java_files_num")
    private Integer javaFilesNum;

    @Column(name = "maven_fork_test")
    private Integer mavenForkTest;

    @Column(name = "maven_report_generation")
    private Integer mavenReportGeneration;

    @Column(name = "maven_compiler_daemon")
    private Integer mavenCompilerDaemon;

    @Column(name = "maven_incremental_compilation")
    private Integer mavenIncrementalCompilation;

    @Column(name = "contain_test")
    private Integer containTest;
}
