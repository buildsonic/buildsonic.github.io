package util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UtilTest {


    @Test
    void testGetShellFilePaths() {
        String path = System.getProperty("user.dir")
        println(path)
        Util.getShellFilePaths(path)
    }
}